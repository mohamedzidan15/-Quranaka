<?php
/**
 * ============================================================
 * admin.php - لوحة التحكم V10.0 (شاملة وكاملة)
 * تشمل: الأذكار + الأحاديث + الأيقونات + كل الإعدادات
 * ============================================================
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('QURAN_APP', true);
require_once __DIR__ . '/config.php';
startSecureSession();

/* تسجيل الخروج */
if (isset($_GET['logout'])) { adminLogout(); redirect('admin.php'); }

/* تسجيل الدخول */
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && !isset($_POST['action'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        $loginError = 'طلب غير آمن';
    } else {
        $result = adminLogin($_POST['username'] ?? '', $_POST['password'] ?? '');
        if ($result['success']) redirect('admin.php');
        else $loginError = $result['message'];
    }
}

if (!isAdminLoggedIn()) {
    $token = csrfToken();
    ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تسجيل الدخول</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Cairo',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0d2b35,#07131c);padding:20px}
.login-card{background:#fff;border-radius:24px;padding:40px 30px;max-width:420px;width:100%;text-align:center;box-shadow:0 25px 60px rgba(0,0,0,.4)}
.login-logo{width:80px;height:80px;margin:0 auto 20px;background:linear-gradient(135deg,#c9a959,#a8893a);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:36px;color:#fff}
.login-card h1{color:#0d2b35;font-size:26px;font-weight:900;margin-bottom:6px}
.login-subtitle{color:#64748b;font-size:14px;margin-bottom:24px}
.login-error{background:#fef2f2;color:#ef4444;padding:12px;border-radius:10px;margin-bottom:18px;font-size:14px;border-right:4px solid #ef4444}
.login-form{display:flex;flex-direction:column;gap:14px}
.input-group{position:relative}
.input-group i:first-child{position:absolute;right:16px;top:50%;transform:translateY(-50%);color:#64748b}
.input-group input{width:100%;padding:14px 46px;border:2px solid #e2e8f0;border-radius:10px;font-family:inherit;font-size:15px;background:#f8fafc}
.input-group input:focus{outline:none;border-color:#c9a959;background:#fff}
.toggle-password{position:absolute;left:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#64748b;cursor:pointer;padding:6px}
.btn-login{background:linear-gradient(135deg,#c9a959,#a8893a);color:#fff;border:none;padding:14px;border-radius:10px;font-family:inherit;font-size:16px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;margin-top:8px}
</style>
</head>
<body>
<div class="login-card">
    <div class="login-logo"><i class="fas fa-quran"></i></div>
    <h1>لوحة التحكم</h1>
    <p class="login-subtitle">أدخل بياناتك للوصول</p>
    <?php if ($loginError): ?><div class="login-error"><i class="fas fa-exclamation-triangle"></i> <?= sanitize($loginError) ?></div><?php endif; ?>
    <form method="POST" class="login-form">
        <input type="hidden" name="csrf_token" value="<?= $token ?>">
        <div class="input-group"><i class="fas fa-user"></i><input type="text" name="username" placeholder="اسم المستخدم" required autofocus></div>
        <div class="input-group"><i class="fas fa-lock"></i><input type="password" name="password" id="passwordInput" placeholder="كلمة المرور" required>
            <button type="button" class="toggle-password" onclick="togglePassword()"><i class="fas fa-eye"></i></button>
        </div>
        <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> دخول</button>
    </form>
</div>
<script>
function togglePassword(){const i=document.getElementById('passwordInput');const ic=document.querySelector('.toggle-password i');if(i.type==='password'){i.type='text';ic.classList.replace('fa-eye','fa-eye-slash')}else{i.type='password';ic.classList.replace('fa-eye-slash','fa-eye')}}
</script>
</body>
</html>
    <?php
    exit;
}

/* ============================================================
   معالج الإجراءات
   ============================================================ */
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action !== '' && !in_array($action, ['do_login', 'logout'], true)) {
    $csrfActions = [
        'update_settings','save_reciter','save_reel_reciter','save_audio',
        'save_video','save_book','smart_upload','update_reels_order',
        'save_control','save_content_settings','toggle_section','clear_cache',
        'change_password','bulk_delete','save_carousel_settings',
        'save_azkar_category','save_zikr','save_hadith','save_app_icon'
    ];
    if (in_array($action, $csrfActions, true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireCSRF();
    }
    handleAdminAction($action);
}

function handleAdminAction(string $action): void
{
    try {
        switch ($action) {

            case 'stats':
                header('Content-Type: application/json; charset=utf-8');
                $stats = [
                    'total_views'    => (int)db()->query("SELECT COALESCE(SUM(view_count),0) FROM stats_page_views")->fetchColumn(),
                    'total_likes'    => (int)db()->query("SELECT COUNT(*) FROM stats_user_actions WHERE action_type='like'")->fetchColumn(),
                    'total_shares'   => (int)db()->query("SELECT COUNT(*) FROM stats_user_actions WHERE action_type='share'")->fetchColumn(),
                    'total_plays'    => (int)db()->query("SELECT COUNT(*) FROM stats_user_actions WHERE action_type IN ('play_audio','play_video')")->fetchColumn(),
                    'total_downloads'=> (int)db()->query("SELECT COUNT(*) FROM stats_user_actions WHERE action_type='download'")->fetchColumn(),
                    'active_today'   => (int)db()->query("SELECT COUNT(DISTINCT session_id) FROM stats_active_sessions WHERE DATE(last_activity)=CURDATE()")->fetchColumn(),
                    'total_reciters' => (int)db()->query("SELECT COUNT(*) FROM reciters")->fetchColumn(),
                    'total_videos'   => (int)db()->query("SELECT COUNT(*) FROM videos")->fetchColumn(),
                    'total_books'    => (int)db()->query("SELECT COUNT(*) FROM books")->fetchColumn(),
                    'total_audios'   => (int)db()->query("SELECT COUNT(*) FROM audios")->fetchColumn(),
                    'total_azkar'    => (int)db()->query("SELECT COUNT(*) FROM azkar")->fetchColumn(),
                    'total_hadiths'  => (int)db()->query("SELECT COUNT(*) FROM hadiths")->fetchColumn(),
                    'online_now'     => (int)db()->query("SELECT COUNT(DISTINCT session_id) FROM stats_active_sessions WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)")->fetchColumn(),
                ];
                $daily = db()->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM stats_user_actions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date ASC")->fetchAll();
                $contentTypes = db()->query("SELECT item_type, COUNT(*) as count FROM stats_user_actions WHERE item_type IS NOT NULL AND item_type != '' GROUP BY item_type ORDER BY count DESC LIMIT 8")->fetchAll();
                $peakHours = db()->query("SELECT HOUR(created_at) as hour, COUNT(*) as count FROM stats_user_actions GROUP BY HOUR(created_at) ORDER BY hour ASC")->fetchAll();
                $recentActivity = [];
                try {
                    $recentActivity = db()->query("SELECT action_type, item_type, item_id, created_at FROM stats_user_actions ORDER BY created_at DESC LIMIT 20")->fetchAll();
                } catch (Throwable $e) {}
                echo json_encode([
                    'success' => true, 'stats' => $stats, 'daily' => $daily,
                    'contentTypes' => $contentTypes, 'peakHours' => $peakHours,
                    'topReciters' => [], 'topBooks' => [], 'topVideos' => [],
                    'recentActivity' => $recentActivity,
                ], JSON_UNESCAPED_UNICODE);
                exit;

            case 'update_settings':
                $checkboxKeys = ['show_intro','maintenance_mode'];
                $textKeys = ['site_name','site_description','contact_email','contact_phone','social_facebook','social_twitter','social_youtube','social_telegram'];
                foreach ($checkboxKeys as $k) {
                    $val = isset($_POST[$k]) && $_POST[$k] === '1' ? '1' : '0';
                    db()->prepare("INSERT INTO settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([$k, $val]);
                }
                foreach ($textKeys as $k) {
                    if (!isset($_POST[$k])) continue;
                    db()->prepare("INSERT INTO settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([$k, trim($_POST[$k])]);
                }
                setFlash('✅ تم حفظ الإعدادات','success');
                redirect('admin.php?tab=settings');

            case 'save_control':
                $controlKeys = [
                    'site_title','site_subtitle','hero_title','hero_subtitle','footer_text',
                    'bg_fajr','bg_sunrise','bg_dhuhr','bg_asr','bg_maghrib','bg_isha','bg_night','bg_default',
                    'primary_color','accent_color','whatsapp_number','telegram_channel'
                ];
                foreach ($controlKeys as $k) {
                    if (!isset($_POST[$k])) continue;
                    db()->prepare("INSERT INTO app_settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([$k, trim($_POST[$k])]);
                }
                setFlash('✅ تم حفظ الإعدادات','success');
                redirect('admin.php?tab=control');

            case 'toggle_section':
                $section = $_GET['section'] ?? '';
                $enabled = ($_GET['enabled'] ?? '0') === '1' ? '1' : '0';
                $allowed = ['books','videos','audio','reciters','reel_reciters','prayer','surahs','azkar','tasbih','hadith','calendar'];
                if (!in_array($section, $allowed, true)) {
                    setFlash('قسم غير معروف','error');
                    redirect('admin.php?tab=control');
                }
                db()->prepare("INSERT INTO app_settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute(['show_'.$section, $enabled]);
                setFlash($enabled === '1' ? '✅ تم تفعيل القسم' : '✅ تم تعطيل القسم','success');
                redirect('admin.php?tab=control');

            case 'save_carousel_settings':
                $textKeys = ['carousel_speed','carousel_item_size'];
                $checkboxKeys = ['carousel_auto_scroll','carousel_pause_on_touch'];
                foreach ($textKeys as $k) {
                    $val = isset($_POST[$k]) ? trim($_POST[$k]) : '0.5';
                    db()->prepare("INSERT INTO content_settings (content_key,content_value,content_type,category) VALUES (?,?,'text','carousel') ON DUPLICATE KEY UPDATE content_value=VALUES(content_value)")->execute([$k, $val]);
                }
                foreach ($checkboxKeys as $k) {
                    $val = isset($_POST[$k]) && $_POST[$k] === '1' ? '1' : '0';
                    db()->prepare("INSERT INTO content_settings (content_key,content_value,content_type,category) VALUES (?,?,'text','carousel') ON DUPLICATE KEY UPDATE content_value=VALUES(content_value)")->execute([$k, $val]);
                }
                setFlash('✅ تم حفظ إعدادات الشريط','success');
                redirect('admin.php?tab=carousel');

            case 'save_content_settings':
                $allowedKeys = [
                    'site_title','site_subtitle','intro_text',
                    'section_reciters_title','section_recent_title','section_books_title','section_surahs_title',
                    'nav_home_label','nav_quran_label','nav_juz_label','nav_audio_label','nav_videos_label','nav_books_label',
                    'empty_reciters_msg','empty_books_msg','empty_videos_msg',
                    'btn_play','btn_download','btn_like','btn_share'
                ];
                foreach ($allowedKeys as $k) {
                    if (!isset($_POST[$k])) continue;
                    db()->prepare("INSERT INTO content_settings (content_key,content_value,content_type,category) VALUES (?,?,'text','general') ON DUPLICATE KEY UPDATE content_value=VALUES(content_value)")->execute([$k, trim($_POST[$k])]);
                }
                setFlash('✅ تم حفظ النصوص','success');
                redirect('admin.php?tab=content');

            case 'save_azkar_category':
                $id = (int)($_POST['category_id'] ?? 0);
                $name = trim($_POST['category_name'] ?? '');
                $icon = trim($_POST['category_icon'] ?? 'fa-hands-praying');
                $orderIndex = (int)($_POST['order_index'] ?? 0);
                $active = isset($_POST['active']) && $_POST['active'] === '1' ? 1 : 0;
                if (!$name) { setFlash('اسم القسم مطلوب','error'); redirect('admin.php?tab=azkar'); }
                if ($id > 0) {
                    db()->prepare("UPDATE azkar_categories SET name=?,icon=?,order_index=?,active=? WHERE id=?")->execute([$name,$icon,$orderIndex,$active,$id]);
                    setFlash('✅ تم تحديث القسم','success');
                } else {
                    db()->prepare("INSERT INTO azkar_categories (name,icon,order_index,active) VALUES (?,?,?,?)")->execute([$name,$icon,$orderIndex,$active]);
                    setFlash('✅ تم إضافة القسم','success');
                }
                redirect('admin.php?tab=azkar');

            case 'save_zikr':
                $id = (int)($_POST['zikr_id'] ?? 0);
                $categoryId = (int)($_POST['category_id'] ?? 0);
                $text = trim($_POST['zikr_text'] ?? '');
                $repeat = (int)($_POST['repeat_count'] ?? 1);
                $reward = trim($_POST['reward'] ?? '');
                $orderIndex = (int)($_POST['order_index'] ?? 0);
                if (!$categoryId || !$text) { setFlash('بيانات ناقصة','error'); redirect('admin.php?tab=azkar'); }
                if ($id > 0) {
                    db()->prepare("UPDATE azkar SET category_id=?,text=?,repeat_count=?,reward=?,order_index=? WHERE id=?")->execute([$categoryId,$text,$repeat,$reward,$orderIndex,$id]);
                    setFlash('✅ تم تحديث الذكر','success');
                } else {
                    db()->prepare("INSERT INTO azkar (category_id,text,repeat_count,reward,order_index) VALUES (?,?,?,?,?)")->execute([$categoryId,$text,$repeat,$reward,$orderIndex]);
                    setFlash('✅ تم إضافة الذكر','success');
                }
                redirect('admin.php?tab=azkar');

            case 'save_hadith':
                $id = (int)($_POST['hadith_id'] ?? 0);
                $title = trim($_POST['hadith_title'] ?? '');
                $text = trim($_POST['hadith_text'] ?? '');
                $narrator = trim($_POST['narrator'] ?? '');
                $source = trim($_POST['source'] ?? '');
                $orderIndex = (int)($_POST['order_index'] ?? 0);
                $active = isset($_POST['active']) && $_POST['active'] === '1' ? 1 : 0;
                if (!$text) { setFlash('نص الحديث مطلوب','error'); redirect('admin.php?tab=hadiths'); }
                if ($id > 0) {
                    db()->prepare("UPDATE hadiths SET title=?,text=?,narrator=?,source=?,order_index=?,active=? WHERE id=?")->execute([$title,$text,$narrator,$source,$orderIndex,$active,$id]);
                    setFlash('✅ تم تحديث الحديث','success');
                } else {
                    db()->prepare("INSERT INTO hadiths (title,text,narrator,source,order_index,active) VALUES (?,?,?,?,?,?)")->execute([$title,$text,$narrator,$source,$orderIndex,$active]);
                    setFlash('✅ تم إضافة الحديث','success');
                }
                redirect('admin.php?tab=hadiths');

            case 'save_app_icon':
                $id = (int)($_POST['icon_id'] ?? 0);
                $name = trim($_POST['icon_name'] ?? '');
                $icon = trim($_POST['icon_class'] ?? 'fa-star');
                $color = trim($_POST['icon_color'] ?? '#c9a959');
                $actionType = trim($_POST['action_type'] ?? 'internal');
                $link = trim($_POST['icon_link'] ?? '');
                $orderIndex = (int)($_POST['order_index'] ?? 0);
                $active = isset($_POST['active']) && $_POST['active'] === '1' ? 1 : 0;
                if (!$name) { setFlash('اسم الأيقونة مطلوب','error'); redirect('admin.php?tab=icons'); }
                if ($id > 0) {
                    db()->prepare("UPDATE app_icons SET name=?,icon=?,color=?,action_type=?,link=?,order_index=?,active=? WHERE id=?")->execute([$name,$icon,$color,$actionType,$link,$orderIndex,$active,$id]);
                    setFlash('✅ تم تحديث الأيقونة','success');
                } else {
                    db()->prepare("INSERT INTO app_icons (name,icon,color,action_type,link,order_index,active) VALUES (?,?,?,?,?,?,?)")->execute([$name,$icon,$color,$actionType,$link,$orderIndex,$active]);
                    setFlash('✅ تم إضافة الأيقونة','success');
                }
                redirect('admin.php?tab=icons');

            case 'smart_upload':
                $reciter_id = (int)($_POST['reciter_id'] ?? 0);
                $example_url = trim($_POST['example_url'] ?? '');
                if (!$reciter_id || !$example_url) { setFlash('بيانات ناقصة','error'); redirect('admin.php?tab=quran'); }
                if (!preg_match('/(\d+)\.mp3$/i', $example_url, $m)) { setFlash('الرابط غير صحيح','error'); redirect('admin.php?tab=quran'); }
                $maxNumber = (int)$m[1];
                $baseUrl = preg_replace('/\d+\.mp3$/i', '', $example_url);
                $added = 0;
                $check = db()->prepare("SELECT id FROM audios WHERE reciter_id=? AND surah_number=?");
                $insert = db()->prepare("INSERT INTO audios (reciter_id,surah_name,surah_number,audio_type,audio_url,file_path) VALUES (?,?,?,'url',?,'')");
                for ($i=1; $i<=$maxNumber; $i++) {
                    $sn = getSurahName($i);
                    if (!$sn) continue;
                    $check->execute([$reciter_id,$i]);
                    if (!$check->fetch()) {
                        $formatted = str_pad($i,3,'0',STR_PAD_LEFT);
                        $insert->execute([$reciter_id,$sn,$i,$baseUrl.$formatted.'.mp3']);
                        $added++;
                    }
                }
                setFlash("✅ تم إضافة {$added} سورة",'success');
                redirect('admin.php?tab=quran');

            case 'save_reciter':
                $id = (int)($_POST['reciter_id'] ?? 0);
                $name = trim($_POST['reciter_name'] ?? '');
                $image = trim($_POST['current_image'] ?? '');
                $isLocked = isset($_POST['is_locked']) && $_POST['is_locked'] === '1' ? 1 : 0;
                $lockMessage = trim($_POST['lock_message'] ?? 'سيتم إضافته قريباً');
                if (!$name) { setFlash('اسم القارئ مطلوب','error'); redirect('admin.php?tab=reciters'); }
                if (!empty($_FILES['reciter_image']['name']) && $_FILES['reciter_image']['error']===UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($_FILES['reciter_image']['name'],PATHINFO_EXTENSION));
                    if (in_array($ext,['jpg','jpeg','png','gif','webp'])) {
                        if ($image && file_exists(UPLOAD_PATH.'/'.$image)) safeDelete(UPLOAD_PATH.'/'.$image);
                        ensureDir(UPLOAD_PATH);
                        $image = 'reciter_'.time().'_'.random_int(1000,9999).'.'.$ext;
                        move_uploaded_file($_FILES['reciter_image']['tmp_name'],UPLOAD_PATH.'/'.$image);
                        compressImage(UPLOAD_PATH.'/'.$image,UPLOAD_PATH.'/'.$image,80);
                    }
                }
                if ($id>0) {
                    db()->prepare("UPDATE reciters SET name=?,image=?,is_locked=?,lock_message=? WHERE id=?")->execute([$name,$image,$isLocked,$lockMessage,$id]);
                    setFlash('✅ تم تحديث القارئ','success');
                } else {
                    db()->prepare("INSERT INTO reciters (name,image,is_locked,lock_message) VALUES (?,?,?,?)")->execute([$name,$image,$isLocked,$lockMessage]);
                    setFlash('✅ تم إضافة القارئ','success');
                }
                redirect('admin.php?tab=reciters');

            case 'save_reel_reciter':
                $id = (int)($_POST['reciter_id'] ?? 0);
                $name = trim($_POST['name'] ?? '');
                $username = trim($_POST['username'] ?? '');
                $bio = trim($_POST['bio'] ?? '');
                $image = trim($_POST['current_image'] ?? '');
                if (!$name) { setFlash('الاسم مطلوب','error'); redirect('admin.php?tab=reel_reciters'); }
                if (!empty($_FILES['reciter_image']['name']) && $_FILES['reciter_image']['error']===UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($_FILES['reciter_image']['name'],PATHINFO_EXTENSION));
                    if (in_array($ext,['jpg','jpeg','png','gif','webp'])) {
                        if ($image && file_exists(REEL_RECITERS_PATH.'/'.$image)) safeDelete(REEL_RECITERS_PATH.'/'.$image);
                        ensureDir(REEL_RECITERS_PATH);
                        $image = 'reel_'.time().'_'.random_int(1000,9999).'.'.$ext;
                        move_uploaded_file($_FILES['reciter_image']['tmp_name'],REEL_RECITERS_PATH.'/'.$image);
                        compressImage(REEL_RECITERS_PATH.'/'.$image,REEL_RECITERS_PATH.'/'.$image,80);
                    }
                }
                if ($id>0) {
                    db()->prepare("UPDATE reel_reciters SET name=?,username=?,image=?,bio=? WHERE id=?")->execute([$name,$username,$image,$bio,$id]);
                    setFlash('✅ تم تحديث القارئ','success');
                } else {
                    db()->prepare("INSERT INTO reel_reciters (name,username,image,bio) VALUES (?,?,?,?)")->execute([$name,$username,$image,$bio]);
                    setFlash('✅ تم إضافة القارئ','success');
                }
                redirect('admin.php?tab=reel_reciters');

            case 'save_audio':
                $id = (int)($_POST['audio_id'] ?? 0);
                $reciterId = (int)($_POST['reciter_id'] ?? 0);
                $surahName = trim($_POST['surah_name'] ?? '');
                $surahNumber = (int)($_POST['surah_number'] ?? 0);
                $audioType = ($_POST['audio_type'] ?? 'url')==='file'?'file':'url';
                $audioUrl = trim($_POST['audio_url'] ?? '');
                $filePath = trim($_POST['current_file_path'] ?? '');
                if (!$reciterId || !$surahName) { setFlash('بيانات ناقصة','error'); redirect('admin.php?tab=quran'); }
                if ($audioType==='file') {
                    if (!empty($_FILES['audio_file']['name']) && $_FILES['audio_file']['error']===UPLOAD_ERR_OK) {
                        $ext = strtolower(pathinfo($_FILES['audio_file']['name'],PATHINFO_EXTENSION));
                        if ($filePath && file_exists(UPLOAD_PATH.'/'.$filePath)) safeDelete(UPLOAD_PATH.'/'.$filePath);
                        ensureDir(UPLOAD_PATH);
                        $filePath = 'audio_'.time().'_'.random_int(1000,9999).'.'.$ext;
                        move_uploaded_file($_FILES['audio_file']['tmp_name'],UPLOAD_PATH.'/'.$filePath);
                    }
                    $audioUrl = '';
                } else {
                    if ($filePath && file_exists(UPLOAD_PATH.'/'.$filePath)) safeDelete(UPLOAD_PATH.'/'.$filePath);
                    $filePath = '';
                }
                if ($id>0) {
                    db()->prepare("UPDATE audios SET reciter_id=?,surah_name=?,surah_number=?,audio_type=?,audio_url=?,file_path=? WHERE id=?")->execute([$reciterId,$surahName,$surahNumber,$audioType,$audioUrl,$filePath,$id]);
                    setFlash('✅ تم تحديث السورة','success');
                } else {
                    db()->prepare("INSERT INTO audios (reciter_id,surah_name,surah_number,audio_type,audio_url,file_path) VALUES (?,?,?,?,?,?)")->execute([$reciterId,$surahName,$surahNumber,$audioType,$audioUrl,$filePath]);
                    setFlash('✅ تم إضافة السورة','success');
                }
                redirect('admin.php?tab=quran');

            case 'save_video':
                $id = (int)($_POST['video_id'] ?? 0);
                $title = trim($_POST['video_title'] ?? '');
                $videoType = ($_POST['video_type'] ?? 'url')==='file'?'file':'url';
                $videoUrl = trim($_POST['video_url'] ?? '');
                $filePath = trim($_POST['current_file_path'] ?? '');
                $thumbnailPath = '';
                $sortOrder = (int)($_POST['sort_order'] ?? 0);
                $videoDuration = $_POST['video_duration'] ?? '00:00';
                $reelReciterId = !empty($_POST['reel_reciter_id']) ? (int)$_POST['reel_reciter_id'] : null;
                if (!$title) { setFlash('العنوان مطلوب','error'); redirect('admin.php?tab=videos'); }
                if (!empty($_FILES['video_thumbnail']['name']) && $_FILES['video_thumbnail']['error']===UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($_FILES['video_thumbnail']['name'],PATHINFO_EXTENSION));
                    ensureDir(THUMBNAILS_PATH);
                    $thumbnailPath = 'thumb_'.time().'_'.random_int(1000,9999).'.'.$ext;
                    move_uploaded_file($_FILES['video_thumbnail']['tmp_name'],THUMBNAILS_PATH.'/'.$thumbnailPath);
                    compressImage(THUMBNAILS_PATH.'/'.$thumbnailPath,THUMBNAILS_PATH.'/'.$thumbnailPath,80);
                }
                if ($videoType==='file') {
                    if (!empty($_FILES['video_file']['name']) && $_FILES['video_file']['error']===UPLOAD_ERR_OK) {
                        $ext = strtolower(pathinfo($_FILES['video_file']['name'],PATHINFO_EXTENSION));
                        if ($filePath && file_exists(UPLOAD_PATH.'/'.$filePath)) safeDelete(UPLOAD_PATH.'/'.$filePath);
                        ensureDir(UPLOAD_PATH);
                        $filePath = 'vid_'.time().'_'.random_int(1000,9999).'.'.$ext;
                        move_uploaded_file($_FILES['video_file']['tmp_name'],UPLOAD_PATH.'/'.$filePath);
                    }
                    $videoUrl = '';
                } else {
                    if ($filePath && file_exists(UPLOAD_PATH.'/'.$filePath)) safeDelete(UPLOAD_PATH.'/'.$filePath);
                    $filePath = '';
                }
                if ($id>0) {
                    db()->prepare("UPDATE videos SET title=?,video_type=?,video_url=?,file_path=?,sort_order=?,thumbnail_path=COALESCE(NULLIF(?,''),thumbnail_path),video_duration=?,reel_reciter_id=? WHERE id=?")->execute([$title,$videoType,$videoUrl,$filePath,$sortOrder,$thumbnailPath,$videoDuration,$reelReciterId,$id]);
                    setFlash('✅ تم تحديث الفيديو','success');
                } else {
                    db()->prepare("INSERT INTO videos (title,video_type,video_url,file_path,sort_order,thumbnail_path,video_duration,reel_reciter_id) VALUES (?,?,?,?,?,?,?,?)")->execute([$title,$videoType,$videoUrl,$filePath,$sortOrder,$thumbnailPath,$videoDuration,$reelReciterId]);
                    if ($reelReciterId) {
                        db()->prepare("UPDATE reel_reciters SET total_videos=(SELECT COUNT(*) FROM videos WHERE reel_reciter_id=?) WHERE id=?")->execute([$reelReciterId,$reelReciterId]);
                    }
                    setFlash('✅ تم نشر الفيديو','success');
                }
                redirect('admin.php?tab=videos');

            case 'save_book':
                $id = (int)($_POST['book_id'] ?? 0);
                $title = trim($_POST['title'] ?? '');
                $author = trim($_POST['author'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $category = trim($_POST['category'] ?? 'أخرى');
                $pages = (int)($_POST['pages'] ?? 0);
                $sortOrder = (int)($_POST['sort_order'] ?? 0);
                $status = isset($_POST['status']) && $_POST['status'] === '1' ? 1 : 0;
                $coverImage = $_POST['current_cover'] ?? '';
                $pdfFile = $_POST['current_pdf'] ?? '';
                $pdfUrl = trim($_POST['pdf_url'] ?? '');
                $sourceType = ($_POST['source_type'] ?? 'file')==='url'?'url':'file';
                if (!$title || !$author) { setFlash('العنوان والمؤلف مطلوبان','error'); redirect('admin.php?tab=books'); }
                if (!empty($_FILES['cover_image']['name']) && $_FILES['cover_image']['error']===UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($_FILES['cover_image']['name'],PATHINFO_EXTENSION));
                    if (in_array($ext,['jpg','jpeg','png','gif','webp'])) {
                        if ($coverImage && file_exists(BOOKS_COVERS_PATH.'/'.$coverImage)) safeDelete(BOOKS_COVERS_PATH.'/'.$coverImage);
                        ensureDir(BOOKS_COVERS_PATH);
                        $coverImage = 'cover_'.time().'_'.random_int(1000,9999).'.'.$ext;
                        move_uploaded_file($_FILES['cover_image']['tmp_name'],BOOKS_COVERS_PATH.'/'.$coverImage);
                        compressImage(BOOKS_COVERS_PATH.'/'.$coverImage,BOOKS_COVERS_PATH.'/'.$coverImage,80);
                    }
                }
                if ($sourceType==='file') {
                    if (!empty($_FILES['pdf_file']['name']) && $_FILES['pdf_file']['error']===UPLOAD_ERR_OK) {
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime = finfo_file($finfo,$_FILES['pdf_file']['tmp_name']);
                        finfo_close($finfo);
                        if ($mime==='application/pdf') {
                            if ($pdfFile && file_exists(BOOKS_PDFS_PATH.'/'.$pdfFile)) safeDelete(BOOKS_PDFS_PATH.'/'.$pdfFile);
                            ensureDir(BOOKS_PDFS_PATH);
                            $pdfFile = 'book_'.time().'_'.random_int(1000,9999).'.pdf';
                            move_uploaded_file($_FILES['pdf_file']['tmp_name'],BOOKS_PDFS_PATH.'/'.$pdfFile);
                            $pdfUrl = '';
                        }
                    }
                } else {
                    if ($pdfFile && file_exists(BOOKS_PDFS_PATH.'/'.$pdfFile)) safeDelete(BOOKS_PDFS_PATH.'/'.$pdfFile);
                    $pdfFile = '';
                }
                if ($id>0) {
                    db()->prepare("UPDATE books SET title=?,author=?,description=?,category=?,cover_image=?,pdf_file=?,pdf_url=?,pages=?,sort_order=?,status=?,source_type=? WHERE id=?")->execute([$title,$author,$description,$category,$coverImage,$pdfFile,$pdfUrl,$pages,$sortOrder,$status,$sourceType,$id]);
                    setFlash('✅ تم تحديث الكتاب','success');
                } else {
                    db()->prepare("INSERT INTO books (title,author,description,category,cover_image,pdf_file,pdf_url,pages,sort_order,status,source_type) VALUES (?,?,?,?,?,?,?,?,?,?,?)")->execute([$title,$author,$description,$category,$coverImage,$pdfFile,$pdfUrl,$pages,$sortOrder,$status,$sourceType]);
                    setFlash('✅ تم إضافة الكتاب','success');
                }
                redirect('admin.php?tab=books');

            case 'delete_reciter':
            case 'delete_reel_reciter':
            case 'delete_audio':
            case 'delete_video':
            case 'delete_book':
            case 'delete_azkar_category':
            case 'delete_zikr':
            case 'delete_hadith':
            case 'delete_app_icon':
                $id = (int)($_GET['id'] ?? 0);
                if ($id<=0) { setFlash('معرّف غير صحيح','error'); redirect('admin.php'); }
                switch ($action) {
                    case 'delete_reciter':
                        $files = db()->query("SELECT file_path FROM audios WHERE reciter_id=$id")->fetchAll();
                        foreach ($files as $f) { if ($f['file_path'] && file_exists(UPLOAD_PATH.'/'.$f['file_path'])) safeDelete(UPLOAD_PATH.'/'.$f['file_path']); }
                        $img = db()->query("SELECT image FROM reciters WHERE id=$id")->fetchColumn();
                        if ($img && file_exists(UPLOAD_PATH.'/'.$img)) safeDelete(UPLOAD_PATH.'/'.$img);
                        db()->exec("DELETE FROM reciters WHERE id=$id");
                        setFlash('✅ تم حذف القارئ','success');
                        redirect('admin.php?tab=reciters');
                    case 'delete_reel_reciter':
                        $img = db()->query("SELECT image FROM reel_reciters WHERE id=$id")->fetchColumn();
                        if ($img && file_exists(REEL_RECITERS_PATH.'/'.$img)) safeDelete(REEL_RECITERS_PATH.'/'.$img);
                        db()->exec("DELETE FROM reel_reciters WHERE id=$id");
                        setFlash('✅ تم حذف القارئ','success');
                        redirect('admin.php?tab=reel_reciters');
                    case 'delete_audio':
                        $path = db()->query("SELECT file_path FROM audios WHERE id=$id")->fetchColumn();
                        if ($path && file_exists(UPLOAD_PATH.'/'.$path)) safeDelete(UPLOAD_PATH.'/'.$path);
                        db()->exec("DELETE FROM audios WHERE id=$id");
                        setFlash('✅ تم حذف السورة','success');
                        redirect('admin.php?tab=quran');
                    case 'delete_video':
                        $v = db()->query("SELECT file_path,thumbnail_path,reel_reciter_id FROM videos WHERE id=$id")->fetch();
                        if ($v) {
                            if ($v['file_path'] && file_exists(UPLOAD_PATH.'/'.$v['file_path'])) safeDelete(UPLOAD_PATH.'/'.$v['file_path']);
                            if ($v['thumbnail_path'] && file_exists(THUMBNAILS_PATH.'/'.$v['thumbnail_path'])) safeDelete(THUMBNAILS_PATH.'/'.$v['thumbnail_path']);
                            if ($v['reel_reciter_id']) db()->exec("UPDATE reel_reciters SET total_videos=(SELECT COUNT(*) FROM videos WHERE reel_reciter_id={$v['reel_reciter_id']}) WHERE id={$v['reel_reciter_id']}");
                        }
                        db()->exec("DELETE FROM videos WHERE id=$id");
                        setFlash('✅ تم حذف الفيديو','success');
                        redirect('admin.php?tab=videos');
                    case 'delete_book':
                        $b = db()->query("SELECT cover_image,pdf_file FROM books WHERE id=$id")->fetch();
                        if ($b) {
                            if ($b['cover_image'] && file_exists(BOOKS_COVERS_PATH.'/'.$b['cover_image'])) safeDelete(BOOKS_COVERS_PATH.'/'.$b['cover_image']);
                            if ($b['pdf_file'] && file_exists(BOOKS_PDFS_PATH.'/'.$b['pdf_file'])) safeDelete(BOOKS_PDFS_PATH.'/'.$b['pdf_file']);
                        }
                        db()->exec("DELETE FROM books WHERE id=$id");
                        setFlash('✅ تم حذف الكتاب','success');
                        redirect('admin.php?tab=books');
                    case 'delete_azkar_category':
                        db()->exec("DELETE FROM azkar_categories WHERE id=$id");
                        setFlash('✅ تم حذف القسم','success');
                        redirect('admin.php?tab=azkar');
                    case 'delete_zikr':
                        db()->exec("DELETE FROM azkar WHERE id=$id");
                        setFlash('✅ تم حذف الذكر','success');
                        redirect('admin.php?tab=azkar');
                    case 'delete_hadith':
                        db()->exec("DELETE FROM hadiths WHERE id=$id");
                        setFlash('✅ تم حذف الحديث','success');
                        redirect('admin.php?tab=hadiths');
                    case 'delete_app_icon':
                        db()->exec("DELETE FROM app_icons WHERE id=$id");
                        setFlash('✅ تم حذف الأيقونة','success');
                        redirect('admin.php?tab=icons');
                }
                break;

            case 'toggle_book':
                $id = (int)($_GET['id'] ?? 0);
                if ($id>0) { db()->exec("UPDATE books SET status=1-status WHERE id=$id"); setFlash('✅ تم تغيير حالة الكتاب','success'); }
                redirect('admin.php?tab=books');

            case 'update_reels_order':
                $type = ($_POST['reels_order_type'] ?? 'random')==='normal'?'normal':'random';
                db()->prepare("INSERT INTO app_settings (setting_key,setting_value) VALUES ('reels_order_type',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([$type]);
                setFlash('✅ تم تحديث ترتيب الريلزات','success');
                redirect('admin.php?tab=videos');

            case 'clear_cache':
                try {
                    if (function_exists('opcache_reset')) opcache_reset();
                    $tmpFiles = glob(sys_get_temp_dir() . '/quran_attempts/*.json');
                    if ($tmpFiles) array_map('unlink', $tmpFiles);
                    setFlash('✅ تم مسح الكاش','success');
                } catch (Throwable $e) { setFlash('خطأ: '.$e->getMessage(),'error'); }
                redirect('admin.php?tab=settings');

            case 'change_password':
                $current = $_POST['current_password'] ?? '';
                $new = $_POST['new_password'] ?? '';
                $confirm = $_POST['confirm_password'] ?? '';
                if (!password_verify($current, ADMIN_PASSWORD_HASH)) setFlash('كلمة المرور الحالية خاطئة','error');
                elseif (strlen($new) < 6) setFlash('كلمة المرور الجديدة قصيرة','error');
                elseif ($new !== $confirm) setFlash('كلمتا المرور غير متطابقتين','error');
                else {
                    $hash = password_hash($new, PASSWORD_BCRYPT);
                    file_put_contents(__DIR__ . '/.admin_hash', $hash);
                    setFlash('⚠️ احفظ الـ hash الجديد في config.php: '.$hash,'success');
                }
                redirect('admin.php?tab=security');

            case 'bulk_delete':
                $type = $_POST['bulk_type'] ?? '';
                $ids = $_POST['ids'] ?? [];
                if (!is_array($ids) || empty($ids)) { setFlash('لم تحدد عناصر','error'); redirect('admin.php'); }
                $ids = array_map('intval', $ids);
                $idsStr = implode(',', $ids);
                $map = ['books'=>'books','videos'=>'videos','audios'=>'audios','reciters'=>'reciters','reel_reciters'=>'reel_reciters'];
                if (isset($map[$type])) { db()->exec("DELETE FROM {$map[$type]} WHERE id IN ({$idsStr})"); setFlash('✅ تم الحذف الجماعي','success'); }
                redirect('admin.php?tab=' . ($_POST['return_tab'] ?? 'dashboard'));

            default:
                setFlash('إجراء غير معروف','error');
                redirect('admin.php');
        }
    } catch (Throwable $e) {
        setFlash('خطأ: '.$e->getMessage(),'error');
        redirect('admin.php');
    }
}

/* ============================================================
   جلب البيانات
   ============================================================ */
$csrf = csrfToken();
$flash = getFlash();
$currentTab = $_GET['tab'] ?? 'dashboard';

updateActiveSession();

try {
    $reciters      = db()->query("SELECT * FROM reciters ORDER BY id DESC")->fetchAll();
    $reelReciters  = db()->query("SELECT * FROM reel_reciters ORDER BY id DESC")->fetchAll();
    $books         = db()->query("SELECT * FROM books ORDER BY sort_order ASC, id DESC")->fetchAll();
    $videos        = db()->query("SELECT v.*, r.name as reciter_name FROM videos v LEFT JOIN reel_reciters r ON v.reel_reciter_id = r.id ORDER BY v.sort_order ASC, v.id DESC")->fetchAll();
    $audios        = db()->query("SELECT a.*, r.name as reciter_name FROM audios a JOIN reciters r ON a.reciter_id = r.id ORDER BY a.surah_number ASC LIMIT 500")->fetchAll();
    $showIntro     = db()->query("SELECT setting_value FROM settings WHERE setting_key='show_intro'")->fetchColumn() == '1';
    $reelsOrder    = db()->query("SELECT setting_value FROM app_settings WHERE setting_key='reels_order_type'")->fetchColumn() ?: 'random';

    $azkarCategories = db()->query("SELECT * FROM azkar_categories ORDER BY order_index ASC")->fetchAll();
    $azkar = db()->query("SELECT * FROM azkar ORDER BY category_id ASC, order_index ASC")->fetchAll();
    $hadiths = db()->query("SELECT * FROM hadiths ORDER BY order_index ASC, id DESC")->fetchAll();
    $appIcons = db()->query("SELECT * FROM app_icons ORDER BY order_index ASC")->fetchAll();

    $appSettings = [];
    try { $rows = db()->query("SELECT setting_key,setting_value FROM app_settings")->fetchAll(); foreach ($rows as $r) $appSettings[$r['setting_key']] = $r['setting_value']; } catch (Throwable $e) {}
    $contentSettings = [];
    try { $rows = db()->query("SELECT content_key,content_value FROM content_settings")->fetchAll(); foreach ($rows as $r) $contentSettings[$r['content_key']] = $r['content_value']; } catch (Throwable $e) {}
    $siteSettings = [];
    try { $rows = db()->query("SELECT setting_key,setting_value FROM settings")->fetchAll(); foreach ($rows as $r) $siteSettings[$r['setting_key']] = $r['setting_value']; } catch (Throwable $e) {}
} catch (Throwable $e) { die('خطأ في جلب البيانات: ' . $e->getMessage()); }

function cs_adm(string $key, string $default = ''): string { global $contentSettings; return $contentSettings[$key] ?? $default; }
function isSectionEnabled(string $section): bool { global $appSettings; return ($appSettings['show_'.$section] ?? '1') === '1'; }
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>لوحة التحكم - <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root{--gold:#c9a959;--gold-light:#e2c78a;--gold-dark:#a8893a;--dark:#0d2b35;--darker:#07131c;--bg:#f0f4f8;--card:#fff;--text:#1a2c38;--text-light:#64748b;--border:#e2e8f0;--success:#10b981;--danger:#ef4444;--warning:#f59e0b;--info:#3b82f6;--radius:14px;--radius-sm:10px;--shadow:0 4px 20px rgba(13,43,53,.08);--shadow-lg:0 12px 40px rgba(13,43,53,.15)}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{font-family:'Cairo',sans-serif;background:var(--bg);color:var(--text);line-height:1.6;overflow-x:hidden}
.sidebar{position:fixed;top:0;right:-300px;width:280px;height:100vh;background:linear-gradient(180deg,var(--dark),var(--darker));z-index:1000;transition:right .35s;display:flex;flex-direction:column;box-shadow:-4px 0 30px rgba(0,0,0,.2)}
.sidebar.open{right:0}
.sidebar-header{padding:22px 20px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(201,169,89,.15)}
.sidebar-header .logo{display:flex;align-items:center;gap:12px;color:var(--gold);font-weight:900;font-size:17px}
.sidebar-header .logo i{font-size:24px}
.sidebar-close{background:rgba(255,255,255,.08);border:none;color:#fff;width:32px;height:32px;border-radius:8px;cursor:pointer;display:none}
.sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto;display:flex;flex-direction:column;gap:4px}
.nav-section-title{font-size:11px;color:rgba(255,255,255,.35);font-weight:700;padding:12px 16px 6px;text-transform:uppercase;letter-spacing:.5px}
.nav-link{display:flex;align-items:center;gap:12px;padding:12px 16px;color:rgba(255,255,255,.7);text-decoration:none;border-radius:var(--radius-sm);transition:all .3s;font-weight:600;font-size:14px;position:relative;cursor:pointer}
.nav-link i{font-size:17px;width:22px;text-align:center}
.nav-link::before{content:'';position:absolute;right:0;top:0;height:100%;width:3px;background:var(--gold);transform:scaleY(0);transition:transform .3s}
.nav-link:hover{background:rgba(201,169,89,.1);color:var(--gold)}
.nav-link.active{background:linear-gradient(90deg,rgba(201,169,89,.2),transparent);color:var(--gold)}
.nav-link.active::before{transform:scaleY(1)}
.nav-link .nav-badge{margin-right:auto;background:var(--danger);color:#fff;font-size:10px;font-weight:700;padding:2px 8px;border-radius:30px}
.sidebar-footer{padding:16px;border-top:1px solid rgba(201,169,89,.15);display:flex;flex-direction:column;gap:10px}
.admin-info{display:flex;align-items:center;gap:10px;color:rgba(255,255,255,.8);font-size:14px;padding:8px 12px;background:rgba(201,169,89,.08);border-radius:var(--radius-sm)}
.admin-info i{color:var(--gold)}
.logout-btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:11px;background:rgba(239,68,68,.15);color:#fca5a5;text-decoration:none;border-radius:var(--radius-sm);font-weight:700;font-size:14px;transition:all .3s}
.logout-btn:hover{background:var(--danger);color:#fff}
.sidebar-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);backdrop-filter:blur(4px);z-index:999;opacity:0;pointer-events:none;transition:opacity .35s}
.sidebar-overlay.active{opacity:1;pointer-events:all}
.main-content{min-height:100vh;transition:margin-right .35s}
.top-header{background:var(--card);padding:16px 20px;display:flex;align-items:center;gap:16px;position:sticky;top:0;z-index:100;box-shadow:0 2px 15px rgba(13,43,53,.06);border-bottom:1px solid var(--border)}
.menu-toggle{background:var(--dark);border:none;color:var(--gold);width:42px;height:42px;border-radius:var(--radius-sm);cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.menu-toggle:hover{background:var(--gold);color:var(--dark)}
.top-header h1{flex:1;font-size:20px;font-weight:900;color:var(--dark)}
.live-indicator{display:flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(16,185,129,.1);color:var(--success);border-radius:30px;font-size:12px;font-weight:700}
.live-indicator i{font-size:8px;animation:pulseDot 1.5s infinite}
@keyframes pulseDot{0%,100%{opacity:1}50%{opacity:.5;transform:scale(1.3)}}
.header-btn{background:rgba(201,169,89,.1);border:1px solid rgba(201,169,89,.3);color:var(--gold-dark);width:38px;height:38px;border-radius:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s}
.header-btn:hover{background:var(--gold);color:#fff}
.tab-panel{display:none;padding:20px}
.tab-panel.active{display:block}
.panel-card{background:var(--card);border-radius:var(--radius);padding:24px;margin-bottom:20px;box-shadow:var(--shadow);border-right:4px solid var(--gold)}
.panel-card h2{font-size:17px;font-weight:900;color:var(--dark);margin-bottom:18px;padding-bottom:12px;border-bottom:2px solid var(--border);display:flex;align-items:center;gap:10px}
.panel-card h2 i{color:var(--gold)}
.panel-card h2 .badge-count{margin-right:auto;background:rgba(201,169,89,.15);color:var(--gold-dark);font-size:12px;font-weight:700;padding:3px 12px;border-radius:30px}
.hint{color:var(--text-light);font-size:13px;margin-bottom:14px}
.form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:16px}
.form-group{display:flex;flex-direction:column;gap:6px}
.form-group.full{grid-column:1/-1}
.form-group label{font-weight:700;font-size:13px}
.form-group input,.form-group select,.form-group textarea{padding:11px 14px;border:2px solid var(--border);border-radius:var(--radius-sm);font-family:inherit;font-size:14px;background:#fafbfc;width:100%;transition:all .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--gold);background:#fff;box-shadow:0 0 0 4px rgba(201,169,89,.12)}
.form-group textarea{resize:vertical;min-height:80px}
.form-group small{color:var(--text-light);font-size:11px}
.switch-label{display:inline-flex;align-items:center;gap:10px;cursor:pointer;font-weight:600;font-size:14px;user-select:none;position:relative}
.switch-label input[type="checkbox"]{display:none}
.switch{position:relative;width:46px;height:26px;background:#cbd5e1;border-radius:30px;transition:all .3s;flex-shrink:0}
.switch::after{content:'';position:absolute;top:3px;right:3px;width:20px;height:20px;background:#fff;border-radius:50%;transition:all .3s;box-shadow:0 2px 4px rgba(0,0,0,.2)}
.switch-label input[type="checkbox"]:checked + .switch{background:var(--gold)}
.switch-label input[type="checkbox"]:checked + .switch::after{right:calc(100% - 23px)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:11px 22px;border:none;border-radius:var(--radius-sm);font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;text-decoration:none;transition:all .3s}
.btn-primary{background:linear-gradient(135deg,var(--dark),#1a4755);color:#fff}
.btn-primary:hover{background:linear-gradient(135deg,var(--gold),var(--gold-dark));transform:translateY(-2px)}
.btn-success{background:linear-gradient(135deg,var(--success),#059669);color:#fff}
.btn-danger{background:linear-gradient(135deg,var(--danger),#dc2626);color:#fff}
.btn-warning{background:linear-gradient(135deg,var(--warning),#d97706);color:#fff}
.btn-sm{padding:8px 16px;font-size:13px}
.btn-icon{width:36px;height:36px;border-radius:8px;border:none;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;text-decoration:none;font-size:14px;margin:0 2px;transition:all .2s}
.btn-icon:hover{transform:scale(1.1)}
.btn-edit{background:rgba(245,158,11,.15);color:var(--warning)}
.btn-edit:hover{background:var(--warning);color:#fff}
.btn-delete{background:rgba(239,68,68,.15);color:var(--danger)}
.btn-delete:hover{background:var(--danger);color:#fff}
.btn-toggle{background:rgba(59,130,246,.15);color:var(--info)}
.alert{padding:14px 18px;border-radius:var(--radius-sm);margin:0 20px 20px;display:flex;align-items:center;gap:10px;font-weight:600;font-size:14px}
.alert-success{background:#ecfdf5;color:#065f46;border-right:4px solid var(--success)}
.alert-error{background:#fef2f2;color:#991b1b;border-right:4px solid var(--danger)}
.alert button{background:none;border:none;color:currentColor;opacity:.6;cursor:pointer;margin-right:auto;padding:4px}
.table-wrap{overflow-x:auto;border-radius:var(--radius-sm);border:1px solid var(--border)}
table{width:100%;border-collapse:collapse;font-size:14px;min-width:600px}
th{background:var(--dark);color:var(--gold);padding:14px 16px;text-align:right;font-weight:700;font-size:13px;white-space:nowrap}
td{padding:12px 16px;border-bottom:1px solid var(--border);vertical-align:middle}
tbody tr:hover{background:#f8fafc}
.thumb{width:48px;height:48px;object-fit:cover;border-radius:10px;border:2px solid var(--border)}
.thumb-book{width:50px;height:68px;object-fit:cover;border-radius:6px;border:2px solid var(--border)}
.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 12px;border-radius:30px;font-size:12px;font-weight:700}
.badge-success{background:rgba(16,185,129,.15);color:#047857}
.badge-danger{background:rgba(239,68,68,.15);color:#b91c1c}
.badge-info{background:rgba(59,130,246,.15);color:#1d4ed8}
.stats-loading{text-align:center;padding:60px 20px;color:var(--text-light)}
.stats-loading i{font-size:42px;color:var(--gold);margin-bottom:15px}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:24px}
.stat-card{background:linear-gradient(135deg,#fff,#f8fafc);border-radius:var(--radius);padding:20px;box-shadow:var(--shadow);position:relative;overflow:hidden;border:1px solid var(--border);transition:all .2s}
.stat-card::before{content:'';position:absolute;top:0;right:0;width:4px;height:100%;background:var(--gold)}
.stat-card:hover{transform:translateY(-5px);box-shadow:var(--shadow-lg)}
.stat-card .stat-icon{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,rgba(201,169,89,.15),rgba(201,169,89,.05));display:flex;align-items:center;justify-content:center;color:var(--gold);font-size:18px;margin-bottom:12px}
.stat-card .stat-number{font-size:28px;font-weight:900;color:var(--dark);line-height:1.1;direction:ltr;text-align:right}
.stat-card .stat-label{font-size:13px;color:var(--text-light);margin-top:4px;font-weight:600}
.stat-card.green::before{background:var(--success)}
.stat-card.green .stat-icon{background:rgba(16,185,129,.1);color:var(--success)}
.stat-card.blue::before{background:var(--info)}
.stat-card.blue .stat-icon{background:rgba(59,130,246,.1);color:var(--info)}
.stat-card.red::before{background:var(--danger)}
.stat-card.red .stat-icon{background:rgba(239,68,68,.1);color:var(--danger)}
.stat-card.purple::before{background:#8b5cf6}
.stat-card.purple .stat-icon{background:rgba(139,92,246,.1);color:#8b5cf6}
.charts-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;margin-top:20px}
.chart-card{background:var(--card);border-radius:var(--radius);padding:20px;box-shadow:var(--shadow);border:1px solid var(--border)}
.chart-card h3{font-size:15px;font-weight:900;color:var(--dark);margin-bottom:16px;display:flex;align-items:center;gap:8px}
.chart-card h3 i{color:var(--gold)}
.chart-card canvas{max-height:260px}
.toast{position:fixed;bottom:30px;left:50%;transform:translateX(-50%) translateY(120px);background:var(--dark);color:#fff;padding:14px 24px;border-radius:30px;font-weight:700;font-size:14px;z-index:10000;opacity:0;transition:all .4s;box-shadow:0 15px 40px rgba(0,0,0,.3);display:flex;align-items:center;gap:10px;max-width:90vw;border:2px solid var(--gold)}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.section-toggle-card{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;background:#fff;border-radius:var(--radius-sm);border:2px solid var(--border);margin-bottom:10px;transition:all .2s}
.section-toggle-card:hover{border-color:var(--gold)}
.section-toggle-card .section-info{display:flex;align-items:center;gap:14px;flex:1}
.section-toggle-card .section-icon{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.section-toggle-card.enabled .section-icon{background:rgba(16,185,129,.15);color:var(--success)}
.section-toggle-card.disabled .section-icon{background:rgba(239,68,68,.15);color:var(--danger)}
.section-toggle-card .section-text h4{font-size:15px;font-weight:700;color:var(--dark);margin-bottom:2px}
.section-toggle-card .section-text small{font-size:12px;color:var(--text-light)}
.section-toggle-card .section-status{display:flex;align-items:center;gap:8px}
.status-pill{padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700}
.status-pill.on{background:rgba(16,185,129,.15);color:var(--success)}
.status-pill.off{background:rgba(239,68,68,.15);color:var(--danger)}
.icon-picker-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(70px,1fr));gap:8px;max-height:200px;overflow-y:auto;padding:10px;background:#f8fafc;border-radius:var(--radius-sm);border:2px solid var(--border);margin-top:8px}
.icon-pick-item{aspect-ratio:1;display:flex;align-items:center;justify-content:center;background:#fff;border:2px solid var(--border);border-radius:8px;cursor:pointer;font-size:20px;color:var(--text);transition:all .2s}
.icon-pick-item:hover{background:var(--gold);color:#fff;border-color:var(--gold);transform:scale(1.1)}
.icon-pick-item.selected{background:var(--gold);color:#fff;border-color:var(--gold)}
.color-picker-row{display:flex;gap:8px;align-items:center}
.color-picker-row input[type="color"]{width:50px;height:44px;border:2px solid var(--border);border-radius:8px;cursor:pointer;background:#fff;padding:2px}
.zikr-item{padding:14px 18px;background:#f8fafc;border-radius:10px;margin-bottom:10px;border-right:3px solid var(--gold);display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
.zikr-item .zikr-text{flex:1;font-size:15px;line-height:1.8}
.zikr-item .zikr-meta{font-size:12px;color:var(--text-light);margin-top:6px}
.zikr-item .zikr-actions{display:flex;gap:4px}
@media(min-width:1024px){
    .sidebar{right:0}
    .main-content{margin-right:280px}
    .menu-toggle,.sidebar-close{display:none}
    .sidebar-overlay{display:none}
}
@media(max-width:768px){
    .panel-card{padding:18px 16px}
    .form-grid{grid-template-columns:1fr}
    .stat-card{padding:16px}
    .stat-card .stat-number{font-size:22px}
    .top-header h1{font-size:17px}
    .live-indicator{display:none}
    .sidebar-close{display:flex;align-items:center;justify-content:center}
    .section-toggle-card{flex-direction:column;gap:12px;align-items:stretch}
}
::-webkit-scrollbar{width:8px;height:8px}
::-webkit-scrollbar-track{background:#f1f5f9}
::-webkit-scrollbar-thumb{background:var(--gold);border-radius:10px}
</style>
</head>
<body data-csrf="<?= $csrf ?>">

<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo"><i class="fas fa-quran"></i><span>لوحة التحكم</span></div>
        <button class="sidebar-close" onclick="toggleSidebar()"><i class="fas fa-times"></i></button>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section-title">الرئيسية</div>
        <a class="nav-link <?= $currentTab==='dashboard'?'active':'' ?>" data-tab="dashboard"><i class="fas fa-chart-line"></i><span>الإحصائيات</span></a>
        <a class="nav-link <?= $currentTab==='control'?'active':'' ?>" data-tab="control"><i class="fas fa-sliders-h"></i><span>التحكم الكامل</span></a>
        <a class="nav-link <?= $currentTab==='content'?'active':'' ?>" data-tab="content"><i class="fas fa-edit"></i><span>تحرير المحتوى</span></a>
        <a class="nav-link <?= $currentTab==='carousel'?'active':'' ?>" data-tab="carousel"><i class="fas fa-film"></i><span>شريط القراء</span></a>

        <div class="nav-section-title">محتوى ديني</div>
        <a class="nav-link <?= $currentTab==='azkar'?'active':'' ?>" data-tab="azkar"><i class="fas fa-hands-praying"></i><span>الأذكار</span><span class="nav-badge"><?= count($azkar) ?></span></a>
        <a class="nav-link <?= $currentTab==='hadiths'?'active':'' ?>" data-tab="hadiths"><i class="fas fa-book-open"></i><span>الأحاديث</span><span class="nav-badge"><?= count($hadiths) ?></span></a>
        <a class="nav-link <?= $currentTab==='icons'?'active':'' ?>" data-tab="icons"><i class="fas fa-th"></i><span>الأيقونات</span><span class="nav-badge"><?= count($appIcons) ?></span></a>

        <div class="nav-section-title">إدارة المحتوى</div>
        <a class="nav-link <?= $currentTab==='reciters'?'active':'' ?>" data-tab="reciters"><i class="fas fa-microphone"></i><span>قراء الصوتيات</span><span class="nav-badge"><?= count($reciters) ?></span></a>
        <a class="nav-link <?= $currentTab==='reel_reciters'?'active':'' ?>" data-tab="reel_reciters"><i class="fas fa-users"></i><span>قراء الريلزات</span><span class="nav-badge"><?= count($reelReciters) ?></span></a>
        <a class="nav-link <?= $currentTab==='quran'?'active':'' ?>" data-tab="quran"><i class="fas fa-book-quran"></i><span>السور الصوتية</span></a>
        <a class="nav-link <?= $currentTab==='videos'?'active':'' ?>" data-tab="videos"><i class="fas fa-video"></i><span>الريلزات</span><span class="nav-badge"><?= count($videos) ?></span></a>
        <a class="nav-link <?= $currentTab==='books'?'active':'' ?>" data-tab="books"><i class="fas fa-book"></i><span>الكتب</span><span class="nav-badge"><?= count($books) ?></span></a>

        <div class="nav-section-title">النظام</div>
        <a class="nav-link <?= $currentTab==='settings'?'active':'' ?>" data-tab="settings"><i class="fas fa-cog"></i><span>الإعدادات</span></a>
        <a class="nav-link <?= $currentTab==='security'?'active':'' ?>" data-tab="security"><i class="fas fa-shield-alt"></i><span>الأمان</span></a>
    </nav>
    <div class="sidebar-footer">
        <div class="admin-info"><i class="fas fa-user-shield"></i><span><?= sanitize($_SESSION['admin_username'] ?? 'admin') ?></span></div>
        <a href="admin.php?logout=1" class="logout-btn"><i class="fas fa-sign-out-alt"></i> خروج</a>
    </div>
</aside>
<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<main class="main-content">
<header class="top-header">
    <button class="menu-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
    <h1 id="pageTitle">الإحصائيات</h1>
    <div class="header-actions">
        <button class="header-btn" onclick="window.open('index.php','_blank')" title="عرض الموقع"><i class="fas fa-external-link-alt"></i></button>
        <span class="live-indicator"><i class="fas fa-circle"></i> متصل</span>
    </div>
</header>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>">
    <i class="fas fa-<?= $flash['type']==='success'?'check-circle':'exclamation-circle' ?>"></i>
    <?= sanitize($flash['message']) ?>
    <button onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
</div>
<?php endif; ?>

<!-- الإحصائيات -->
<section class="tab-panel <?= $currentTab==='dashboard'?'active':'' ?>" id="tab-dashboard">
    <div id="statsContent" class="stats-loading"><i class="fas fa-spinner fa-spin"></i><p>جاري تحميل الإحصائيات...</p></div>
</section>

<!-- التحكم الكامل -->
<section class="tab-panel <?= $currentTab==='control'?'active':'' ?>" id="tab-control">
    <div class="panel-card">
        <h2><i class="fas fa-palette"></i> نصوص وعناوين الموقع</h2>
        <form method="POST" action="admin.php?action=save_control" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label>عنوان الموقع</label><input type="text" name="site_title" value="<?= sanitize($appSettings['site_title'] ?? 'القرآن الكريم') ?>"></div>
                <div class="form-group"><label>العنوان الفرعي</label><input type="text" name="site_subtitle" value="<?= sanitize($appSettings['site_subtitle'] ?? '') ?>"></div>
                <div class="form-group"><label>عنوان البانر</label><input type="text" name="hero_title" value="<?= sanitize($appSettings['hero_title'] ?? '') ?>"></div>
                <div class="form-group full"><label>نص التذييل</label><input type="text" name="footer_text" value="<?= sanitize($appSettings['footer_text'] ?? '') ?>"></div>
                <div class="form-group"><label>اللون الأساسي</label><input type="text" name="primary_color" value="<?= sanitize($appSettings['primary_color'] ?? '#c9a959') ?>"></div>
                <div class="form-group"><label>اللون الثانوي</label><input type="text" name="accent_color" value="<?= sanitize($appSettings['accent_color'] ?? '#0d2b35') ?>"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> حفظ النصوص</button>
        </form>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-image"></i> خلفيات مواقيت الصلاة</h2>
        <form method="POST" action="admin.php?action=save_control" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label>🌅 خلفية الفجر</label><input type="url" name="bg_fajr" value="<?= sanitize($appSettings['bg_fajr'] ?? '') ?>"></div>
                <div class="form-group"><label>🌄 خلفية الشروق</label><input type="url" name="bg_sunrise" value="<?= sanitize($appSettings['bg_sunrise'] ?? '') ?>"></div>
                <div class="form-group"><label>☀️ خلفية الظهر</label><input type="url" name="bg_dhuhr" value="<?= sanitize($appSettings['bg_dhuhr'] ?? '') ?>"></div>
                <div class="form-group"><label>🌤️ خلفية العصر</label><input type="url" name="bg_asr" value="<?= sanitize($appSettings['bg_asr'] ?? '') ?>"></div>
                <div class="form-group"><label>🌆 خلفية المغرب</label><input type="url" name="bg_maghrib" value="<?= sanitize($appSettings['bg_maghrib'] ?? '') ?>"></div>
                <div class="form-group"><label>🌙 خلفية العشاء</label><input type="url" name="bg_isha" value="<?= sanitize($appSettings['bg_isha'] ?? '') ?>"></div>
                <div class="form-group"><label>🌃 خلفية افتراضية</label><input type="url" name="bg_default" value="<?= sanitize($appSettings['bg_default'] ?? '') ?>"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> حفظ الخلفيات</button>
        </form>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-toggle-on"></i> تفعيل/تعطيل أقسام الموقع</h2>
        <?php
        $allSections = [
            'books' => ['label' => '📚 الكتب', 'icon' => 'fa-book', 'desc' => 'قسم عرض الكتب'],
            'videos' => ['label' => '🎬 الريلزات', 'icon' => 'fa-video', 'desc' => 'قسم الفيديوهات'],
            'audio' => ['label' => '🎧 الصوتيات', 'icon' => 'fa-headphones', 'desc' => 'قسم القراء والسور'],
            'reciters' => ['label' => '🎤 شريط القراء', 'icon' => 'fa-microphone', 'desc' => 'شريط القراء'],
            'prayer' => ['label' => '🕌 مواقيت الصلاة', 'icon' => 'fa-clock', 'desc' => 'مواقيت الصلاة'],
            'surahs' => ['label' => '📖 القرآن الكريم', 'icon' => 'fa-book-quran', 'desc' => 'قسم القرآن'],
            'azkar' => ['label' => '📿 الأذكار', 'icon' => 'fa-hands-praying', 'desc' => 'قسم الأذكار'],
            'tasbih' => ['label' => '📿 المسبحة', 'icon' => 'fa-circle-dot', 'desc' => 'المسبحة الإلكترونية'],
            'hadith' => ['label' => '📖 الأحاديث', 'icon' => 'fa-book-open', 'desc' => 'الأحاديث النبوية'],
            'calendar' => ['label' => '📅 التقويم', 'icon' => 'fa-calendar', 'desc' => 'التقويم الهجري']
        ];
        foreach ($allSections as $key => $info):
            $enabled = isSectionEnabled($key);
        ?>
        <div class="section-toggle-card <?= $enabled ? 'enabled' : 'disabled' ?>">
            <div class="section-info">
                <div class="section-icon"><i class="fas <?= $info['icon'] ?>"></i></div>
                <div class="section-text"><h4><?= $info['label'] ?></h4><small><?= $info['desc'] ?></small></div>
            </div>
            <div class="section-status">
                <span class="status-pill <?= $enabled ? 'on' : 'off' ?>"><?= $enabled ? 'مفعّل' : 'معطّل' ?></span>
                <a href="admin.php?action=toggle_section&section=<?= $key ?>&enabled=<?= $enabled ? '0' : '1' ?>" class="btn btn-sm <?= $enabled ? 'btn-danger' : 'btn-success' ?>">
                    <i class="fas fa-<?= $enabled ? 'eye-slash' : 'eye' ?>"></i> <?= $enabled ? 'تعطيل' : 'تفعيل' ?>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- تحرير المحتوى -->
<section class="tab-panel <?= $currentTab==='content'?'active':'' ?>" id="tab-content">
    <div class="panel-card">
        <h2><i class="fas fa-edit"></i> تحرير النصوص</h2>
        <form method="POST" action="admin.php?action=save_content_settings" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label>عنوان الموقع</label><input type="text" name="site_title" value="<?= sanitize(cs_adm('site_title','القرآن الكريم')) ?>"></div>
                <div class="form-group"><label>نص شاشة الترحيب</label><input type="text" name="intro_text" value="<?= sanitize(cs_adm('intro_text','القرآن الكريم')) ?>"></div>
                <div class="form-group"><label>عنوان قسم القراء</label><input type="text" name="section_reciters_title" value="<?= sanitize(cs_adm('section_reciters_title','القراء')) ?>"></div>
                <div class="form-group"><label>عنوان قسم الحديث</label><input type="text" name="section_recent_title" value="<?= sanitize(cs_adm('section_recent_title','أضيف حديثاً')) ?>"></div>
                <div class="form-group"><label>نص زر الرئيسية</label><input type="text" name="nav_home_label" value="<?= sanitize(cs_adm('nav_home_label','الرئيسية')) ?>"></div>
                <div class="form-group"><label>نص زر القرآن</label><input type="text" name="nav_quran_label" value="<?= sanitize(cs_adm('nav_quran_label','القرآن')) ?>"></div>
                <div class="form-group"><label>نص زر الأجزاء</label><input type="text" name="nav_juz_label" value="<?= sanitize(cs_adm('nav_juz_label','أجزاء')) ?>"></div>
                <div class="form-group"><label>نص زر الصوتيات</label><input type="text" name="nav_audio_label" value="<?= sanitize(cs_adm('nav_audio_label','صوتيات')) ?>"></div>
                <div class="form-group"><label>نص زر الريلزات</label><input type="text" name="nav_videos_label" value="<?= sanitize(cs_adm('nav_videos_label','ريلز')) ?>"></div>
                <div class="form-group"><label>نص زر الكتب</label><input type="text" name="nav_books_label" value="<?= sanitize(cs_adm('nav_books_label','كتب')) ?>"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> حفظ النصوص</button>
        </form>
    </div>
</section>

<!-- شريط القراء -->
<section class="tab-panel <?= $currentTab==='carousel'?'active':'' ?>" id="tab-carousel">
    <div class="panel-card">
        <h2><i class="fas fa-film"></i> إعدادات شريط القراء</h2>
        <form method="POST" action="admin.php?action=save_carousel_settings" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label>حجم عنصر الشريط (px)</label><input type="number" name="carousel_item_size" value="<?= sanitize(cs_adm('carousel_item_size','82')) ?>" min="60" max="140"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> حفظ</button>
        </form>
    </div>
</section>

<!-- الأذكار -->
<section class="tab-panel <?= $currentTab==='azkar'?'active':'' ?>" id="tab-azkar">
    <div class="panel-card">
        <h2><i class="fas fa-folder-plus"></i> <span id="azkarCatFormTitle">إضافة قسم أذكار</span></h2>
        <form method="POST" action="admin.php?action=save_azkar_category" class="ajax-form" id="azkarCatForm">
            <?= csrfField() ?>
            <input type="hidden" name="category_id" value="">
            <div class="form-grid">
                <div class="form-group"><label>اسم القسم *</label><input type="text" name="category_name" required></div>
                <div class="form-group"><label>الأيقونة</label><input type="text" name="category_icon" value="fa-hands-praying" id="catIconInput"></div>
                <div class="form-group"><label>الترتيب</label><input type="number" name="order_index" value="0"></div>
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="active" value="1" checked><span class="switch"></span> مفعّل</label></div>
            </div>
            <div>
                <label style="font-weight:700;font-size:13px">اختر أيقونة:</label>
                <div class="icon-picker-grid" id="catIconPicker">
                    <?php
                    $iconList = ['fa-hands-praying','fa-sun','fa-moon','fa-cloud-sun','fa-restroom','fa-tint','fa-door-open','fa-home','fa-plane','fa-mosque','fa-users','fa-utensils','fa-book','fa-book-open','fa-star','fa-heart','fa-clock','fa-calendar','fa-circle-dot','fa-quran'];
                    foreach ($iconList as $ic): ?>
                    <div class="icon-pick-item" data-icon="<?= $ic ?>" onclick="pickIcon(this,'catIconInput')"><i class="fas <?= $ic ?>"></i></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> <span>إضافة قسم</span></button>
            <button type="button" class="btn btn-danger" onclick="resetAzkarCatForm()" style="display:none" id="azkarCatResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-list"></i> أقسام الأذكار <span class="badge-count"><?= count($azkarCategories) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>الأيقونة</th><th>الاسم</th><th>الترتيب</th><th>الحالة</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($azkarCategories as $cat): ?>
                <tr>
                    <td><i class="fas <?= sanitize($cat['icon']) ?> fa-2x" style="color:#c9a959"></i></td>
                    <td><strong><?= sanitize($cat['name']) ?></strong></td>
                    <td><?= (int)$cat['order_index'] ?></td>
                    <td><?= $cat['active'] ? '<span class="badge badge-success">مفعّل</span>' : '<span class="badge badge-danger">معطّل</span>' ?></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editAzkarCat(<?= json_encode($cat,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=delete_azkar_category&id=<?= $cat['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-plus-circle"></i> <span id="zikrFormTitle">إضافة ذكر</span></h2>
        <form method="POST" action="admin.php?action=save_zikr" class="ajax-form" id="zikrForm">
            <?= csrfField() ?>
            <input type="hidden" name="zikr_id" value="">
            <div class="form-grid">
                <div class="form-group">
                    <label>القسم *</label>
                    <select name="category_id" required>
                        <?php foreach ($azkarCategories as $cat): ?>
                        <option value="<?= $cat['id'] ?>"><?= sanitize($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>عدد التكرار</label><input type="number" name="repeat_count" value="1" min="1"></div>
                <div class="form-group"><label>الترتيب</label><input type="number" name="order_index" value="0"></div>
                <div class="form-group full"><label>نص الذكر *</label><textarea name="zikr_text" rows="4" required></textarea></div>
                <div class="form-group full"><label>الفضل (اختياري)</label><input type="text" name="reward"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <span>حفظ</span></button>
            <button type="button" class="btn btn-danger" onclick="resetZikrForm()" style="display:none" id="zikrResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-list"></i> الأذكار <span class="badge-count"><?= count($azkar) ?></span></h2>
        <div style="max-height:600px;overflow-y:auto">
            <?php foreach ($azkar as $z): 
                $catName = '';
                foreach ($azkarCategories as $c) { if ($c['id'] == $z['category_id']) { $catName = $c['name']; break; } }
            ?>
            <div class="zikr-item">
                <div>
                    <div class="zikr-text"><?= nl2br(sanitize($z['text'])) ?></div>
                    <div class="zikr-meta">📁 <?= sanitize($catName) ?> • 🔄 <?= (int)$z['repeat_count'] ?> مرة</div>
                    <?php if ($z['reward']): ?><div class="zikr-meta">🌟 <?= sanitize($z['reward']) ?></div><?php endif; ?>
                </div>
                <div class="zikr-actions">
                    <button type="button" class="btn-icon btn-edit" onclick='editZikr(<?= json_encode($z,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                    <a href="admin.php?action=delete_zikr&id=<?= $z['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- الأحاديث -->
<section class="tab-panel <?= $currentTab==='hadiths'?'active':'' ?>" id="tab-hadiths">
    <div class="panel-card">
        <h2><i class="fas fa-plus-circle"></i> <span id="hadithFormTitle">إضافة حديث</span></h2>
        <form method="POST" action="admin.php?action=save_hadith" class="ajax-form" id="hadithForm">
            <?= csrfField() ?>
            <input type="hidden" name="hadith_id" value="">
            <div class="form-grid">
                <div class="form-group"><label>عنوان الحديث</label><input type="text" name="hadith_title"></div>
                <div class="form-group"><label>الراوي</label><input type="text" name="narrator" placeholder="أبو هريرة رضي الله عنه"></div>
                <div class="form-group"><label>المصدر</label><input type="text" name="source" placeholder="صحيح البخاري"></div>
                <div class="form-group"><label>الترتيب</label><input type="number" name="order_index" value="0"></div>
                <div class="form-group full"><label>نص الحديث *</label><textarea name="hadith_text" rows="5" required></textarea></div>
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="active" value="1" checked><span class="switch"></span> مفعّل</label></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <span>حفظ</span></button>
            <button type="button" class="btn btn-danger" onclick="resetHadithForm()" style="display:none" id="hadithResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-list"></i> الأحاديث <span class="badge-count"><?= count($hadiths) ?></span></h2>
        <div style="max-height:600px;overflow-y:auto">
            <?php foreach ($hadiths as $h): ?>
            <div class="zikr-item">
                <div>
                    <?php if ($h['title']): ?><div style="font-weight:700;color:#c9a959;margin-bottom:6px"><?= sanitize($h['title']) ?></div><?php endif; ?>
                    <div class="zikr-text"><?= nl2br(sanitize($h['text'])) ?></div>
                    <div class="zikr-meta">
                        <?php if ($h['narrator']): ?>👤 <?= sanitize($h['narrator']) ?><?php endif; ?>
                        <?php if ($h['source']): ?> • 📚 <?= sanitize($h['source']) ?><?php endif; ?>
                    </div>
                </div>
                <div class="zikr-actions">
                    <button type="button" class="btn-icon btn-edit" onclick='editHadith(<?= json_encode($h,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                    <a href="admin.php?action=delete_hadith&id=<?= $h['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- الأيقونات -->
<section class="tab-panel <?= $currentTab==='icons'?'active':'' ?>" id="tab-icons">
    <div class="panel-card">
        <h2><i class="fas fa-plus-circle"></i> <span id="iconFormTitle">إضافة أيقونة</span></h2>
        <p class="hint">الأيقونات تظهر تحت شريط "أضيف حديثاً"</p>
        <form method="POST" action="admin.php?action=save_app_icon" class="ajax-form" id="appIconForm">
            <?= csrfField() ?>
            <input type="hidden" name="icon_id" value="">
            <div class="form-grid">
                <div class="form-group"><label>الاسم *</label><input type="text" name="icon_name" required></div>
                <div class="form-group"><label>الأيقونة</label><input type="text" name="icon_class" value="fa-star" id="appIconInput"></div>
                <div class="form-group"><label>اللون</label><div class="color-picker-row"><input type="color" name="icon_color" value="#c9a959"></div></div>
                <div class="form-group">
                    <label>نوع الإجراء</label>
                    <select name="action_type">
                        <option value="azkar">الأذكار</option>
                        <option value="tasbih">المسبحة</option>
                        <option value="hadith">الأحاديث</option>
                        <option value="calendar">التقويم</option>
                        <option value="link">رابط خارجي</option>
                    </select>
                </div>
                <div class="form-group"><label>الرابط (للخارجي)</label><input type="url" name="icon_link"></div>
                <div class="form-group"><label>الترتيب</label><input type="number" name="order_index" value="0"></div>
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="active" value="1" checked><span class="switch"></span> مفعّل</label></div>
            </div>
            <div>
                <label style="font-weight:700;font-size:13px">اختر أيقونة:</label>
                <div class="icon-picker-grid" id="appIconPicker">
                    <?php foreach ($iconList as $ic): ?>
                    <div class="icon-pick-item" data-icon="<?= $ic ?>" onclick="pickIcon(this,'appIconInput')"><i class="fas <?= $ic ?>"></i></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <br>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <span>حفظ</span></button>
            <button type="button" class="btn btn-danger" onclick="resetAppIconForm()" style="display:none" id="appIconResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>

    <div class="panel-card">
        <h2><i class="fas fa-th"></i> الأيقونات <span class="badge-count"><?= count($appIcons) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>الأيقونة</th><th>الاسم</th><th>الإجراء</th><th>الترتيب</th><th>الحالة</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($appIcons as $ic): ?>
                <tr>
                    <td><div style="width:44px;height:44px;border-radius:10px;background:<?= sanitize($ic['color']) ?>22;display:flex;align-items:center;justify-content:center;color:<?= sanitize($ic['color']) ?>;font-size:20px"><i class="fas <?= sanitize($ic['icon']) ?>"></i></div></td>
                    <td><strong><?= sanitize($ic['name']) ?></strong></td>
                    <td><span class="badge badge-info"><?= sanitize($ic['action_type']) ?></span></td>
                    <td><?= (int)$ic['order_index'] ?></td>
                    <td><?= $ic['active'] ? '<span class="badge badge-success">مفعّل</span>' : '<span class="badge badge-danger">معطّل</span>' ?></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editAppIcon(<?= json_encode($ic,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=delete_app_icon&id=<?= $ic['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- قراء الصوتيات -->
<section class="tab-panel <?= $currentTab==='reciters'?'active':'' ?>" id="tab-reciters">
    <div class="panel-card">
        <h2><i class="fas fa-user-plus"></i> <span id="reciterFormTitle">إضافة قارئ</span></h2>
        <form method="POST" action="admin.php?action=save_reciter" enctype="multipart/form-data" class="ajax-form" id="reciterForm">
            <?= csrfField() ?>
            <input type="hidden" name="reciter_id" value="">
            <input type="hidden" name="current_image" value="">
            <div class="form-grid">
                <div class="form-group"><label>الاسم *</label><input type="text" name="reciter_name" required></div>
                <div class="form-group"><label>الصورة</label><input type="file" name="reciter_image" accept="image/*"></div>
                <div class="form-group"><label>رسالة القفل</label><input type="text" name="lock_message" value="سيتم إضافته قريباً"></div>
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="is_locked" value="1"><span class="switch"></span>🔒 مقفل</label></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> <span>إضافة</span></button>
            <button type="button" class="btn btn-danger" onclick="resetReciterForm()" style="display:none" id="reciterResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-users"></i> القراء <span class="badge-count"><?= count($reciters) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>الصورة</th><th>الاسم</th><th>الحالة</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($reciters as $r): ?>
                <tr>
                    <td><?php if ($r['image'] && file_exists(UPLOAD_PATH.'/'.$r['image'])): ?><img src="uploads/<?= sanitize($r['image']) ?>" class="thumb"><?php else: ?><i class="fas fa-user-circle fa-2x" style="color:#c9a959"></i><?php endif; ?></td>
                    <td><strong><?= sanitize($r['name']) ?></strong></td>
                    <td><?= $r['is_locked']?'<span class="badge badge-danger">🔒 مقفل</span>':'<span class="badge badge-success">🔓 مفتوح</span>' ?></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editReciter(<?= json_encode($r,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=delete_reciter&id=<?= $r['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- قراء الريلزات -->
<section class="tab-panel <?= $currentTab==='reel_reciters'?'active':'' ?>" id="tab-reel_reciters">
    <div class="panel-card">
        <h2><i class="fas fa-user-plus"></i> <span id="reelFormTitle">إضافة قارئ ريلزات</span></h2>
        <form method="POST" action="admin.php?action=save_reel_reciter" enctype="multipart/form-data" class="ajax-form" id="reelForm">
            <?= csrfField() ?>
            <input type="hidden" name="reciter_id" value="">
            <input type="hidden" name="current_image" value="">
            <div class="form-grid">
                <div class="form-group"><label>الاسم *</label><input type="text" name="name" required></div>
                <div class="form-group"><label>اسم المستخدم</label><input type="text" name="username" placeholder="@username"></div>
                <div class="form-group"><label>الصورة</label><input type="file" name="reciter_image" accept="image/*"></div>
                <div class="form-group full"><label>الوصف</label><textarea name="bio" rows="3"></textarea></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> <span>إضافة</span></button>
            <button type="button" class="btn btn-danger" onclick="resetReelForm()" style="display:none" id="reelResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-users"></i> القراء <span class="badge-count"><?= count($reelReciters) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>الصورة</th><th>الاسم</th><th>المستخدم</th><th>فيديوهات</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($reelReciters as $r): ?>
                <tr>
                    <td><?php if ($r['image'] && file_exists(REEL_RECITERS_PATH.'/'.$r['image'])): ?><img src="uploads/reel_reciters/<?= sanitize($r['image']) ?>" class="thumb"><?php else: ?><i class="fas fa-user-circle fa-2x" style="color:#c9a959"></i><?php endif; ?></td>
                    <td><strong><?= sanitize($r['name']) ?></strong></td>
                    <td><?= sanitize($r['username'] ?? '') ?></td>
                    <td><span class="badge badge-info"><?= (int)($r['total_videos'] ?? 0) ?></span></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editReelReciter(<?= json_encode($r,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=delete_reel_reciter&id=<?= $r['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- السور الصوتية -->
<section class="tab-panel <?= $currentTab==='quran'?'active':'' ?>" id="tab-quran">
    <div class="panel-card" style="background:linear-gradient(135deg,#f0fdf4,#dcfce7);border-right-color:var(--success)">
        <h2><i class="fas fa-magic"></i> الرفع الذكي للسور</h2>
        <form method="POST" action="admin.php?action=smart_upload" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label>القارئ</label><select name="reciter_id" required><option value="">-- اختر --</option><?php foreach ($reciters as $r): ?><option value="<?= $r['id'] ?>"><?= sanitize($r['name']) ?></option><?php endforeach; ?></select></div>
                <div class="form-group full"><label>رابط نموذجي</label><input type="url" name="example_url" placeholder="https://server8.mp3quran.net/lhdan/114.mp3" required></div>
            </div>
            <button type="submit" class="btn btn-success"><i class="fas fa-bolt"></i> استخراج الكل</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-plus"></i> <span id="audioFormTitle">إضافة سورة</span></h2>
        <form method="POST" action="admin.php?action=save_audio" enctype="multipart/form-data" class="ajax-form" id="audioForm">
            <?= csrfField() ?>
            <input type="hidden" name="audio_id" value="">
            <input type="hidden" name="current_file_path" value="">
            <div class="form-grid">
                <div class="form-group"><label>القارئ *</label><select name="reciter_id" required><?php foreach ($reciters as $r): ?><option value="<?= $r['id'] ?>"><?= sanitize($r['name']) ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>اسم السورة *</label><input type="text" name="surah_name" required></div>
                <div class="form-group"><label>رقم السورة</label><input type="number" name="surah_number" min="1" max="114"></div>
                <div class="form-group"><label>النوع</label><select name="audio_type" class="audio-type-toggle"><option value="url">🔗 رابط</option><option value="file">📁 ملف</option></select></div>
                <div class="form-group audio-url-group"><label>الرابط</label><input type="url" name="audio_url"></div>
                <div class="form-group audio-file-group" style="display:none"><label>ملف MP3</label><input type="file" name="audio_file" accept="audio/*"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <span>حفظ</span></button>
            <button type="button" class="btn btn-danger" onclick="resetAudioForm()" style="display:none" id="audioResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-list"></i> السور <span class="badge-count"><?= count($audios) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>القارئ</th><th>السورة</th><th>#</th><th>النوع</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($audios as $a): ?>
                <tr>
                    <td><?= sanitize($a['reciter_name']) ?></td>
                    <td><strong><?= sanitize($a['surah_name']) ?></strong></td>
                    <td><?= (int)$a['surah_number'] ?></td>
                    <td><?= $a['audio_type']==='file'?'<span class="badge badge-info">📁 ملف</span>':'<span class="badge badge-success">🔗 رابط</span>' ?></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editAudio(<?= json_encode($a,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=delete_audio&id=<?= $a['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- الريلزات -->
<section class="tab-panel <?= $currentTab==='videos'?'active':'' ?>" id="tab-videos">
    <div class="panel-card">
        <h2><i class="fas fa-random"></i> ترتيب الريلزات</h2>
        <form method="POST" action="admin.php?action=update_reels_order" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><select name="reels_order_type"><option value="random" <?= $reelsOrder==='random'?'selected':'' ?>>🎲 عشوائي</option><option value="normal" <?= $reelsOrder==='normal'?'selected':'' ?>>📋 منتظم</option></select></div>
            </div>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> حفظ</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-video"></i> <span id="videoFormTitle">إضافة فيديو</span></h2>
        <form method="POST" action="admin.php?action=save_video" enctype="multipart/form-data" class="ajax-form" id="videoForm">
            <?= csrfField() ?>
            <input type="hidden" name="video_id" value="">
            <input type="hidden" name="current_file_path" value="">
            <input type="hidden" name="current_thumbnail" value="">
            <div class="form-grid">
                <div class="form-group full"><label>العنوان *</label><input type="text" name="video_title" required></div>
                <div class="form-group"><label>النوع</label><select name="video_type" class="video-type-toggle"><option value="url">🔗 رابط</option><option value="file">📁 ملف</option></select></div>
                <div class="form-group video-url-group"><label>الرابط</label><input type="url" name="video_url"></div>
                <div class="form-group video-file-group" style="display:none"><label>ملف</label><input type="file" name="video_file" accept="video/*"></div>
                <div class="form-group"><label>قارئ الريلزات</label><select name="reel_reciter_id"><option value="">-- بدون --</option><?php foreach ($reelReciters as $r): ?><option value="<?= $r['id'] ?>"><?= sanitize($r['name']) ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>صورة مصغرة</label><input type="file" name="video_thumbnail" accept="image/*"></div>
                <div class="form-group"><label>المدة</label><input type="text" name="video_duration" value="00:00"></div>
                <div class="form-group"><label>الترتيب</label><input type="number" name="sort_order" value="0"></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> <span>نشر</span></button>
            <button type="button" class="btn btn-danger" onclick="resetVideoForm()" style="display:none" id="videoResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-film"></i> الفيديوهات <span class="badge-count"><?= count($videos) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>#</th><th>المعاينة</th><th>العنوان</th><th>القارئ</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($videos as $v): ?>
                <tr>
                    <td><?= $v['id'] ?></td>
                    <td><?php if ($v['thumbnail_path'] && file_exists(THUMBNAILS_PATH.'/'.$v['thumbnail_path'])): ?><img src="uploads/thumbnails/<?= sanitize($v['thumbnail_path']) ?>" class="thumb"><?php else: ?><i class="fas fa-video fa-2x" style="color:#c9a959"></i><?php endif; ?></td>
                    <td><strong><?= sanitize($v['title']) ?></strong></td>
                    <td><?= sanitize($v['reciter_name'] ?? '-') ?></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editVideo(<?= json_encode($v,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=delete_video&id=<?= $v['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- الكتب -->
<section class="tab-panel <?= $currentTab==='books'?'active':'' ?>" id="tab-books">
    <div class="panel-card">
        <h2><i class="fas fa-book-open"></i> <span id="bookFormTitle">إضافة كتاب</span></h2>
        <form method="POST" action="admin.php?action=save_book" enctype="multipart/form-data" class="ajax-form" id="bookForm">
            <?= csrfField() ?>
            <input type="hidden" name="book_id" value="">
            <input type="hidden" name="current_cover" value="">
            <input type="hidden" name="current_pdf" value="">
            <div class="form-grid">
                <div class="form-group"><label>عنوان الكتاب *</label><input type="text" name="title" required></div>
                <div class="form-group"><label>المؤلف *</label><input type="text" name="author" required></div>
                <div class="form-group full"><label>الوصف</label><textarea name="description" rows="3"></textarea></div>
                <div class="form-group"><label>التصنيف</label><select name="category"><option value="تفسير">تفسير</option><option value="حديث">حديث</option><option value="عقيدة">عقيدة</option><option value="فقه">فقه</option><option value="سيرة">سيرة</option><option value="أذكار">أذكار</option><option value="أخرى">أخرى</option></select></div>
                <div class="form-group"><label>عدد الصفحات</label><input type="number" name="pages" value="0" min="0"></div>
                <div class="form-group"><label>الترتيب</label><input type="number" name="sort_order" value="0"></div>
                <div class="form-group"><label>الغلاف</label><input type="file" name="cover_image" accept="image/*"></div>
                <div class="form-group full">
                    <label>مصدر PDF</label>
                    <div style="display:flex;gap:16px;margin:6px 0">
                        <label style="display:flex;gap:6px;cursor:pointer"><input type="radio" name="source_type" value="file" checked> 📁 رفع ملف</label>
                        <label style="display:flex;gap:6px;cursor:pointer"><input type="radio" name="source_type" value="url"> 🔗 رابط خارجي</label>
                    </div>
                    <div class="pdf-file-group"><input type="file" name="pdf_file" accept=".pdf"></div>
                    <div class="pdf-url-group" style="display:none;margin-top:10px"><input type="url" name="pdf_url" style="direction:ltr"></div>
                </div>
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="status" value="1" checked><span class="switch"></span> منشور</label></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> <span>حفظ</span></button>
            <button type="button" class="btn btn-danger" onclick="resetBookForm()" style="display:none" id="bookResetBtn"><i class="fas fa-undo"></i> إلغاء</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-list"></i> الكتب <span class="badge-count"><?= count($books) ?></span></h2>
        <div class="table-wrap">
            <table>
                <thead><tr><th>الغلاف</th><th>العنوان</th><th>المؤلف</th><th>الحالة</th><th>إجراءات</th></tr></thead>
                <tbody>
                <?php foreach ($books as $b): ?>
                <tr>
                    <td><?php if ($b['cover_image'] && file_exists(BOOKS_COVERS_PATH.'/'.$b['cover_image'])): ?><img src="uploads/books/covers/<?= sanitize($b['cover_image']) ?>" class="thumb-book"><?php else: ?><i class="fas fa-book fa-2x" style="color:#c9a959"></i><?php endif; ?></td>
                    <td><strong><?= sanitize($b['title']) ?></strong></td>
                    <td><?= sanitize($b['author']) ?></td>
                    <td><?= $b['status']?'<span class="badge badge-success">منشور</span>':'<span class="badge badge-danger">مخفي</span>' ?></td>
                    <td>
                        <button type="button" class="btn-icon btn-edit" onclick='editBook(<?= json_encode($b,JSON_UNESCAPED_UNICODE|JSON_HEX_APOS) ?>)'><i class="fas fa-edit"></i></button>
                        <a href="admin.php?action=toggle_book&id=<?= $b['id'] ?>" class="btn-icon btn-toggle"><i class="fas fa-<?= $b['status']?'eye-slash':'eye' ?>"></i></a>
                        <a href="admin.php?action=delete_book&id=<?= $b['id'] ?>" class="btn-icon btn-delete confirm-delete"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- الإعدادات -->
<section class="tab-panel <?= $currentTab==='settings'?'active':'' ?>" id="tab-settings">
    <div class="panel-card">
        <h2><i class="fas fa-cog"></i> الإعدادات العامة</h2>
        <form method="POST" action="admin.php?action=update_settings" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="show_intro" value="1" <?= $showIntro?'checked':'' ?>><span class="switch"></span> تفعيل شاشة الترحيب</label></div>
                <div class="form-group"><label class="switch-label"><input type="checkbox" name="maintenance_mode" value="1" <?= ($siteSettings['maintenance_mode'] ?? '0')==='1'?'checked':'' ?>><span class="switch"></span> وضع الصيانة</label></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> حفظ</button>
        </form>
    </div>
    <div class="panel-card">
        <h2><i class="fas fa-broom"></i> أدوات الصيانة</h2>
        <a href="admin.php?action=clear_cache" class="btn btn-warning"><i class="fas fa-broom"></i> مسح الكاش</a>
    </div>
</section>

<!-- الأمان -->
<section class="tab-panel <?= $currentTab==='security'?'active':'' ?>" id="tab-security">
    <div class="panel-card">
        <h2><i class="fas fa-key"></i> تغيير كلمة المرور</h2>
        <form method="POST" action="admin.php?action=change_password" class="ajax-form">
            <?= csrfField() ?>
            <div class="form-grid">
                <div class="form-group"><label>كلمة المرور الحالية</label><input type="password" name="current_password" required></div>
                <div class="form-group"><label>كلمة المرور الجديدة</label><input type="password" name="new_password" required minlength="6"></div>
                <div class="form-group"><label>تأكيد كلمة المرور</label><input type="password" name="confirm_password" required minlength="6"></div>
            </div>
            <button type="submit" class="btn btn-warning"><i class="fas fa-key"></i> تغيير</button>
        </form>
    </div>
</section>

</main>

<div id="toast" class="toast"></div>

<script>
(function(){
'use strict';
const CSRF = document.body.dataset.csrf || '';
const API = 'admin.php?action=';

let toastTimeout = null;
function showToast(msg, type = 'info') {
    const t = document.getElementById('toast');
    if (!t) return;
    const icons = {success:'fa-check-circle',error:'fa-exclamation-circle',info:'fa-info-circle',warning:'fa-exclamation-triangle'};
    t.innerHTML = `<i class="fas ${icons[type]||icons.info}"></i> ${msg}`;
    t.className = 'toast show ' + type;
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => t.classList.remove('show'), 3000);
}
window.showToast = showToast;

window.toggleSidebar = function() {
    document.getElementById('sidebar').classList.toggle('open');
    document.querySelector('.sidebar-overlay').classList.toggle('active');
};

const tabTitles = {dashboard:'الإحصائيات',control:'التحكم الكامل',content:'تحرير المحتوى',carousel:'شريط القراء',azkar:'الأذكار',hadiths:'الأحاديث',icons:'الأيقونات',reciters:'قراء الصوتيات',reel_reciters:'قراء الريلزات',quran:'السور الصوتية',videos:'الريلزات',books:'الكتب',settings:'الإعدادات',security:'الأمان'};

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const tab = link.dataset.tab;
        if (tab) switchTab(tab);
    });
});

function switchTab(tab) {
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector(`.nav-link[data-tab="${tab}"]`)?.classList.add('active');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.getElementById('tab-' + tab)?.classList.add('active');
    document.getElementById('pageTitle').textContent = tabTitles[tab] || 'لوحة التحكم';
    history.replaceState(null, null, '?tab=' + tab);
    if (window.innerWidth < 1024) {
        document.getElementById('sidebar').classList.remove('open');
        document.querySelector('.sidebar-overlay').classList.remove('active');
    }
    if (tab === 'dashboard') loadStats();
}

document.querySelectorAll('.ajax-form').forEach(form => {
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        const btn = form.querySelector('button[type="submit"]');
        const orig = btn?.innerHTML;
        if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...'; }
        const fd = new FormData(form);
        try {
            const res = await fetch(form.action || 'admin.php', { method: 'POST', body: fd });
            if (res.redirected || res.ok) {
                showToast('✅ تم الحفظ بنجاح', 'success');
                setTimeout(() => window.location.reload(), 700);
            } else {
                showToast('حدث خطأ', 'error');
                if (btn) { btn.disabled = false; btn.innerHTML = orig; }
            }
        } catch (err) {
            showToast('خطأ في الاتصال', 'error');
            if (btn) { btn.disabled = false; btn.innerHTML = orig; }
        }
    });
});

document.querySelectorAll('.confirm-delete').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('⚠️ هل أنت متأكد من الحذف؟')) window.location.href = this.href;
    });
});

function initToggles() {
    document.querySelectorAll('.audio-type-toggle').forEach(sel => {
        if (sel.dataset.init) return; sel.dataset.init = '1';
        const form = sel.closest('form');
        const url = form.querySelector('.audio-url-group');
        const file = form.querySelector('.audio-file-group');
        const upd = () => { const isFile = sel.value === 'file'; url.style.display = isFile ? 'none' : 'flex'; file.style.display = isFile ? 'flex' : 'none'; };
        sel.addEventListener('change', upd); upd();
    });
    document.querySelectorAll('.video-type-toggle').forEach(sel => {
        if (sel.dataset.init) return; sel.dataset.init = '1';
        const form = sel.closest('form');
        const url = form.querySelector('.video-url-group');
        const file = form.querySelector('.video-file-group');
        const upd = () => { const isFile = sel.value === 'file'; url.style.display = isFile ? 'none' : 'flex'; file.style.display = isFile ? 'flex' : 'none'; };
        sel.addEventListener('change', upd); upd();
    });
    document.querySelectorAll('input[name="source_type"]').forEach(radio => {
        if (radio.dataset.init) return; radio.dataset.init = '1';
        radio.addEventListener('change', function() {
            const form = this.closest('form');
            const file = form.querySelector('.pdf-file-group');
            const url = form.querySelector('.pdf-url-group');
            const isUrl = this.value === 'url';
            if (file) file.style.display = isUrl ? 'none' : 'block';
            if (url) url.style.display = isUrl ? 'block' : 'none';
        });
    });
}
initToggles();

window.pickIcon = function(el, inputId) {
    const icon = el.dataset.icon;
    document.getElementById(inputId).value = icon;
    el.parentElement.querySelectorAll('.icon-pick-item').forEach(i => i.classList.remove('selected'));
    el.classList.add('selected');
};

/* Azkar Form Handlers */
window.editAzkarCat = function(c) {
    const form = document.getElementById('azkarCatForm');
    form.querySelector('[name="category_id"]').value = c.id;
    form.querySelector('[name="category_name"]').value = c.name || '';
    form.querySelector('[name="category_icon"]').value = c.icon || 'fa-hands-praying';
    form.querySelector('[name="order_index"]').value = c.order_index || 0;
    form.querySelector('[name="active"]').checked = c.active == 1;
    document.getElementById('azkarCatFormTitle').textContent = 'تعديل قسم';
    document.getElementById('azkarCatResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
    showToast('وضع التعديل مفعل','info');
};
window.resetAzkarCatForm = function() {
    const form = document.getElementById('azkarCatForm');
    form.reset();
    form.querySelector('[name="category_id"]').value = '';
    document.getElementById('azkarCatFormTitle').textContent = 'إضافة قسم أذكار';
    document.getElementById('azkarCatResetBtn').style.display = 'none';
};
window.editZikr = function(z) {
    const form = document.getElementById('zikrForm');
    form.querySelector('[name="zikr_id"]').value = z.id;
    form.querySelector('[name="category_id"]').value = z.category_id;
    form.querySelector('[name="zikr_text"]').value = z.text || '';
    form.querySelector('[name="repeat_count"]').value = z.repeat_count || 1;
    form.querySelector('[name="reward"]').value = z.reward || '';
    form.querySelector('[name="order_index"]').value = z.order_index || 0;
    document.getElementById('zikrFormTitle').textContent = 'تعديل ذكر';
    document.getElementById('zikrResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
    showToast('وضع التعديل مفعل','info');
};
window.resetZikrForm = function() {
    const form = document.getElementById('zikrForm');
    form.reset();
    form.querySelector('[name="zikr_id"]').value = '';
    document.getElementById('zikrFormTitle').textContent = 'إضافة ذكر';
    document.getElementById('zikrResetBtn').style.display = 'none';
};
window.editHadith = function(h) {
    const form = document.getElementById('hadithForm');
    form.querySelector('[name="hadith_id"]').value = h.id;
    form.querySelector('[name="hadith_title"]').value = h.title || '';
    form.querySelector('[name="hadith_text"]').value = h.text || '';
    form.querySelector('[name="narrator"]').value = h.narrator || '';
    form.querySelector('[name="source"]').value = h.source || '';
    form.querySelector('[name="order_index"]').value = h.order_index || 0;
    form.querySelector('[name="active"]').checked = h.active == 1;
    document.getElementById('hadithFormTitle').textContent = 'تعديل حديث';
    document.getElementById('hadithResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
    showToast('وضع التعديل مفعل','info');
};
window.resetHadithForm = function() {
    const form = document.getElementById('hadithForm');
    form.reset();
    form.querySelector('[name="hadith_id"]').value = '';
    document.getElementById('hadithFormTitle').textContent = 'إضافة حديث';
    document.getElementById('hadithResetBtn').style.display = 'none';
};
window.editAppIcon = function(ic) {
    const form = document.getElementById('appIconForm');
    form.querySelector('[name="icon_id"]').value = ic.id;
    form.querySelector('[name="icon_name"]').value = ic.name || '';
    form.querySelector('[name="icon_class"]').value = ic.icon || 'fa-star';
    form.querySelector('[name="icon_color"]').value = ic.color || '#c9a959';
    form.querySelector('[name="action_type"]').value = ic.action_type || 'azkar';
    form.querySelector('[name="icon_link"]').value = ic.link || '';
    form.querySelector('[name="order_index"]').value = ic.order_index || 0;
    form.querySelector('[name="active"]').checked = ic.active == 1;
    document.getElementById('iconFormTitle').textContent = 'تعديل أيقونة';
    document.getElementById('appIconResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
    showToast('وضع التعديل مفعل','info');
};
window.resetAppIconForm = function() {
    const form = document.getElementById('appIconForm');
    form.reset();
    form.querySelector('[name="icon_id"]').value = '';
    document.getElementById('iconFormTitle').textContent = 'إضافة أيقونة';
    document.getElementById('appIconResetBtn').style.display = 'none';
};

/* Edit Functions */
window.editReciter = function(r) {
    const form = document.getElementById('reciterForm');
    form.querySelector('[name="reciter_id"]').value = r.id;
    form.querySelector('[name="reciter_name"]').value = r.name || '';
    form.querySelector('[name="current_image"]').value = r.image || '';
    form.querySelector('[name="lock_message"]').value = r.lock_message || 'سيتم إضافته قريباً';
    form.querySelector('[name="is_locked"]').checked = r.is_locked == 1;
    document.getElementById('reciterFormTitle').textContent = 'تعديل قارئ';
    document.getElementById('reciterResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
};
window.resetReciterForm = function() {
    const form = document.getElementById('reciterForm');
    form.reset();
    form.querySelector('[name="reciter_id"]').value = '';
    document.getElementById('reciterFormTitle').textContent = 'إضافة قارئ';
    document.getElementById('reciterResetBtn').style.display = 'none';
};
window.editReelReciter = function(r) {
    const form = document.getElementById('reelForm');
    form.querySelector('[name="reciter_id"]').value = r.id;
    form.querySelector('[name="name"]').value = r.name || '';
    form.querySelector('[name="username"]').value = r.username || '';
    form.querySelector('[name="bio"]').value = r.bio || '';
    form.querySelector('[name="current_image"]').value = r.image || '';
    document.getElementById('reelFormTitle').textContent = 'تعديل قارئ';
    document.getElementById('reelResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
};
window.resetReelForm = function() {
    const form = document.getElementById('reelForm');
    form.reset();
    form.querySelector('[name="reciter_id"]').value = '';
    document.getElementById('reelFormTitle').textContent = 'إضافة قارئ ريلزات';
    document.getElementById('reelResetBtn').style.display = 'none';
};
window.editAudio = function(a) {
    const form = document.getElementById('audioForm');
    form.querySelector('[name="audio_id"]').value = a.id;
    form.querySelector('[name="reciter_id"]').value = a.reciter_id;
    form.querySelector('[name="surah_name"]').value = a.surah_name || '';
    form.querySelector('[name="surah_number"]').value = a.surah_number || '';
    form.querySelector('[name="audio_type"]').value = a.audio_type || 'url';
    form.querySelector('[name="audio_url"]').value = a.audio_url || '';
    form.querySelector('[name="current_file_path"]').value = a.file_path || '';
    form.querySelector('[name="audio_type"]').dispatchEvent(new Event('change'));
    document.getElementById('audioFormTitle').textContent = 'تعديل سورة';
    document.getElementById('audioResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
};
window.resetAudioForm = function() {
    const form = document.getElementById('audioForm');
    form.reset();
    form.querySelector('[name="audio_id"]').value = '';
    form.querySelector('[name="current_file_path"]').value = '';
    document.getElementById('audioFormTitle').textContent = 'إضافة سورة';
    document.getElementById('audioResetBtn').style.display = 'none';
};
window.editVideo = function(v) {
    const form = document.getElementById('videoForm');
    form.querySelector('[name="video_id"]').value = v.id;
    form.querySelector('[name="video_title"]').value = v.title || '';
    form.querySelector('[name="video_type"]').value = v.video_type || 'url';
    form.querySelector('[name="video_url"]').value = v.video_url || '';
    form.querySelector('[name="current_file_path"]').value = v.file_path || '';
    form.querySelector('[name="current_thumbnail"]').value = v.thumbnail_path || '';
    form.querySelector('[name="reel_reciter_id"]').value = v.reel_reciter_id || '';
    form.querySelector('[name="video_duration"]').value = v.video_duration || '00:00';
    form.querySelector('[name="sort_order"]').value = v.sort_order || 0;
    form.querySelector('[name="video_type"]').dispatchEvent(new Event('change'));
    document.getElementById('videoFormTitle').textContent = 'تعديل فيديو';
    document.getElementById('videoResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
};
window.resetVideoForm = function() {
    const form = document.getElementById('videoForm');
    form.reset();
    form.querySelector('[name="video_id"]').value = '';
    form.querySelector('[name="current_file_path"]').value = '';
    form.querySelector('[name="current_thumbnail"]').value = '';
    document.getElementById('videoFormTitle').textContent = 'إضافة فيديو';
    document.getElementById('videoResetBtn').style.display = 'none';
};
window.editBook = function(b) {
    const form = document.getElementById('bookForm');
    form.querySelector('[name="book_id"]').value = b.id;
    form.querySelector('[name="title"]').value = b.title || '';
    form.querySelector('[name="author"]').value = b.author || '';
    form.querySelector('[name="description"]').value = b.description || '';
    form.querySelector('[name="category"]').value = b.category || 'أخرى';
    form.querySelector('[name="pages"]').value = b.pages || 0;
    form.querySelector('[name="sort_order"]').value = b.sort_order || 0;
    form.querySelector('[name="current_cover"]').value = b.cover_image || '';
    form.querySelector('[name="current_pdf"]').value = b.pdf_file || '';
    form.querySelector('[name="pdf_url"]').value = b.pdf_url || '';
    const st = form.querySelector(`[name="source_type"][value="${b.source_type||'file'}"]`);
    if (st) { st.checked = true; st.dispatchEvent(new Event('change')); }
    form.querySelector('[name="status"]').checked = b.status == 1;
    document.getElementById('bookFormTitle').textContent = 'تعديل كتاب';
    document.getElementById('bookResetBtn').style.display = 'inline-flex';
    form.scrollIntoView({behavior:'smooth',block:'center'});
};
window.resetBookForm = function() {
    const form = document.getElementById('bookForm');
    form.reset();
    form.querySelector('[name="book_id"]').value = '';
    form.querySelector('[name="current_cover"]').value = '';
    form.querySelector('[name="current_pdf"]').value = '';
    document.getElementById('bookFormTitle').textContent = 'إضافة كتاب';
    document.getElementById('bookResetBtn').style.display = 'none';
};

/* Stats */
let charts = {};
window.loadStats = async function() {
    const c = document.getElementById('statsContent');
    if (!c) return;
    c.innerHTML = '<div class="stats-loading"><i class="fas fa-spinner fa-spin"></i><p>جاري تحميل الإحصائيات...</p></div>';
    try {
        const res = await fetch(API + 'stats');
        const text = await res.text();
        if (!text.trim().startsWith('{')) throw new Error('استجابة غير صالحة');
        const data = JSON.parse(text);
        if (!data.success) throw new Error(data.message || 'فشل');
        renderStats(data);
    } catch (e) {
        c.innerHTML = `<div class="stats-loading" style="color:#ef4444;"><i class="fas fa-exclamation-triangle"></i><p>خطأ: ${e.message}</p></div>`;
    }
};

function formatNum(n) {
    n = Number(n) || 0;
    if (n >= 1e6) return (n/1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n/1e3).toFixed(1) + 'K';
    return n.toLocaleString('en-US');
}
function esc(str) { const d = document.createElement('div'); d.textContent = str || ''; return d.innerHTML; }

function renderStats(data) {
    const s = data.stats;
    const c = document.getElementById('statsContent');
    const cards = [
        {icon:'fa-eye',value:s.total_views,label:'مشاهدات',cls:''},
        {icon:'fa-users',value:s.online_now,label:'متصل الآن',cls:'green'},
        {icon:'fa-user-check',value:s.active_today,label:'نشطاء اليوم',cls:'green'},
        {icon:'fa-heart',value:s.total_likes,label:'إعجابات',cls:'red'},
        {icon:'fa-share-alt',value:s.total_shares,label:'مشاركات',cls:'blue'},
        {icon:'fa-play',value:s.total_plays,label:'تشغيل',cls:'purple'},
        {icon:'fa-download',value:s.total_downloads,label:'تحميلات',cls:''},
        {icon:'fa-microphone',value:s.total_reciters,label:'قراء',cls:''},
        {icon:'fa-film',value:s.total_videos,label:'ريلزات',cls:'blue'},
        {icon:'fa-book-quran',value:s.total_audios,label:'سور',cls:'green'},
        {icon:'fa-hands-praying',value:s.total_azkar,label:'أذكار',cls:'purple'},
        {icon:'fa-book-open',value:s.total_hadiths,label:'أحاديث',cls:'purple'}
    ];
    let html = '<div class="stats-grid">';
    cards.forEach(cd => {
        html += `<div class="stat-card ${cd.cls}"><div class="stat-icon"><i class="fas ${cd.icon}"></i></div><div class="stat-number">${formatNum(cd.value)}</div><div class="stat-label">${cd.label}</div></div>`;
    });
    html += '</div>';
    html += '<div class="charts-grid">';
    html += `<div class="chart-card"><h3><i class="fas fa-chart-line"></i> النشاط اليومي</h3><canvas id="chartDaily"></canvas></div>`;
    html += `<div class="chart-card"><h3><i class="fas fa-chart-pie"></i> توزيع التفاعلات</h3><canvas id="chartTypes"></canvas></div>`;
    html += `<div class="chart-card"><h3><i class="fas fa-clock"></i> أوقات الذروة</h3><canvas id="chartHours"></canvas></div>`;
    html += `<div class="chart-card"><h3><i class="fas fa-stream"></i> آخر النشاطات</h3><div style="display:flex;flex-direction:column;gap:8px;max-height:400px;overflow-y:auto">${data.recentActivity.length?data.recentActivity.slice(0,15).map(a=>`<div style="display:flex;align-items:center;gap:10px;padding:10px;background:#f8fafc;border-radius:8px;border-right:3px solid #c9a959;font-size:13px"><i class="fas fa-circle" style="font-size:6px;color:#c9a959"></i><strong>${esc(a.action_type)}</strong><span style="font-size:11px;color:#64748b;margin-right:auto;direction:ltr">${a.created_at||''}</span></div>`).join(''):'<p style="text-align:center;color:#94a3b8;padding:20px;">لا توجد نشاطات</p>'}</div></div>`;
    html += '</div>';
    c.innerHTML = html;
    setTimeout(() => drawCharts(data), 100);
}

function drawCharts(data) {
    const gold = '#c9a959';
    const palette = ['#c9a959','#10b981','#3b82f6','#ef4444','#8b5cf6','#f59e0b','#ec4899','#14b8a6'];
    if (charts.daily) charts.daily.destroy();
    const dc = document.getElementById('chartDaily');
    if (dc && data.daily.length) {
        charts.daily = new Chart(dc, {type:'line',data:{labels:data.daily.map(d=>d.date),datasets:[{label:'التفاعلات',data:data.daily.map(d=>d.count),borderColor:gold,backgroundColor:'rgba(201,169,89,.1)',fill:true,tension:.4,borderWidth:2,pointBackgroundColor:gold,pointRadius:4}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'#f1f5f9'}},x:{grid:{display:false}}}}});
    }
    if (charts.types) charts.types.destroy();
    const tc = document.getElementById('chartTypes');
    if (tc && data.contentTypes.length) {
        charts.types = new Chart(tc, {type:'doughnut',data:{labels:data.contentTypes.map(c=>c.item_type),datasets:[{data:data.contentTypes.map(c=>c.count),backgroundColor:palette,borderWidth:3,borderColor:'#fff'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{family:'Cairo',size:12},padding:12}}},cutout:'60%'}});
    }
    if (charts.hours) charts.hours.destroy();
    const hc = document.getElementById('chartHours');
    if (hc && data.peakHours.length) {
        charts.hours = new Chart(hc, {type:'bar',data:{labels:data.peakHours.map(h=>h.hour+':00'),datasets:[{label:'التفاعلات',data:data.peakHours.map(h=>h.count),backgroundColor:gold,borderRadius:8,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'#f1f5f9'}},x:{grid:{display:false}}}}});
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const dt = document.getElementById('tab-dashboard');
    if (dt && dt.classList.contains('active')) loadStats();
});

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.getElementById('sidebar')?.classList.remove('open');
        document.querySelector('.sidebar-overlay')?.classList.remove('active');
    }
});
})();
</script>
</body>
</html>