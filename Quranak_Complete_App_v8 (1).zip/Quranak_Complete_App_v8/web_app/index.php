<?php
/**
 * ============================================================
 * index.php — قرآنك V11.0
 * إصلاح 20+ خطأ + تصميم جديد + شاشة مقدمة + نافذة مدينة + تقويم
 * ============================================================
 */

define('QURAN_APP', true);
require_once __DIR__ . '/config.php';
startSecureSession();

/* ==================== API ==================== */
$action = $_GET['action'] ?? '';
if ($action !== '') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        switch ($action) {
            case 'get_reciters':
                jsonResponse(db()->query("SELECT * FROM reciters ORDER BY id DESC")->fetchAll());
            case 'get_reciters_carousel':
                jsonResponse(db()->query("SELECT id, name, image FROM reciters WHERE is_locked = 0 ORDER BY id DESC LIMIT 30")->fetchAll());
            case 'get_reel_reciters':
                jsonResponse(db()->query("SELECT * FROM reel_reciters ORDER BY id DESC")->fetchAll());
            case 'get_reel_reciter':
                $stmt = db()->prepare("SELECT * FROM reel_reciters WHERE id = ?");
                $stmt->execute([(int)($_GET['id'] ?? 0)]);
                $r = $stmt->fetch();
                if ($r) {
                    $vs = db()->prepare("SELECT COUNT(*) FROM videos WHERE reel_reciter_id = ?");
                    $vs->execute([$r['id']]);
                    $r['video_count'] = (int)$vs->fetchColumn();
                }
                jsonResponse($r ?: []);
            case 'get_reciter_videos':
                $stmt = db()->prepare("SELECT * FROM videos WHERE reel_reciter_id = ? ORDER BY sort_order ASC, id DESC");
                $stmt->execute([(int)($_GET['reciter_id'] ?? 0)]);
                jsonResponse($stmt->fetchAll());
            case 'get_audios':
                $stmt = db()->prepare("SELECT * FROM audios WHERE reciter_id = ? ORDER BY surah_number ASC");
                $stmt->execute([(int)($_GET['reciter_id'] ?? 0)]);
                jsonResponse($stmt->fetchAll());
            case 'get_videos':
                $orderType = db()->query("SELECT setting_value FROM app_settings WHERE setting_key='reels_order_type'")->fetchColumn() ?: 'random';
                $sql = "SELECT v.*, r.name as reciter_name, r.image as reciter_image, r.username FROM videos v LEFT JOIN reel_reciters r ON v.reel_reciter_id = r.id WHERE v.video_type IS NOT NULL";
                $sql .= ($orderType === 'random') ? " ORDER BY RAND()" : " ORDER BY v.sort_order ASC, v.id DESC";
                jsonResponse(db()->query($sql)->fetchAll());
            case 'get_recent_videos':
                jsonResponse(db()->query("SELECT v.*, r.name as reciter_name, r.image as reciter_image FROM videos v LEFT JOIN reel_reciters r ON v.reel_reciter_id = r.id ORDER BY v.id DESC LIMIT 10")->fetchAll());
            case 'get_video':
                $stmt = db()->prepare("SELECT v.*, r.name as reciter_name, r.image as reciter_image, r.username FROM videos v LEFT JOIN reel_reciters r ON v.reel_reciter_id = r.id WHERE v.id = ?");
                $stmt->execute([(int)($_GET['id'] ?? 0)]);
                jsonResponse($stmt->fetch() ?: []);
            case 'get_books':
                $status = isset($_GET['status']) ? (int)$_GET['status'] : 1;
                $stmt = db()->prepare("SELECT * FROM books WHERE status = ? ORDER BY sort_order ASC, id DESC");
                $stmt->execute([$status]);
                jsonResponse($stmt->fetchAll());
            case 'get_book':
                $stmt = db()->prepare("SELECT * FROM books WHERE id = ?");
                $stmt->execute([(int)($_GET['id'] ?? 0)]);
                jsonResponse($stmt->fetch() ?: []);
            case 'increment_book_views':
                db()->prepare("UPDATE books SET views = views + 1 WHERE id = ?")->execute([(int)($_GET['id'] ?? 0)]);
                jsonResponse(['status' => 'ok']);
            case 'get_azkar_categories':
                jsonResponse(db()->query("SELECT * FROM azkar_categories WHERE active = 1 ORDER BY order_index ASC")->fetchAll());
            case 'get_azkar':
                $stmt = db()->prepare("SELECT * FROM azkar WHERE category_id = ? ORDER BY order_index ASC, id ASC");
                $stmt->execute([(int)($_GET['category_id'] ?? 0)]);
                jsonResponse($stmt->fetchAll());
            case 'get_hadiths':
                jsonResponse(db()->query("SELECT * FROM hadiths WHERE active = 1 ORDER BY order_index ASC, id DESC")->fetchAll());
            case 'get_app_icons':
                jsonResponse(db()->query("SELECT * FROM app_icons WHERE active = 1 ORDER BY order_index ASC")->fetchAll());
            case 'track':
                $type = $_GET['type'] ?? ''; $itemType = $_GET['item_type'] ?? ''; $itemId = $_GET['item_id'] ?? '';
                if ($type) logUserAction($type, $itemType, $itemId);
                jsonResponse(['status' => 'ok']);
            case 'update_session':
                updateActiveSession();
                jsonResponse(['status' => 'ok']);
            case 'proxy_download':
                $url = $_GET['url'] ?? '';
                $filename = $_GET['filename'] ?? 'download';
                if (!$url || !preg_match('/^https?:\/\//i', $url)) { http_response_code(400); exit; }
                try {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => false,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_MAXREDIRS => 5,
                        CURLOPT_TIMEOUT => 300,
                        CURLOPT_CONNECTTIMEOUT => 15,
                        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        CURLOPT_SSL_VERIFYPEER => false,
                    ]);
                    $contentType = 'application/octet-stream';
                    curl_setopt($ch, CURLOPT_HEADERFUNCTION, function($ch, $header) use (&$contentType) {
                        if (stripos($header, 'Content-Type:') === 0) $contentType = trim(substr($header, 13));
                        return strlen($header);
                    });
                    header('Content-Type: ' . $contentType);
                    header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
                    header('Cache-Control: no-cache, must-revalidate');
                    curl_exec($ch);
                    curl_close($ch);
                } catch (Throwable $e) { http_response_code(500); }
                exit;
            default:
                jsonResponse(['error' => 'Unknown action'], 400);
        }
    } catch (Throwable $e) {
        error_log('API Error: ' . $e->getMessage());
        jsonResponse(['error' => 'Server error'], 500);
    }
    exit;
}

updateActiveSession();
try {
    if (!isset($_SESSION['page_viewed'])) {
        db()->exec("INSERT INTO stats_page_views (page_name, view_count) VALUES ('total', 1) ON DUPLICATE KEY UPDATE view_count = view_count + 1");
        $_SESSION['page_viewed'] = true;
    }
} catch (Throwable $e) {}

/* ==================== بيانات الصفحة ==================== */
try {
    $showIntro = db()->query("SELECT setting_value FROM settings WHERE setting_key='show_intro'")->fetchColumn() === '1';
    $recentVideos = [];
    if (sectionEnabled('videos')) {
        $recentVideos = db()->query("SELECT v.*, r.name as reciter_name, r.image as reciter_image FROM videos v LEFT JOIN reel_reciters r ON v.reel_reciter_id = r.id ORDER BY v.id DESC LIMIT 10")->fetchAll();
    }
    $appIcons = [];
    try { $appIcons = db()->query("SELECT * FROM app_icons WHERE active = 1 ORDER BY order_index ASC")->fetchAll(); } catch (Throwable $e) {}
} catch (Throwable $e) { die('خطأ في جلب البيانات'); }

$surahStartPages = [1=>1,2=>2,3=>50,4=>77,5=>106,6=>128,7=>151,8=>177,9=>187,10=>209,11=>221,12=>235,13=>249,14=>255,15=>262,16=>267,17=>282,18=>293,19=>305,20=>312,21=>322,22=>332,23=>342,24=>350,25=>359,26=>367,27=>377,28=>385,29=>396,30=>404,31=>411,32=>415,33=>418,34=>428,35=>434,36=>440,37=>446,38=>453,39=>458,40=>467,41=>477,42=>483,43=>489,44=>496,45=>499,46=>502,47=>507,48=>511,49=>515,50=>518,51=>520,52=>523,53=>526,54=>528,55=>531,56=>534,57=>537,58=>542,59=>545,60=>549,61=>551,62=>553,63=>554,64=>556,65=>558,66=>560,67=>562,68=>564,69=>566,70=>568,71=>570,72=>572,73=>574,74=>575,75=>577,76=>578,77=>580,78=>581,79=>583,80=>584,81=>585,82=>586,83=>587,84=>589,85=>590,86=>591,87=>591,88=>592,89=>593,90=>594,91=>595,92=>595,93=>596,94=>596,95=>597,96=>597,97=>598,98=>598,99=>599,100=>599,101=>600,102=>600,103=>601,104=>601,105=>601,106=>602,107=>602,108=>602,109=>603,110=>603,111=>603,112=>604,113=>604,114=>604];
$surahNames = [1=>'الفاتحة',2=>'البقرة',3=>'آل عمران',4=>'النساء',5=>'المائدة',6=>'الأنعام',7=>'الأعراف',8=>'الأنفال',9=>'التوبة',10=>'يونس',11=>'هود',12=>'يوسف',13=>'الرعد',14=>'إبراهيم',15=>'الحجر',16=>'النحل',17=>'الإسراء',18=>'الكهف',19=>'مريم',20=>'طه',21=>'الأنبياء',22=>'الحج',23=>'المؤمنون',24=>'النور',25=>'الفرقان',26=>'الشعراء',27=>'النمل',28=>'القصص',29=>'العنكبوت',30=>'الروم',31=>'لقمان',32=>'السجدة',33=>'الأحزاب',34=>'سبإ',35=>'فاطر',36=>'يس',37=>'الصافات',38=>'ص',39=>'الزمر',40=>'غافر',41=>'فصلت',42=>'الشورى',43=>'الزخرف',44=>'الدخان',45=>'الجاثية',46=>'الأحقاف',47=>'محمد',48=>'الفتح',49=>'الحجرات',50=>'ق',51=>'الذاريات',52=>'الطور',53=>'النجم',54=>'القمر',55=>'الرحمن',56=>'الواقعة',57=>'الحديد',58=>'المجادلة',59=>'الحشر',60=>'الممتحنة',61=>'الصف',62=>'الجمعة',63=>'المنافقون',64=>'التغابن',65=>'الطلاق',66=>'التحريم',67=>'الملك',68=>'القلم',69=>'الحاقة',70=>'المعارج',71=>'نوح',72=>'الجن',73=>'المزمل',74=>'المدثر',75=>'القيامة',76=>'الإنسان',77=>'المرسلات',78=>'النبإ',79=>'النازعات',80=>'عبس',81=>'التكوير',82=>'الإنفطار',83=>'المطففين',84=>'الإنشقاق',85=>'البروج',86=>'الطارق',87=>'الأعلى',88=>'الغاشية',89=>'الفجر',90=>'البلد',91=>'الشمس',92=>'الليل',93=>'الضحى',94=>'الشرح',95=>'التين',96=>'العلق',97=>'القدر',98=>'البينة',99=>'الزلزلة',100=>'العاديات',101=>'القارعة',102=>'التكاثر',103=>'العصر',104=>'الهمزة',105=>'الفيل',106=>'قريش',107=>'الماعون',108=>'الكوثر',109=>'الكافرون',110=>'النصر',111=>'المسد',112=>'الإخلاص',113=>'الفلق',114=>'الناس'];

$bgFajr = as_('bg_fajr', 'https://quran1.kesug.com/20.png');
$bgSunrise = as_('bg_sunrise', 'https://quran1.kesug.com/22.png');
$bgDhuhr = as_('bg_dhuhr', 'https://quran1.kesug.com/21.png');
$bgAsr = as_('bg_asr', 'https://quran1.kesug.com/21.png');
$bgMaghrib = as_('bg_maghrib', 'https://quran1.kesug.com/24.png');
$bgIsha = as_('bg_isha', 'https://quran1.kesug.com/23.png');
$bgDefault = as_('bg_default', 'https://quran1.kesug.com/21.png');

$carouselItemSize = (int)cs('carousel_item_size', '82');

$showBooks = sectionEnabled('books');
$showVideos = sectionEnabled('videos');
$showAudio = sectionEnabled('audio');
$showReciters = sectionEnabled('reciters');
$showPrayer = sectionEnabled('prayer');
$showSurahs = sectionEnabled('surahs');
$showAzkar = sectionEnabled('azkar');
$showTasbih = sectionEnabled('tasbih');
$showHadith = sectionEnabled('hadith');
$showCalendar = sectionEnabled('calendar');

$siteTitle = cs('site_title', 'قرآنك');
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0a2a25">
<title><?= htmlspecialchars($siteTitle) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --gold: <?= as_('primary_color', '#c9a959') ?>;
    --gold-light: #e2c78a;
    --gold-dark: #a8893a;
    --dark: <?= as_('accent_color', '#0d2b35') ?>;
    --darker: #07131c;
    --text-light: #a0b9c4;
    --radius-md: 14px;
    --radius-sm: 10px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    --safe-top: env(safe-area-inset-top, 0);
    --safe-bottom: env(safe-area-inset-bottom, 0);
    --carousel-size: <?= $carouselItemSize ?>px;
    --sidebar-width: 260px;
    --navbar-height: 64px;
    --content-padding: 16px;
}
* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }
body { font-family: 'Cairo', sans-serif; background: #0a0f1e; color: #fff; min-height: 100vh; overflow-x: hidden; -webkit-font-smoothing: antialiased; }
img { max-width: 100%; display: block; }
button { font-family: inherit; cursor: pointer; border: none; background: none; color: inherit; }
a { color: inherit; text-decoration: none; }

/* ============ INTRO (قرآنك) ============ */
.intro-screen { position: fixed; inset: 0; background: linear-gradient(135deg, #0a0f1e 0%, #0d2b35 50%, #071915 100%); z-index: 10000; display: flex; align-items: center; justify-content: center; transition: opacity 0.8s ease; }
.intro-content { text-align: center; padding: 20px; }
.intro-logo-wrap { width: 120px; height: 120px; margin: 0 auto 25px; background: linear-gradient(135deg, var(--gold), var(--gold-dark)); border-radius: 30px; display: flex; align-items: center; justify-content: center; box-shadow: 0 20px 60px rgba(201,169,89,0.3); animation: introPulse 2s ease-in-out infinite; }
.intro-logo-wrap i { font-size: 60px; color: #0a0f1e; }
.intro-title { font-size: 42px; color: var(--gold); font-family: 'Amiri', serif; font-weight: 700; margin-bottom: 8px; letter-spacing: 1px; }
.intro-subtitle { font-size: 15px; color: var(--gold-light); opacity: 0.8; margin-bottom: 24px; }
.intro-bismillah { font-size: 20px; color: var(--gold-light); margin-top: 15px; opacity: 0.85; font-family: 'Amiri', serif; }
.intro-progress { width: 220px; height: 3px; background: rgba(201,169,89,0.2); margin: 35px auto 0; border-radius: 3px; overflow: hidden; }
.intro-progress-bar { width: 0%; height: 100%; background: linear-gradient(90deg, var(--gold-dark), var(--gold), var(--gold-light)); animation: introProgress 2.2s ease-in-out forwards; }
@keyframes introPulse { 0%,100%{transform:scale(1);box-shadow:0 20px 60px rgba(201,169,89,0.3)} 50%{transform:scale(1.05);box-shadow:0 25px 70px rgba(201,169,89,0.5)} }
@keyframes introProgress { from{width:0%} to{width:100%} }

/* ============ APP ============ */
.app-wrapper { width: 100%; background: var(--darker); min-height: 100vh; position: relative; }
.app-content { padding: 0 0 calc(var(--navbar-height) + var(--safe-bottom)); }
.tab-pane { display: none; }
.tab-pane.active { display: block; }

/* ============ PRAYER HERO ============ */
.prayer-hero { position: relative; width: 100%; height: 290px; overflow: hidden; background: linear-gradient(135deg, #0a2a25 0%, #071915 100%); }
.prayer-hero-bg { position: absolute; inset: 0; background-size: cover; background-position: center; background-repeat: no-repeat; opacity: 0; transition: opacity 1.5s ease; z-index: 1; }
.prayer-hero-bg.loaded { opacity: 1; }
.prayer-hero-gradient { position: absolute; inset: 0; z-index: 2; background: linear-gradient(180deg, rgba(7,19,28,0.55) 0%, rgba(7,19,28,0.35) 40%, rgba(7,19,28,0.75) 100%); }
.prayer-hero-inner { position: relative; z-index: 3; display: flex; flex-direction: column; padding: 14px 16px 16px; height: 100%; }
.prayer-hero-top { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.prayer-location-btn { display: inline-flex; align-items: center; gap: 6px; background: rgba(0,0,0,0.4); backdrop-filter: blur(10px); padding: 7px 13px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.15); font-size: 13px; font-weight: 700; cursor: pointer; white-space: nowrap; }
.prayer-location-btn i:first-child { color: var(--gold); font-size: 12px; }
.prayer-location-btn i:last-child { font-size: 9px; opacity: 0.7; }
.prayer-hijri { font-size: 12px; color: rgba(255,255,255,0.9); background: rgba(0,0,0,0.4); backdrop-filter: blur(10px); padding: 7px 13px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.15); white-space: nowrap; }
.prayer-hero-center { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; text-align: center; margin: 6px 0; }
.prayer-next-label { font-size: 13px; color: rgba(255,255,255,0.9); font-weight: 600; text-shadow: 0 2px 8px rgba(0,0,0,0.6); }
.prayer-next-label span { color: var(--gold); font-weight: 800; }
.prayer-countdown-hero { font-size: 44px; font-weight: 900; color: #fff; direction: ltr; font-family: 'Courier New', monospace; text-shadow: 0 4px 24px rgba(0,0,0,0.8); letter-spacing: 3px; line-height: 1; }
.prayer-hero-times { display: grid; grid-template-columns: repeat(6, 1fr); gap: 0; background: rgba(0,0,0,0.45); backdrop-filter: blur(15px); border-radius: 14px; padding: 10px 4px; border: 1px solid rgba(255,255,255,0.1); }
.prayer-time-col { display: flex; flex-direction: column; align-items: center; gap: 3px; padding: 3px 2px; position: relative; border-radius: 8px; transition: var(--transition); }
.prayer-time-col:not(:last-child)::after { content: ''; position: absolute; left: 0; top: 15%; bottom: 15%; width: 1px; background: rgba(255,255,255,0.12); }
.prayer-time-col.active { background: rgba(201,169,89,0.22); }
.prayer-time-name { font-size: 10px; color: rgba(255,255,255,0.72); font-weight: 600; white-space: nowrap; }
.prayer-time-col.active .prayer-time-name { color: var(--gold); font-weight: 800; }
.prayer-time-value { font-size: 11px; color: #fff; font-weight: 700; direction: ltr; white-space: nowrap; }

/* ============ CITY MODAL (إصلاح كامل) ============ */
.city-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.75); backdrop-filter: blur(6px); z-index: 9000; display: none; align-items: center; justify-content: center; padding: 20px; }
.city-modal.active { display: flex; animation: fadeIn 0.2s ease; }
@keyframes fadeIn { from{opacity:0} to{opacity:1} }
.city-modal-content { background: linear-gradient(145deg, #1a4755 0%, #0d2b35 100%); border-radius: 20px; width: 100%; max-width: 480px; max-height: 80vh; border: 2px solid rgba(201,169,89,0.3); box-shadow: 0 25px 70px rgba(0,0,0,0.6); display: flex; flex-direction: column; overflow: hidden; animation: popUp 0.25s cubic-bezier(0.34,1.56,0.64,1); }
@keyframes popUp { from{transform:scale(0.85);opacity:0} to{transform:scale(1);opacity:1} }
.city-modal-header { padding: 18px 20px; border-bottom: 1px solid rgba(201,169,89,0.2); display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; }
.city-modal-header h3 { color: var(--gold); font-size: 17px; font-weight: 800; display: flex; align-items: center; gap: 8px; }
.city-modal-header i.fa-times { color: var(--gold); font-size: 20px; cursor: pointer; padding: 6px; }
.city-modal-grid { padding: 12px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; overflow-y: auto; -webkit-overflow-scrolling: touch; }
.city-modal-item { padding: 14px 12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(201,169,89,0.15); border-radius: 10px; color: #fff; font-size: 14px; font-weight: 600; text-align: center; cursor: pointer; transition: all 0.2s; }
.city-modal-item:hover { background: rgba(201,169,89,0.15); border-color: var(--gold); }
.city-modal-item:active { transform: scale(0.96); }
.city-modal-item.selected { background: linear-gradient(135deg, var(--gold), var(--gold-dark)); color: #000; font-weight: 800; border-color: var(--gold); }

/* ============ SECTION HEADER ============ */
.section-header { display: flex; justify-content: space-between; align-items: center; padding: 0 var(--content-padding); margin: 22px 0 14px; }
.section-header h2 { font-size: 17px; font-weight: 800; color: var(--gold); display: flex; align-items: center; gap: 8px; }
.section-header h2 i { font-size: 16px; }
.section-more { font-size: 12px; color: var(--text-light); cursor: pointer; display: flex; align-items: center; gap: 4px; }

/* ============ CAROUSEL ============ */
.reciters-scroll { display: flex; gap: 14px; overflow-x: auto; overflow-y: hidden; padding: 4px var(--content-padding) 20px; -webkit-overflow-scrolling: touch; scrollbar-width: none; cursor: grab; user-select: none; scroll-snap-type: x proximity; }
.reciters-scroll::-webkit-scrollbar { display: none; }
.reciters-scroll.dragging { cursor: grabbing; scroll-snap-type: none; }
.reciters-scroll.dragging * { pointer-events: none; }
.carousel-reciter-item { flex: 0 0 auto; width: var(--carousel-size); display: flex; flex-direction: column; align-items: center; gap: 6px; cursor: pointer; scroll-snap-align: start; transition: transform 0.15s; }
.carousel-reciter-item:active { transform: scale(0.92); }
.carousel-avatar-wrapper { position: relative; width: calc(var(--carousel-size) - 6px); height: calc(var(--carousel-size) - 6px); border-radius: 50%; padding: 3px; background: linear-gradient(135deg, var(--gold), var(--gold-dark)); box-shadow: 0 4px 14px rgba(0,0,0,0.4); flex-shrink: 0; }
.carousel-avatar-wrapper img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; border: 2px solid var(--darker); background: #0a0f1e; pointer-events: none; }
.carousel-reciter-name { font-size: 11px; font-weight: 700; color: #fff; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; width: 100%; pointer-events: none; }

/* ============ RECENT VIDEOS ============ */
.recent-videos-scroll { display: flex; gap: 12px; overflow-x: auto; overflow-y: hidden; padding: 4px var(--content-padding) 20px; -webkit-overflow-scrolling: touch; scrollbar-width: none; cursor: grab; user-select: none; }
.recent-videos-scroll::-webkit-scrollbar { display: none; }
.recent-videos-scroll.dragging { cursor: grabbing; }
.recent-videos-scroll.dragging * { pointer-events: none; }
.recent-video-card { flex: 0 0 auto; width: 140px; aspect-ratio: 9 / 16; border-radius: 16px; overflow: hidden; position: relative; background: #0a0f1e; border: 2px solid rgba(201,169,89,0.25); cursor: pointer; transition: transform 0.2s, border-color 0.2s; }
.recent-video-card:hover { border-color: var(--gold); }
.recent-video-card:active { transform: scale(0.95); }
.recent-video-card img { width: 100%; height: 100%; object-fit: cover; pointer-events: none; }
.recent-video-play { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 40px; height: 40px; background: rgba(0,0,0,0.6); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--gold); font-size: 16px; backdrop-filter: blur(4px); border: 2px solid rgba(201,169,89,0.5); }
.recent-video-duration { position: absolute; bottom: 8px; right: 8px; background: rgba(0,0,0,0.85); color: #fff; font-size: 11px; padding: 3px 8px; border-radius: 6px; font-weight: 700; }

/* ============ QUICK ICONS ============ */
.quick-icons-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; padding: 0 var(--content-padding); margin: 24px 0; }
.quick-icon-card { display: flex; align-items: center; gap: 14px; padding: 18px 20px; background: linear-gradient(160deg, #1a4755 0%, #0f2b3d 100%); border: 2px solid rgba(201,169,89,0.2); border-radius: 18px; cursor: pointer; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
.quick-icon-card::before { content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, var(--icon-color, var(--gold)) 0%, transparent 70%); opacity: 0; transition: opacity 0.3s; pointer-events: none; }
.quick-icon-card:hover::before, .quick-icon-card:active::before { opacity: 0.12; }
.quick-icon-card:active { transform: scale(0.97); border-color: var(--icon-color, var(--gold)); }
.quick-icon-circle { width: 52px; height: 52px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 24px; color: var(--icon-color, var(--gold)); background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%); border: 2px solid var(--icon-color, var(--gold)); transition: all 0.3s; box-shadow: 0 0 16px var(--icon-color, var(--gold)), inset 0 0 16px rgba(0,0,0,0.3); flex-shrink: 0; }
.quick-icon-label { font-size: 15px; font-weight: 800; color: #fff; white-space: nowrap; letter-spacing: 0.3px; flex: 1; text-align: right; }

/* ============ SEARCH ============ */
.search-wrapper { position: relative; margin-bottom: 14px; }
.search-box { width: 100%; padding: 12px 18px; border-radius: 30px; border: 2px solid var(--gold); background: rgba(7,19,28,0.95); color: #fff; font-family: 'Cairo', sans-serif; font-size: 15px; outline: none; direction: rtl; }
.search-box::placeholder { color: rgba(255,255,255,0.35); }

/* ============ SURAH LIST ============ */
.surah-list { display: flex; flex-direction: column; gap: 10px; padding-bottom: 100px; }
.card { background: linear-gradient(145deg, #1a4755, #0f2b3d); border: 1px solid rgba(201,169,89,0.3); border-radius: 14px; padding: 0 18px; height: 78px; width: 100%; display: flex; align-items: center; gap: 14px; cursor: pointer; transition: all 0.2s; overflow: hidden; flex: 0 0 78px; box-sizing: border-box; }
.card:active { transform: scale(0.98); }
.num-badge { background: linear-gradient(145deg, var(--gold), var(--gold-dark)); color: #000; width: 52px; min-width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 20px; flex: 0 0 52px; }
.surah-info { flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 2px; min-width: 0; overflow: hidden; height: 100%; }
.surah-name { font-weight: 700; font-size: 17px; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.2; }
.surah-details { font-size: 12px; color: var(--text-light); white-space: nowrap; line-height: 1.2; }

/* ============ JUZ ============ */
.juz-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(110px, 1fr)); gap: 10px; }
.juz-box { background: linear-gradient(145deg, #1a4755, #0f2b3d); border: 1px solid rgba(201,169,89,0.3); border-radius: var(--radius-md); padding: 20px 8px; min-height: 90px; text-align: center; cursor: pointer; display: flex; flex-direction: column; justify-content: center; align-items: center; gap: 6px; transition: all 0.2s; }
.juz-box:active { transform: scale(0.95); }
.juz-box span { color: var(--gold); font-weight: 900; font-size: 28px; line-height: 1; }
.juz-box small { font-size: 12px; color: var(--text-light); font-weight: 600; }
.back-button { color: var(--gold); margin-bottom: 12px; cursor: pointer; display: inline-block; background: rgba(201,169,89,0.1); padding: 6px 16px; border-radius: 50px; font-size: 14px; }

/* ============ RECITERS GRID ============ */
.reciters-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; }
.reciter-card { background: linear-gradient(145deg, #1a4755, #0f2b3d); border: 1px solid rgba(201,169,89,0.25); border-radius: var(--radius-md); padding: 16px 12px; text-align: center; cursor: pointer; position: relative; transition: all 0.2s; }
.reciter-card:active { transform: scale(0.96); }
.reciter-card.locked { opacity: 0.6; cursor: default; }
.reciter-card img { width: 80px; height: 80px; border-radius: 50%; border: 3px solid var(--gold); object-fit: cover; margin: 0 auto 8px; }
.reciter-card h4 { color: var(--gold); font-size: 15px; }
.lock-overlay { position: absolute; top: 8px; left: 8px; background: rgba(0,0,0,0.7); border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; color: #ff4757; font-size: 14px; }

/* ============ BOOKS GRID ============ */
.books-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin-bottom: 20px; }
.book-card { background: linear-gradient(145deg, #1a4755, #0f2b3d); border: 2px solid rgba(201,169,89,0.2); border-radius: var(--radius-md); overflow: hidden; position: relative; cursor: pointer; transition: all 0.2s; }
.book-card:active { transform: scale(0.96); }
.book-cover { width: 100%; aspect-ratio: 2 / 3; object-fit: cover; background: #0a0f1e; border-bottom: 2px solid rgba(201,169,89,0.3); }
.book-info { padding: 10px 8px 12px; text-align: center; }
.book-title { font-weight: 700; color: var(--gold); font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.book-author { font-size: 11px; color: var(--text-light); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.book-pages { font-size: 10px; color: var(--text-light); opacity: 0.6; }
.book-category { position: absolute; top: 6px; right: 6px; background: rgba(0,0,0,0.75); padding: 2px 10px; border-radius: 30px; font-size: 9px; color: var(--gold); border: 1px solid var(--gold); }

/* ============ POPUPS ============ */
.reader-screen, .reciter-page, .video-player-modal, .azkar-page, .hadith-page, .tasbih-page, .calendar-page {
    position: fixed; top: 0; left: 0; width: 100%; height: 100vh; height: 100dvh;
    background: var(--darker); z-index: 2000; display: none; flex-direction: column;
}
.reader-screen.active, .reciter-page.active, .video-player-modal.active, .azkar-page.active, .hadith-page.active, .tasbih-page.active, .calendar-page.active { display: flex; }

/* ============ READER ============ */
.reader-header { background: var(--dark); color: var(--gold); padding: 12px 16px; display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid var(--gold); flex-shrink: 0; gap: 10px; }
.reader-header > i { font-size: 22px; cursor: pointer; }
.reader-title { font-size: 17px; font-weight: 700; flex: 1; }
.reader-header-actions { display: flex; align-items: center; gap: 6px; }
.reader-header-actions button { background: rgba(201,169,89,0.15); border: 1px solid var(--gold); color: var(--gold); width: 28px; height: 28px; border-radius: 50%; font-size: 13px; display: flex; align-items: center; justify-content: center; }
.quran-container { flex: 1; overflow: hidden; background: linear-gradient(145deg, #fefcf5, #f5f0e0); display: flex; flex-direction: column; align-items: center; justify-content: center; position: relative; }
.quran-container.night-mode { background: #1a1a2e; }
.quran-page-wrapper { width: 100%; height: 100%; display: flex; flex-direction: column; position: relative; }
.quran-page-img { width: 100%; height: 100%; object-fit: contain; background: #f5f0e0; max-width: 100%; user-select: none; }
.page-nav-overlay { position: absolute; inset: 0; display: flex; justify-content: space-between; align-items: center; padding: 0 8px; pointer-events: none; }
.page-nav-overlay .nav-btn { pointer-events: auto; width: 44px; height: 44px; background: rgba(201,169,89,0.15); backdrop-filter: blur(8px); border: 2px solid var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--gold); font-size: 20px; }
.page-nav-overlay .nav-btn:disabled { opacity: 0.2; pointer-events: none; }
.page-number-badge { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.6); backdrop-filter: blur(8px); color: var(--gold); padding: 6px 20px; border-radius: 30px; font-size: 15px; font-weight: 700; border: 1px solid rgba(201,169,89,0.3); pointer-events: none; }

/* ============ VIDEO PLAYER ============ */
.video-player-header { position: absolute; top: 0; left: 0; right: 0; background: linear-gradient(to bottom, rgba(0,0,0,0.8), transparent); padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; z-index: 10; }
.video-player-header i { color: #fff; font-size: 20px; cursor: pointer; background: rgba(0,0,0,0.4); width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
.video-player-header .video-title { color: #fff; font-size: 14px; background: rgba(0,0,0,0.4); padding: 4px 14px; border-radius: 20px; max-width: 60%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.video-player-container { flex: 1; display: flex; align-items: center; justify-content: center; background: #000; }
.video-player-container video { width: 100%; height: 100%; object-fit: contain; }
.video-player-container iframe { width: 100%; height: 100%; border: none; }

/* ============ RECITER PAGE ============ */
.reciter-page-header { background: linear-gradient(145deg, #1a4755, #0d2b35); padding: 15px 18px; display: flex; align-items: center; gap: 12px; border-bottom: 2px solid var(--gold); flex-shrink: 0; }
.reciter-page-header > i { font-size: 22px; cursor: pointer; color: var(--gold); }
.reciter-page-header img { width: 50px; height: 50px; border-radius: 50%; border: 2px solid var(--gold); object-fit: cover; }
.reciter-page-header .reciter-info { flex: 1; }
.reciter-page-header .reciter-info h3 { color: var(--gold); font-size: 17px; }
.reciter-page-header .reciter-info small { color: var(--text-light); font-size: 13px; }
.surah-audio-item { background: #1a4755; border-radius: var(--radius-md); padding: 12px 16px; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between; gap: 8px; transition: all 0.2s; }
.surah-audio-item:hover { background: #1e5566; }
.play-audio-btn, .download-audio-btn { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; }
.play-audio-btn { background: var(--gold); color: #000; }
.download-audio-btn { background: #2d6a4f; color: #fff; }

/* ============ REELS ============ */
.reels-tab-container { width: 100%; height: 100vh; height: 100dvh; overflow-y: scroll; scroll-snap-type: y mandatory; background: #000; scroll-behavior: smooth; overscroll-behavior-y: contain; -webkit-overflow-scrolling: touch; }
.reels-tab-container::-webkit-scrollbar { display: none; }
.reels-tab-container { scrollbar-width: none; }
.reel-item-modern { width: 100%; height: 100vh; height: 100dvh; scroll-snap-align: start; scroll-snap-stop: always; position: relative; background: #000; display: flex; align-items: center; justify-content: center; overflow: hidden; }
.reel-video-wrapper { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; }
.reel-poster { position: absolute; inset: 0; background-size: cover; background-position: center; filter: blur(20px); transform: scale(1.1); opacity: 0.4; z-index: 0; }
.reel-video-player { position: relative; z-index: 1; width: 100%; height: 100%; object-fit: contain; cursor: pointer; background: #000; }
.reel-iframe { position: relative; z-index: 1; width: 100%; height: 100%; border: none; pointer-events: none; background: #000; }
.reel-iframe.active { pointer-events: auto; }
.reel-loading { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 5; pointer-events: none; color: var(--gold); font-size: 32px; }
.reel-loading.hidden { display: none; }
.reel-left-side { position: absolute; bottom: 100px; left: 12px; display: flex; flex-direction: column; align-items: center; gap: 14px; z-index: 12; }
.reel-reciter-avatar { cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 2px; transition: transform 0.2s; }
.reel-reciter-avatar:active { transform: scale(0.9); }
.reel-reciter-avatar img { width: 52px; height: 52px; border-radius: 50%; border: 2.5px solid var(--gold); object-fit: cover; background: #0a0f1e; }
.reciter-name-tag { font-size: 9px; color: var(--gold); background: rgba(0,0,0,0.6); padding: 2px 10px; border-radius: 10px; white-space: nowrap; max-width: 65px; overflow: hidden; text-overflow: ellipsis; }
.reel-action-btn-wrapper { display: flex; flex-direction: column; align-items: center; gap: 2px; cursor: pointer; transition: transform 0.15s; }
.reel-action-btn-wrapper:active { transform: scale(0.9); }
.reel-action-circle { width: 44px; height: 44px; background: rgba(15,43,61,0.7); border: 1.5px solid rgba(201,169,89,0.3); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; color: #fff; backdrop-filter: blur(4px); transition: all 0.2s; }
.reel-action-btn-wrapper span { font-size: 10px; font-weight: 600; color: rgba(255,255,255,0.85); text-shadow: 0 1px 6px rgba(0,0,0,0.8); }
.reel-action-circle.liked { color: #fff; background: #ff4757; border-color: #fff; animation: heartBeat 0.3s; }
.reel-action-circle.download { background: #2d6a4f; border-color: #2d6a4f; }
@keyframes heartBeat { 0% { transform: scale(1); } 50% { transform: scale(1.3); } 100% { transform: scale(1); } }
.reel-bottom-meta { position: absolute; bottom: 90px; right: 16px; left: 80px; z-index: 10; text-align: right; text-shadow: 0 2px 8px rgba(0,0,0,0.9); }
.reel-meta-title { font-size: 17px; font-weight: bold; color: var(--gold); display: flex; align-items: center; gap: 6px; margin-bottom: 4px; }
.reel-meta-desc { font-size: 12px; color: rgba(255,255,255,0.85); line-height: 1.4; }

/* ============ REELS PROGRESS - تصميم حديث ============ */
.reel-progress-holder { position: absolute; bottom: 70px; left: 12px; right: 12px; z-index: 15; opacity: 0; transition: opacity 0.3s; }
.reel-item-modern:hover .reel-progress-holder, .reel-item-modern.paused-mode .reel-progress-holder { opacity: 1; }
.reel-progress-modern { width: 100%; display: flex; align-items: center; gap: 10px; direction: ltr; }
.reel-progress-modern .time-display { color: rgba(255,255,255,0.85); font-size: 10px; font-family: 'Courier New', monospace; min-width: 32px; text-shadow: 0 1px 4px rgba(0,0,0,0.9); }
.reel-progress-modern .track-wrapper { flex: 1; height: 3px; background: rgba(255,255,255,0.2); border-radius: 20px; position: relative; cursor: pointer; }
.reel-progress-modern .track-fill { height: 100%; background: linear-gradient(90deg, var(--gold), var(--gold-light)); border-radius: 20px; width: 0%; transition: width 0.1s linear; box-shadow: 0 0 8px rgba(201,169,89,0.6); }
.reel-progress-modern .track-wrapper input[type="range"] { position: absolute; top: -6px; left: 0; width: 100%; height: 15px; -webkit-appearance: none; appearance: none; background: transparent; cursor: pointer; opacity: 0; }

/* ============ PROFILE ============ */
.profile-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; height: 100dvh; background: #000; z-index: 8000; overflow-y: auto; transform: translateY(100%); transition: transform 0.35s cubic-bezier(0.4, 0, 0.2, 1); -webkit-overflow-scrolling: touch; scrollbar-width: none; }
.profile-overlay::-webkit-scrollbar { display: none; }
.profile-overlay.active { transform: translateY(0); }
.profile-header { position: sticky; top: 0; background: linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.85) 100%); backdrop-filter: blur(16px); padding: calc(12px + var(--safe-top)) 16px 12px; display: flex; align-items: center; justify-content: space-between; z-index: 100; min-height: 56px; }
.profile-header-btn { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 22px; cursor: pointer; flex-shrink: 0; background: transparent; border: none; transition: transform 0.2s; }
.profile-header-btn:active { transform: scale(0.9); }
.profile-header-right { display: flex; gap: 8px; }
.profile-body { padding: 0 0 40px; }
.profile-top-section { display: flex; flex-direction: column; align-items: center; padding: 20px 20px 16px; background: #000; }
.profile-avatar { width: 96px; height: 96px; border-radius: 50%; object-fit: cover; margin-bottom: 12px; background: #1a1a1a; border: 2px solid rgba(255,255,255,0.1); }
.profile-username-handle { font-size: 15px; color: #fff; font-weight: 700; margin-bottom: 14px; }
.profile-stats-row { display: flex; gap: 32px; margin-bottom: 16px; }
.profile-stat { display: flex; flex-direction: column; align-items: center; gap: 2px; }
.profile-stat .num { font-size: 17px; font-weight: 900; color: #fff; direction: ltr; }
.profile-stat .lbl { font-size: 12px; color: rgba(255,255,255,0.6); font-weight: 500; }
.profile-bio { text-align: center; color: rgba(255,255,255,0.9); font-size: 13px; line-height: 1.5; padding: 0 20px; margin-bottom: 16px; white-space: pre-line; }
.profile-tabs { display: flex; border-top: 1px solid rgba(255,255,255,0.08); border-bottom: 1px solid rgba(255,255,255,0.08); background: #000; position: sticky; top: 56px; z-index: 50; }
.profile-tab { flex: 1; padding: 14px; text-align: center; color: rgba(255,255,255,0.5); font-size: 22px; cursor: pointer; border: none; background: none; position: relative; transition: color 0.2s; font-family: inherit; }
.profile-tab.active { color: #fff; }
.profile-tab.active::after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 40%; height: 2px; background: #fff; }
.profile-videos-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px; background: #000; }
.profile-video-item { position: relative; aspect-ratio: 9 / 16; background: #0a0f1e; overflow: hidden; cursor: pointer; transition: transform 0.15s; }
.profile-video-item:active { transform: scale(0.97); }
.profile-video-item img { width: 100%; height: 100%; object-fit: cover; }
.profile-video-overlay { position: absolute; bottom: 0; left: 0; right: 0; padding: 12px 6px 6px; background: linear-gradient(to top, rgba(0,0,0,0.9), transparent); display: flex; align-items: center; justify-content: flex-start; font-size: 12px; color: #fff; font-weight: 700; gap: 4px; }
.profile-video-play-icon { position: absolute; top: 8px; left: 8px; color: #fff; font-size: 14px; text-shadow: 0 2px 8px rgba(0,0,0,0.9); pointer-events: none; }
.profile-empty-state { grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: rgba(255,255,255,0.4); font-size: 14px; }
.profile-empty-state i { font-size: 48px; margin-bottom: 15px; display: block; opacity: 0.4; }

/* ============ SHARE POPUP ============ */
.share-popup-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.75); backdrop-filter: blur(8px); z-index: 11000; display: none; align-items: flex-end; justify-content: center; }
.share-popup-overlay.active { display: flex; }
.share-popup-content { background: linear-gradient(145deg, #1a4755, #0d2b35); border-radius: 30px 30px 0 0; padding: 25px 20px 30px; width: 100%; max-width: 500px; animation: slideUpSheet 0.3s ease; }
@keyframes slideUpSheet { from { transform: translateY(100%); } to { transform: translateY(0); } }
.share-popup-title { font-size: 18px; font-weight: 700; color: var(--gold); text-align: center; margin-bottom: 20px; }
.share-popup-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.share-popup-item { display: flex; flex-direction: column; align-items: center; gap: 6px; cursor: pointer; padding: 10px 0; }
.share-icon { width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; color: #fff; }
.share-icon.whatsapp { background: #25D366; }
.share-icon.facebook { background: #1877F2; }
.share-icon.copy { background: var(--gold); color: #000; }
.share-icon.system { background: #6c5ce7; }
.share-popup-item span { font-size: 11px; color: var(--text-light); }
.share-popup-close { text-align: center; margin-top: 16px; color: var(--text-light); font-size: 14px; cursor: pointer; }

/* ============ PDF READER ============ */
.pdf-reader-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.92); z-index: 30000; display: none; flex-direction: column; }
.pdf-reader-modal.active { display: flex; }
.pdf-reader-header { background: #0d2b35; padding: 10px 16px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--gold); gap: 8px; }
.pdf-title { color: var(--gold); font-size: 15px; font-weight: 700; max-width: 40%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.pdf-tools { display: flex; align-items: center; gap: 8px; }
.pdf-tools input[type="number"] { width: 46px; padding: 4px 6px; border-radius: 6px; border: 1px solid var(--gold); background: rgba(255,255,255,0.08); color: #fff; font-size: 12px; text-align: center; }
.pdf-page-indicator { color: #fff; font-size: 12px; padding: 2px 8px; background: rgba(255,255,255,0.08); border-radius: 20px; }
.pdf-close { color: #fff; font-size: 20px; cursor: pointer; background: rgba(255,255,255,0.1); width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
.pdf-reader-body { flex: 1; overflow-y: auto; background: #1a1a2e; display: flex; justify-content: center; padding: 10px; }
.pdf-reader-body canvas { max-width: 100%; height: auto; box-shadow: 0 0 30px rgba(0,0,0,0.5); background: #fff; border-radius: 4px; }
.pdf-reader-controls { background: #0d2b35; padding: 8px 12px; display: flex; justify-content: center; align-items: center; gap: 12px; border-top: 1px solid var(--gold); }
.pdf-reader-controls button { background: var(--gold); color: #000; padding: 5px 12px; border-radius: 30px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 5px; font-size: 12px; }
.pdf-reader-controls .page-num { color: #fff; font-size: 13px; padding: 0 8px; }

/* ============ TOAST + LOADER ============ */
.custom-toast { position: fixed; bottom: calc(160px + var(--safe-bottom)); left: 50%; transform: translateX(-50%) translateY(20px); background: linear-gradient(135deg, #1a4755 0%, #0f2b3d 100%); border: 2px solid var(--gold); color: #fff; padding: 12px 24px; border-radius: 30px; z-index: 11000; font-weight: 600; text-align: center; pointer-events: none; opacity: 0; transition: all 0.4s ease; font-size: 14px; max-width: 90%; box-shadow: 0 10px 30px rgba(0,0,0,0.4); }
.custom-toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
.loader { text-align: center; padding: 40px 20px; color: var(--text-light); display: flex; flex-direction: column; align-items: center; gap: 12px; }
.loader i { font-size: 30px; color: var(--gold); animation: spin 1s linear infinite; }
@keyframes spin { from{transform:rotate(0)} to{transform:rotate(360deg)} }
.skeleton { background: linear-gradient(90deg, #1a1a2e 25%, #2a2a4e 50%, #1a1a2e 75%); background-size: 200% 100%; animation: skeleton 1.5s infinite; border-radius: var(--radius-md); }
@keyframes skeleton { 0%{background-position:200% 0} 100%{background-position:-200% 0} }

/* ============ NAV BAR ============ */
.nav-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: rgba(15,43,61,0.97); backdrop-filter: blur(12px); display: flex; justify-content: space-around; padding: 4px 0 calc(8px + var(--safe-bottom)); border-top: 1px solid var(--gold); z-index: 2500; overflow: hidden; }
.nav-item { color: #7f8c8d; text-align: center; font-size: 10px; cursor: pointer; padding: 4px 6px; border-radius: 50px; flex: 1; position: relative; transition: var(--transition); }
.nav-item i { font-size: 22px; display: block; margin-bottom: 1px; transition: var(--transition); }
.nav-item.active { color: var(--gold); background: rgba(201,169,89,0.08); }
.nav-item.active i { transform: translateY(-2px); }
.scroll-top-btn { position: fixed; bottom: calc(90px + var(--safe-bottom)); right: 16px; width: 44px; height: 44px; background: var(--gold); color: #000; border: none; border-radius: 50%; font-size: 18px; cursor: pointer; z-index: 3000; display: none; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(201,169,89,0.4); }
.scroll-top-btn.visible { display: flex; }

/* ============ AZKAR ============ */
.azkar-page { z-index: 3000; background: #0a1a15; }
.azkar-header { background: linear-gradient(180deg, #0a2a25 0%, #0a1a15 100%); padding: calc(16px + var(--safe-top)) 20px 12px; display: flex; align-items: center; gap: 14px; flex-shrink: 0; border-bottom: 1px solid rgba(16,185,129,0.2); }
.azkar-header > i { font-size: 22px; cursor: pointer; color: #10b981; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3); border-radius: 50%; flex-shrink: 0; }
.azkar-header h2 { color: #10b981; font-size: 22px; flex: 1; font-weight: 900; text-align: center; padding-left: 40px; }
.azkar-cats-bar { display: flex; gap: 6px; overflow-x: auto; padding: 12px 16px; background: #0a2a25; border-bottom: 1px solid rgba(16,185,129,0.15); scrollbar-width: none; scroll-behavior: smooth; }
.azkar-cats-bar::-webkit-scrollbar { display: none; }
.azkar-cat-pill { flex: 0 0 auto; padding: 8px 18px; border-radius: 30px; background: rgba(255,255,255,0.04); border: 1px solid rgba(16,185,129,0.2); color: rgba(255,255,255,0.75); font-size: 14px; font-weight: 700; cursor: pointer; white-space: nowrap; transition: all 0.25s; font-family: inherit; }
.azkar-cat-pill:active { transform: scale(0.95); }
.azkar-cat-pill.active { background: linear-gradient(135deg, #10b981, #059669); color: #fff; border-color: #10b981; box-shadow: 0 4px 14px rgba(16,185,129,0.4); }
.azkar-list-body { flex: 1; overflow-y: auto; padding: 0; background: #0a1a15; }
.azkar-item-row { padding: 20px 24px; border-bottom: 1px solid rgba(16,185,129,0.12); display: flex; align-items: center; justify-content: space-between; gap: 12px; cursor: pointer; transition: background 0.2s; }
.azkar-item-row:hover { background: rgba(16,185,129,0.04); }
.azkar-item-row .row-title { color: #fff; font-size: 17px; font-weight: 700; flex: 1; line-height: 1.4; }
.azkar-item-row .row-arrow { color: #10b981; font-size: 16px; }
.azkar-content-view { flex: 1; overflow-y: auto; padding: 20px; background: #0a1a15; display: none; }
.azkar-content-view.active { display: block; }
.azkar-content-title { color: #fff; font-size: 18px; font-weight: 800; text-align: center; padding: 16px 0 24px; border-bottom: 1px solid rgba(16,185,129,0.15); margin-bottom: 20px; }
.zikr-text-block { padding: 22px 4px; border-bottom: 1px solid rgba(16,185,129,0.15); color: #fff; font-size: 19px; line-height: 2.1; font-family: 'Amiri', serif; text-align: right; }
.zikr-text-block:last-child { border-bottom: none; }
.zikr-text-block .source-text { color: #10b981; font-size: 14px; font-family: 'Cairo', sans-serif; display: block; margin-top: 10px; }
.azkar-back-btn { display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.3); border-radius: 50px; color: #10b981; font-size: 14px; font-weight: 700; cursor: pointer; margin-bottom: 16px; font-family: inherit; }
.azkar-back-btn:active { transform: scale(0.95); }

/* ============ HADITH ============ */
.hadith-page { z-index: 3000; background: #0a1a15; }
.hadith-header { background: linear-gradient(180deg, #0a2a25 0%, #0a1a15 100%); padding: calc(16px + var(--safe-top)) 20px 12px; display: flex; align-items: center; gap: 14px; flex-shrink: 0; border-bottom: 1px solid rgba(16,185,129,0.2); }
.hadith-header > i { font-size: 22px; cursor: pointer; color: #10b981; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3); border-radius: 50%; flex-shrink: 0; }
.hadith-header h2 { color: #10b981; font-size: 22px; flex: 1; font-weight: 900; text-align: center; padding-left: 40px; }
.hadith-list-body { flex: 1; overflow-y: auto; background: #0a1a15; }
.hadith-content-view { flex: 1; overflow-y: auto; padding: 20px; background: #0a1a15; display: none; }
.hadith-content-view.active { display: block; }
.hadith-item-row { padding: 20px 24px; border-bottom: 1px solid rgba(16,185,129,0.12); display: flex; align-items: center; justify-content: space-between; gap: 12px; cursor: pointer; transition: background 0.2s; }
.hadith-item-row:hover { background: rgba(16,185,129,0.04); }
.hadith-item-row .row-title { color: #fff; font-size: 16px; font-weight: 700; flex: 1; line-height: 1.5; }
.hadith-item-row .row-arrow { color: #10b981; font-size: 16px; }
.hadith-text-block { padding: 22px 4px; border-bottom: 1px solid rgba(16,185,129,0.15); color: #fff; font-size: 19px; line-height: 2.1; font-family: 'Amiri', serif; text-align: right; }
.hadith-text-block .meta-text { color: #10b981; font-size: 14px; font-family: 'Cairo', sans-serif; display: block; margin-top: 10px; }

/* ============ TASBIH ============ */
.tasbih-page { z-index: 3000; background: radial-gradient(circle at 50% 40%, #0d2b35 0%, #07131c 70%); }
.tasbih-header { padding: calc(16px + var(--safe-top)) 20px 12px; display: flex; align-items: center; gap: 14px; flex-shrink: 0; }
.tasbih-header > i { font-size: 22px; cursor: pointer; color: var(--gold); width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: rgba(201,169,89,0.1); border-radius: 50%; border: 1px solid rgba(201,169,89,0.3); flex-shrink: 0; }
.tasbih-header h2 { color: var(--gold); font-size: 20px; flex: 1; font-weight: 900; text-align: center; padding-left: 40px; }
.tasbih-body { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; gap: 28px; }
.tasbih-count-wrap { position: relative; width: 260px; height: 260px; display: flex; align-items: center; justify-content: center; }
.tasbih-ring { position: absolute; inset: 0; border-radius: 50%; border: 2px solid rgba(201,169,89,0.25); }
.tasbih-ring-inner { position: absolute; inset: 20px; border-radius: 50%; border: 1px dashed rgba(201,169,89,0.2); animation: rotateSlow 40s linear infinite; }
@keyframes rotateSlow { from { transform: rotate(0); } to { transform: rotate(360deg); } }
.tasbih-count-number { font-size: 100px; font-weight: 900; color: var(--gold); direction: ltr; line-height: 1; text-shadow: 0 0 50px rgba(201,169,89,0.4); user-select: none; font-family: 'Cairo', sans-serif; position: relative; z-index: 2; transition: transform 0.15s; }
.tasbih-count-number.pulse { transform: scale(1.15); }
.tasbih-tap-btn { width: 100%; max-width: 280px; padding: 22px; border-radius: 50px; background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dark) 100%); color: #000; font-size: 22px; font-weight: 900; cursor: pointer; box-shadow: 0 10px 40px rgba(201,169,89,0.4); transition: all 0.1s; font-family: inherit; border: none; letter-spacing: 2px; }
.tasbih-tap-btn:active { transform: scale(0.96); }
.tasbih-actions-row { display: flex; gap: 12px; width: 100%; max-width: 280px; }
.tasbih-action-btn { flex: 1; padding: 14px; border-radius: 16px; background: rgba(201,169,89,0.06); border: 1px solid rgba(201,169,89,0.25); color: var(--gold); font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit; display: flex; align-items: center; justify-content: center; gap: 6px; transition: all 0.2s; }
.tasbih-action-btn:active { transform: scale(0.96); background: rgba(201,169,89,0.12); }
.tasbih-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.85); backdrop-filter: blur(8px); z-index: 10000; display: none; align-items: center; justify-content: center; padding: 20px; }
.tasbih-modal.active { display: flex; }
.tasbih-modal-content { background: linear-gradient(145deg, #1a4755, #0f2b3d); border-radius: 24px; padding: 28px 24px; width: 100%; max-width: 340px; border: 2px solid rgba(201,169,89,0.3); box-shadow: 0 20px 60px rgba(0,0,0,0.5); animation: popIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
@keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.tasbih-modal-content h3 { color: var(--gold); font-size: 18px; font-weight: 900; text-align: center; margin-bottom: 18px; }
.tasbih-target-options { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 18px; }
.tasbih-target-opt { padding: 14px; border-radius: 12px; background: rgba(201,169,89,0.08); border: 1px solid rgba(201,169,89,0.25); color: var(--gold); font-size: 18px; font-weight: 900; cursor: pointer; font-family: inherit; transition: all 0.2s; }
.tasbih-target-opt:hover, .tasbih-target-opt:active { background: rgba(201,169,89,0.2); transform: scale(0.96); }
.tasbih-modal-actions { display: flex; gap: 10px; }
.tasbih-modal-actions button { flex: 1; padding: 12px; border-radius: 12px; font-size: 14px; font-weight: 700; cursor: pointer; font-family: inherit; }
.tasbih-modal-cancel { background: rgba(255,255,255,0.06); color: #fff; border: 1px solid rgba(255,255,255,0.1); }
.tasbih-modal-confirm { background: linear-gradient(135deg, #ef4444, #dc2626); color: #fff; border: none; }

/* ============ CALENDAR ============ */
.calendar-page { z-index: 3000; background: linear-gradient(180deg, #0a1a15 0%, #07131c 100%); }
.calendar-header { background: linear-gradient(180deg, #0a2a25 0%, #0a1a15 100%); padding: calc(16px + var(--safe-top)) 20px 12px; display: flex; align-items: center; gap: 14px; flex-shrink: 0; border-bottom: 1px solid rgba(16,185,129,0.2); }
.calendar-header > i { font-size: 22px; cursor: pointer; color: #10b981; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3); border-radius: 50%; flex-shrink: 0; }
.calendar-header h2 { color: #10b981; font-size: 22px; flex: 1; font-weight: 900; text-align: center; padding-left: 40px; }
.calendar-body { flex: 1; overflow-y: auto; padding: 16px; }
.calendar-today { background: linear-gradient(145deg, #0a2a25 0%, #071915 100%); border-radius: 20px; padding: 24px; text-align: center; margin-bottom: 20px; border: 1px solid rgba(16,185,129,0.3); }
.calendar-today .day-name { font-size: 16px; color: #34d399; font-weight: 700; margin-bottom: 10px; }
.calendar-today .hijri-date { font-size: 32px; color: #fff; font-weight: 900; margin-bottom: 6px; font-family: 'Amiri', serif; }
.calendar-today .gregorian-date { font-size: 16px; color: var(--text-light); }
.calendar-nav { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; padding: 0 4px; }
.calendar-nav button { width: 44px; height: 44px; border-radius: 50%; background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.3); color: #34d399; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
.calendar-nav button:active { transform: scale(0.92); background: rgba(16,185,129,0.2); }
.calendar-nav .month-title { font-size: 17px; font-weight: 800; color: #fff; }
.calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; background: linear-gradient(145deg, #0a2a25 0%, #071915 100%); padding: 14px; border-radius: 20px; border: 1px solid rgba(16,185,129,0.2); }
.calendar-day-name { text-align: center; padding: 10px 4px; font-size: 12px; color: #34d399; font-weight: 800; }
.calendar-day { text-align: center; padding: 12px 4px 14px; border-radius: 12px; font-size: 15px; color: #fff; cursor: pointer; transition: all 0.2s; position: relative; font-weight: 600; user-select: none; }
.calendar-day:hover { background: rgba(16,185,129,0.15); }
.calendar-day:active { transform: scale(0.92); }
.calendar-day.today { background: linear-gradient(135deg, #10b981, #059669); color: #fff; font-weight: 900; box-shadow: 0 4px 16px rgba(16,185,129,0.5); }
.calendar-day.other-month { opacity: 0.25; }
.calendar-day .hijri-small { display: block; font-size: 9px; color: var(--gold); margin-top: 3px; font-weight: 700; }
.calendar-day.selected { background: linear-gradient(135deg, #10b981, #059669); color: #fff; box-shadow: 0 4px 16px rgba(16,185,129,0.5); }
.calendar-day-detail { margin-top: 16px; padding: 20px; background: linear-gradient(145deg, #0a2a25 0%, #071915 100%); border-radius: 16px; border: 1px solid rgba(16,185,129,0.3); display: none; }
.calendar-day-detail.active { display: block; }
.calendar-day-detail h4 { color: #34d399; font-size: 16px; margin-bottom: 12px; font-weight: 800; }
.calendar-day-detail .detail-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid rgba(16,185,129,0.15); font-size: 14px; }
.calendar-day-detail .detail-row:last-child { border-bottom: none; }
.calendar-day-detail .detail-row .label { color: var(--text-light); }
.calendar-day-detail .detail-row .value { color: #fff; font-weight: 700; }
.calendar-prayer-times { margin-top: 16px; padding: 16px; background: linear-gradient(145deg, #0a2a25 0%, #071915 100%); border-radius: 16px; border: 1px solid rgba(16,185,129,0.3); display: none; }
.calendar-prayer-times.active { display: block; }
.calendar-prayer-times h4 { color: #34d399; font-size: 15px; margin-bottom: 12px; font-weight: 800; display: flex; align-items: center; gap: 6px; }
.calendar-prayer-times .pt-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.calendar-prayer-times .pt-row { display: flex; justify-content: space-between; padding: 10px 12px; background: rgba(255,255,255,0.03); border-radius: 8px; font-size: 13px; }
.calendar-prayer-times .pt-row .name { color: var(--text-light); }
.calendar-prayer-times .pt-row .value { color: #fff; font-weight: 700; direction: ltr; }

/* ============ SPOTIFY PLAYER ============ */
.spotify-player { position: fixed; inset: 0; background: linear-gradient(180deg, #0a1a25 0%, #061018 100%); z-index: 9000; display: none; flex-direction: column; overflow: hidden; }
.spotify-player.active { display: flex; }
.spotify-player-header { display: flex; align-items: center; justify-content: space-between; padding: calc(14px + var(--safe-top)) 20px 8px; flex-shrink: 0; }
.spotify-player-header-btn { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 20px; cursor: pointer; background: transparent; border: none; transition: transform 0.2s; }
.spotify-player-header-btn:active { transform: scale(0.9); }
.spotify-player-header-center { text-align: center; flex: 1; }
.spotify-player-header-center .small-title { font-size: 11px; color: rgba(255,255,255,0.6); text-transform: uppercase; letter-spacing: 1px; font-weight: 700; }
.spotify-player-header-center .playing-from { font-size: 13px; color: #fff; font-weight: 700; margin-top: 2px; }
.spotify-player-body { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; gap: 28px; overflow-y: auto; }
.spotify-cover-wrap { width: min(75vw, 320px); aspect-ratio: 1; border-radius: 20px; overflow: hidden; box-shadow: 0 30px 80px rgba(0,0,0,0.6), 0 0 60px rgba(201,169,89,0.2); position: relative; flex-shrink: 0; }
.spotify-cover-wrap img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s; }
.spotify-cover-wrap.playing img { transform: scale(1.02); }
.spotify-info-row { width: 100%; max-width: 500px; display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 0 4px; }
.spotify-info-text { flex: 1; min-width: 0; }
.spotify-info-text .song-title { font-size: 22px; font-weight: 900; color: #fff; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.spotify-info-text .song-artist { font-size: 15px; color: rgba(255,255,255,0.7); font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.spotify-info-actions { display: flex; gap: 8px; flex-shrink: 0; }
.spotify-info-actions button { width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 22px; background: transparent; border: none; cursor: pointer; transition: all 0.2s; }
.spotify-info-actions button:active { transform: scale(0.9); }
.spotify-info-actions button.liked { color: #1ed760; }
.spotify-info-actions button.added { color: #1ed760; }
.spotify-progress-wrap { width: 100%; max-width: 500px; padding: 0 4px; }
.spotify-progress-bar { width: 100%; height: 4px; background: rgba(255,255,255,0.2); border-radius: 20px; position: relative; cursor: pointer; }
.spotify-progress-fill { height: 100%; background: #1ed760; border-radius: 20px; width: 0%; transition: width 0.1s linear; position: relative; }
.spotify-progress-fill::after { content: ''; position: absolute; right: -6px; top: 50%; transform: translateY(-50%); width: 12px; height: 12px; background: #fff; border-radius: 50%; box-shadow: 0 2px 6px rgba(0,0,0,0.4); opacity: 0; transition: opacity 0.2s; }
.spotify-progress-bar:hover .spotify-progress-fill::after { opacity: 1; }
.spotify-progress-bar input[type="range"] { position: absolute; top: -8px; left: 0; width: 100%; height: 20px; -webkit-appearance: none; appearance: none; background: transparent; cursor: pointer; }
.spotify-progress-times { display: flex; justify-content: space-between; margin-top: 8px; font-size: 11px; color: rgba(255,255,255,0.5); font-family: monospace; direction: ltr; }
.spotify-controls { width: 100%; max-width: 500px; display: flex; align-items: center; justify-content: space-between; padding: 0 4px; gap: 8px; }
.spotify-ctrl-btn { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 22px; background: transparent; border: none; cursor: pointer; transition: all 0.15s; border-radius: 50%; }
.spotify-ctrl-btn:active { transform: scale(0.9); }
.spotify-ctrl-btn.active { color: #1ed760; }
.spotify-play-btn { width: 68px; height: 68px; background: #fff; color: #000; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; cursor: pointer; border: none; transition: all 0.15s; box-shadow: 0 8px 24px rgba(255,255,255,0.2); }
.spotify-play-btn:active { transform: scale(0.92); }
.spotify-bottom-actions { width: 100%; max-width: 500px; display: flex; align-items: center; justify-content: space-between; padding: 0 4px 20px; gap: 16px; margin-top: auto; }
.spotify-bottom-actions button { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 12px; background: transparent; color: rgba(255,255,255,0.7); font-size: 11px; font-weight: 600; cursor: pointer; border: none; font-family: inherit; transition: all 0.2s; border-radius: 12px; }
.spotify-bottom-actions button:hover, .spotify-bottom-actions button:active { color: #fff; background: rgba(255,255,255,0.05); }
.spotify-bottom-actions button i { font-size: 20px; margin-bottom: 4px; }

/* ============ MINI PLAYER ============ */
.mini-player { position: fixed; bottom: calc(var(--navbar-height) + var(--safe-bottom)); left: 0; right: 0; height: 56px; background: linear-gradient(180deg, #1a3a4a 0%, #0f2530 100%); border-top: 1px solid rgba(201,169,89,0.3); z-index: 2400; display: none; align-items: center; padding: 0 12px; gap: 12px; cursor: pointer; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
.mini-player.visible { display: flex; }
.mini-player-cover { width: 40px; height: 40px; border-radius: 6px; object-fit: cover; flex-shrink: 0; background: #0a0f1e; }
.mini-player-info { flex: 1; min-width: 0; text-align: right; }
.mini-player-title { font-size: 13px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.mini-player-sub { font-size: 11px; color: rgba(255,255,255,0.6); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.mini-player-controls { display: flex; align-items: center; gap: 6px; }
.mini-player-controls button { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; color: #fff; background: transparent; border: none; cursor: pointer; font-size: 16px; border-radius: 50%; }
.mini-player-controls button:active { transform: scale(0.9); }
.mini-player-controls .play-btn { background: #fff; color: #000; width: 40px; height: 40px; }
.mini-player-progress { position: absolute; bottom: 0; left: 0; width: 100%; height: 2px; background: rgba(255,255,255,0.1); }
.mini-player-progress-fill { height: 100%; background: #1ed760; width: 0%; transition: width 0.1s linear; }

/* ============ DESKTOP ============ */
.desktop-sidebar { display: none; }

@media (min-width: 1024px) {
    :root { --content-padding: 24px; --navbar-height: 0px; }
    body { background: linear-gradient(135deg, #0a0f1e 0%, #0d2b35 50%, #0a0f1e 100%); display: block; }
    .app-wrapper { display: grid; grid-template-columns: var(--sidebar-width) 1fr; gap: 24px; max-width: 1400px; margin: 0 auto; padding: 24px; min-height: 100vh; background: transparent; }
    .desktop-sidebar { display: flex; flex-direction: column; position: sticky; top: 24px; height: calc(100vh - 48px); background: linear-gradient(180deg, #0d2b35 0%, #07131c 100%); border-radius: 24px; border: 1px solid rgba(201,169,89,0.15); padding: 24px 16px; overflow-y: auto; order: 0; }
    .app-content { order: 1; background: var(--darker); border-radius: 24px; overflow: hidden; min-height: calc(100vh - 48px); box-shadow: 0 0 60px rgba(0,0,0,0.4); padding-bottom: 0; }
    .nav-bar { display: none; }
    .mini-player { left: var(--sidebar-width); right: 0; bottom: 0; }
    #surahsTab, #juzTab, #audiosTab, #booksTab { padding: 24px; }
    .prayer-hero { height: 340px; }
    .prayer-countdown-hero { font-size: 56px; }
    :root { --carousel-size: 96px; }
    .recent-video-card { width: 160px; }
    .books-grid { grid-template-columns: repeat(4, 1fr); gap: 18px; }
    .reciters-grid { grid-template-columns: repeat(3, 1fr); gap: 18px; }
    .juz-grid { grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); }
    .quick-icons-grid { max-width: 720px; margin: 24px auto; }
    .desktop-sidebar .sidebar-logo { display: flex; align-items: center; gap: 12px; color: var(--gold); font-weight: 900; font-size: 20px; padding: 8px 12px 20px; border-bottom: 1px solid rgba(201,169,89,0.15); margin-bottom: 16px; }
    .desktop-sidebar .sidebar-logo i { font-size: 28px; }
    .desktop-sidebar .sidebar-nav-item { display: flex; align-items: center; gap: 14px; padding: 14px 16px; border-radius: 14px; color: rgba(255,255,255,0.7); cursor: pointer; transition: all 0.2s; font-weight: 600; font-size: 15px; margin-bottom: 4px; }
    .desktop-sidebar .sidebar-nav-item:hover { background: rgba(201,169,89,0.1); color: var(--gold); }
    .desktop-sidebar .sidebar-nav-item.active { background: linear-gradient(90deg, rgba(201,169,89,0.2), transparent); color: var(--gold); }
    .desktop-sidebar .sidebar-nav-item i { font-size: 20px; width: 26px; text-align: center; }
    .spotify-player { background: linear-gradient(180deg, #0d2b35 0%, #07131c 100%); }
}

@media (min-width: 768px) and (max-width: 1023px) {
    :root { --content-padding: 24px; --carousel-size: 90px; }
    .app-wrapper { max-width: 900px; margin: 0 auto; }
    .books-grid { grid-template-columns: repeat(4, 1fr); }
    .reciters-grid { grid-template-columns: repeat(3, 1fr); }
    .recent-video-card { width: 150px; }
    .prayer-hero { height: 320px; }
    .prayer-countdown-hero { font-size: 48px; }
}

@media (max-width: 360px) {
    .books-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .reciters-grid { grid-template-columns: 1fr; gap: 10px; }
    .prayer-hero { height: 260px; }
    .prayer-countdown-hero { font-size: 34px; }
    .card { padding: 0 14px; height: 70px; flex: 0 0 70px; gap: 12px; }
    .num-badge { width: 46px; min-width: 46px; height: 46px; flex: 0 0 46px; font-size: 17px; }
    .surah-name { font-size: 15px; }
    .reel-action-circle { width: 38px; height: 38px; font-size: 15px; }
    .profile-avatar { width: 84px; height: 84px; }
    .recent-video-card { width: 120px; }
    .quick-icon-circle { width: 44px; height: 44px; font-size: 20px; }
    .quick-icon-label { font-size: 13px; }
    .tasbih-count-wrap { width: 220px; height: 220px; }
    .tasbih-count-number { font-size: 80px; }
    .calendar-day { font-size: 13px; padding: 10px 2px 12px; }
    .spotify-cover-wrap { width: 70vw; }
    .spotify-info-text .song-title { font-size: 18px; }
    .spotify-play-btn { width: 60px; height: 60px; font-size: 24px; }
    .city-modal-grid { grid-template-columns: 1fr; }
}

@media (max-height: 500px) and (orientation: landscape) {
    .prayer-hero { height: 240px; }
    .prayer-countdown-hero { font-size: 32px; }
}

::-webkit-scrollbar{width:8px;height:8px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--gold);border-radius:10px}
</style>
</head>
<body>
<?php if ($showIntro): ?>
<div class="intro-screen" id="introScreen">
    <div class="intro-content">
        <div class="intro-logo-wrap"><i class="fas fa-quran"></i></div>
        <div class="intro-title">قرآنك</div>
        <div class="intro-subtitle">رفيقك في رحلة الإيمان</div>
        <div class="intro-bismillah">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>
        <div class="intro-progress"><div class="intro-progress-bar"></div></div>
    </div>
</div>
<?php endif; ?>

<div class="app-wrapper" id="appWrapper" style="<?= $showIntro ? 'display:none' : '' ?>">

    <aside class="desktop-sidebar">
        <div class="sidebar-logo"><i class="fas fa-quran"></i><span><?= htmlspecialchars($siteTitle) ?></span></div>
        <div class="sidebar-nav-item active" data-tab="home" onclick="switchTab('home', this)"><i class="fas fa-home"></i><span><?= htmlspecialchars(cs('nav_home_label', 'الرئيسية')) ?></span></div>
        <?php if ($showSurahs): ?>
        <div class="sidebar-nav-item" data-tab="surahs" onclick="switchTab('surahs', this)"><i class="fas fa-book-open"></i><span><?= htmlspecialchars(cs('nav_quran_label', 'القرآن')) ?></span></div>
        <div class="sidebar-nav-item" data-tab="juz" onclick="switchTab('juz', this)"><i class="fas fa-th"></i><span><?= htmlspecialchars(cs('nav_juz_label', 'أجزاء')) ?></span></div>
        <?php endif; ?>
        <?php if ($showAudio): ?>
        <div class="sidebar-nav-item" data-tab="audios" onclick="switchTab('audios', this)"><i class="fas fa-headphones"></i><span><?= htmlspecialchars(cs('nav_audio_label', 'صوتيات')) ?></span></div>
        <?php endif; ?>
        <?php if ($showVideos): ?>
        <div class="sidebar-nav-item" data-tab="videos" onclick="switchTab('videos', this)"><i class="fas fa-film"></i><span><?= htmlspecialchars(cs('nav_videos_label', 'ريلز')) ?></span></div>
        <?php endif; ?>
        <?php if ($showBooks): ?>
        <div class="sidebar-nav-item" data-tab="books" onclick="switchTab('books', this)"><i class="fas fa-book"></i><span><?= htmlspecialchars(cs('nav_books_label', 'كتب')) ?></span></div>
        <?php endif; ?>
    </aside>

    <div class="app-content" id="appContent">

        <!-- HOME -->
        <div id="homeTab" class="tab-pane active">
            <?php if ($showPrayer): ?>
            <div class="prayer-hero" id="prayerHero">
                <div class="prayer-hero-bg" id="prayerHeroBg"></div>
                <div class="prayer-hero-gradient"></div>
                <div class="prayer-hero-inner">
                    <div class="prayer-hero-top">
                        <div class="prayer-location-btn" onclick="toggleCitySelector()"><i class="fas fa-map-marker-alt"></i><span id="heroCityName">القاهرة</span><i class="fas fa-chevron-down"></i></div>
                        <div class="prayer-hijri" id="heroHijriDate">جاري...</div>
                    </div>
                    <div class="prayer-hero-center">
                        <div class="prayer-next-label">المتبقي على صلاة <span id="heroNextName">—</span></div>
                        <div class="prayer-countdown-hero" id="heroCountdown">--:--:--</div>
                    </div>
                    <div class="prayer-hero-times">
                        <div class="prayer-time-col" id="col-Fajr"><div class="prayer-time-name">الفجر</div><div class="prayer-time-value" id="time-Fajr">--:--</div></div>
                        <div class="prayer-time-col" id="col-Sunrise"><div class="prayer-time-name">الشروق</div><div class="prayer-time-value" id="time-Sunrise">--:--</div></div>
                        <div class="prayer-time-col" id="col-Dhuhr"><div class="prayer-time-name">الظهر</div><div class="prayer-time-value" id="time-Dhuhr">--:--</div></div>
                        <div class="prayer-time-col" id="col-Asr"><div class="prayer-time-name">العصر</div><div class="prayer-time-value" id="time-Asr">--:--</div></div>
                        <div class="prayer-time-col" id="col-Maghrib"><div class="prayer-time-name">المغرب</div><div class="prayer-time-value" id="time-Maghrib">--:--</div></div>
                        <div class="prayer-time-col" id="col-Isha"><div class="prayer-time-name">العشاء</div><div class="prayer-time-value" id="time-Isha">--:--</div></div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($showReciters): ?>
            <div class="section-header">
                <h2><i class="fas fa-microphone"></i> <?= htmlspecialchars(cs('section_reciters_title', 'القراء')) ?></h2>
                <span class="section-more" onclick="switchTab('audios')">عرض الكل <i class="fas fa-chevron-left"></i></span>
            </div>
            <div class="reciters-scroll" id="recitersCarousel">
                <div class="loader" style="padding:20px;"><i class="fas fa-spinner fa-spin"></i></div>
            </div>
            <?php endif; ?>

            <?php if ($showVideos && !empty($recentVideos)): ?>
            <div class="section-header">
                <h2><i class="fas fa-clock"></i> <?= htmlspecialchars(cs('section_recent_title', 'أضيف حديثاً')) ?></h2>
                <span class="section-more" onclick="switchTab('videos')">عرض الكل <i class="fas fa-chevron-left"></i></span>
            </div>
            <div class="recent-videos-scroll" id="recentVideosScroll">
                <?php foreach ($recentVideos as $v): ?>
                <div class="recent-video-card" onclick="openVideoPlayerById(<?= $v['id'] ?>)">
                    <img src="<?= $v['thumbnail_path'] ? 'uploads/thumbnails/' . sanitize($v['thumbnail_path']) : 'https://via.placeholder.com/200x350/0d2b35/c9a959?text=فيديو' ?>" alt="" loading="lazy" draggable="false">
                    <div class="recent-video-play"><i class="fas fa-play"></i></div>
                    <div class="recent-video-duration"><?= sanitize($v['video_duration'] ?? '00:00') ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($appIcons)): ?>
            <div class="quick-icons-grid" id="quickIconsGrid">
                <?php foreach ($appIcons as $ic):
                    $sectionMap = ['azkar' => $showAzkar, 'tasbih' => $showTasbih, 'hadith' => $showHadith, 'calendar' => $showCalendar];
                    if (isset($sectionMap[$ic['action_type']]) && !$sectionMap[$ic['action_type']]) continue;
                ?>
                <div class="quick-icon-card" style="--icon-color: <?= sanitize($ic['color']) ?>" onclick="handleQuickIcon('<?= sanitize($ic['action_type']) ?>', '<?= sanitize($ic['link'] ?? '') ?>')">
                    <div class="quick-icon-circle"><i class="fas <?= sanitize($ic['icon']) ?>"></i></div>
                    <div class="quick-icon-label"><?= sanitize($ic['name']) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- SURAHS -->
        <?php if ($showSurahs): ?>
        <div id="surahsTab" class="tab-pane">
            <div class="search-wrapper"><input type="text" class="search-box" id="surahSearch" placeholder="🔍 ابحث عن سورة..." oninput="filterSurahs(this.value)"></div>
            <div id="surahList" class="surah-list loader"><i class="fas fa-spinner fa-spin"></i> جاري تحميل السور...</div>
        </div>
        <div id="juzTab" class="tab-pane">
            <div id="juzContainer"><div class="juz-grid" id="juzGrid"></div></div>
        </div>
        <?php endif; ?>

        <!-- AUDIO -->
        <?php if ($showAudio): ?>
        <div id="audiosTab" class="tab-pane">
            <div class="search-wrapper"><input type="text" class="search-box" id="recitersSearch" placeholder="🔍 ابحث عن قارئ..." oninput="filterReciters(this.value)"></div>
            <div class="reciters-grid" id="recitersGrid"></div>
        </div>
        <?php endif; ?>

        <!-- VIDEOS -->
        <?php if ($showVideos): ?>
        <div id="videosTab" class="tab-pane" style="position:relative;background:#000;">
            <div class="reels-tab-container" id="reelsTabContainer">
                <div class="loader" style="padding-top:150px;color:#fff;"><i class="fas fa-spinner fa-spin" style="font-size:40px;"></i><p>جاري تحميل الريلزات...</p></div>
            </div>
        </div>
        <?php endif; ?>

        <!-- BOOKS -->
        <?php if ($showBooks): ?>
        <div id="booksTab" class="tab-pane">
            <div class="search-wrapper"><input type="text" class="search-box" id="booksSearchInput" placeholder="🔍 ابحث عن كتاب..." oninput="filterBooks(this.value)"></div>
            <div id="booksList" class="books-grid"><div class="skeleton" style="height:200px"></div><div class="skeleton" style="height:200px"></div><div class="skeleton" style="height:200px"></div></div>
        </div>
        <?php endif; ?>
    </div>

    <nav class="nav-bar" id="navBar">
        <div class="nav-item active" data-tab="home" onclick="switchTab('home', this)"><i class="fas fa-home"></i><div><?= htmlspecialchars(cs('nav_home_label', 'الرئيسية')) ?></div></div>
        <?php if ($showSurahs): ?>
        <div class="nav-item" data-tab="surahs" onclick="switchTab('surahs', this)"><i class="fas fa-book-open"></i><div><?= htmlspecialchars(cs('nav_quran_label', 'القرآن')) ?></div></div>
        <div class="nav-item" data-tab="juz" onclick="switchTab('juz', this)"><i class="fas fa-th"></i><div><?= htmlspecialchars(cs('nav_juz_label', 'أجزاء')) ?></div></div>
        <?php endif; ?>
        <?php if ($showAudio): ?>
        <div class="nav-item" data-tab="audios" onclick="switchTab('audios', this)"><i class="fas fa-headphones"></i><div><?= htmlspecialchars(cs('nav_audio_label', 'صوتيات')) ?></div></div>
        <?php endif; ?>
        <?php if ($showVideos): ?>
        <div class="nav-item" data-tab="videos" onclick="switchTab('videos', this)"><i class="fas fa-film"></i><div><?= htmlspecialchars(cs('nav_videos_label', 'ريلز')) ?></div></div>
        <?php endif; ?>
        <?php if ($showBooks): ?>
        <div class="nav-item" data-tab="books" onclick="switchTab('books', this)"><i class="fas fa-book"></i><div><?= htmlspecialchars(cs('nav_books_label', 'كتب')) ?></div></div>
        <?php endif; ?>
    </nav>
</div>

<!-- CITY MODAL -->
<div class="city-modal" id="cityModal" onclick="if(event.target===this) toggleCitySelector()">
    <div class="city-modal-content">
        <div class="city-modal-header"><h3><i class="fas fa-map-marker-alt"></i> اختر المدينة</h3><i class="fas fa-times" onclick="toggleCitySelector()"></i></div>
        <div class="city-modal-grid" id="cityModalGrid"></div>
    </div>
</div>

<!-- VIDEO PLAYER -->
<div id="videoPlayerModal" class="video-player-modal">
    <div class="video-player-header">
        <i class="fas fa-times" onclick="closeVideoPlayer()"></i>
        <div class="video-title" id="videoPlayerTitle"></div>
        <div></div>
    </div>
    <div class="video-player-container" id="videoPlayerContainer"></div>
</div>

<!-- QURAN READER -->
<div id="readerScreen" class="reader-screen">
    <div class="reader-header">
        <i class="fas fa-times" onclick="closeReader()"></i>
        <span class="reader-title" id="readerTitle">المصحف</span>
        <span style="font-size:13px;color:#e2c78a;" id="pageNumberDisplay">صفحة 1</span>
        <div class="reader-header-actions">
            <button onclick="toggleQuranNightMode()"><i class="fas fa-moon"></i></button>
            <button onclick="changeQuranFontSize(-1)"><i class="fas fa-minus"></i></button>
            <span style="font-size:11px;color:#a0b9c4;min-width:30px;" id="quranFontSizeLabel">100%</span>
            <button onclick="changeQuranFontSize(1)"><i class="fas fa-plus"></i></button>
        </div>
    </div>
    <div class="quran-container" id="quranContainer">
        <div class="quran-page-wrapper">
            <img id="quranPageImg" class="quran-page-img" src="" alt="صفحة" loading="lazy">
            <div class="page-nav-overlay">
                <button class="nav-btn" id="prevPageBtn" onclick="changePage(-1)"><i class="fas fa-chevron-right"></i></button>
                <button class="nav-btn" id="nextPageBtn" onclick="changePage(1)"><i class="fas fa-chevron-left"></i></button>
            </div>
            <div class="page-number-badge" id="pageNumberText">1 / 604</div>
        </div>
    </div>
</div>

<!-- RECITER PAGE -->
<div id="reciterPage" class="reciter-page">
    <div class="reciter-page-header">
        <i class="fas fa-arrow-right" onclick="closeReciterPage()"></i>
        <img id="reciterPageImg" src="" loading="lazy">
        <div class="reciter-info"><h3 id="reciterPageName"></h3><small id="reciterPageCount"></small></div>
    </div>
    <div class="search-wrapper" style="padding:0 15px;margin-top:10px;"><input type="text" class="search-box" id="surahSearchInput" placeholder="🔍 ابحث عن سورة..." oninput="filterSurahsInReciter(this.value)"></div>
    <div id="reciterSurahsList" style="flex:1;overflow-y:auto;padding:12px 15px 90px;"></div>
</div>

<!-- PROFILE -->
<div id="profileOverlay" class="profile-overlay">
    <div class="profile-header">
        <button class="profile-header-btn" onclick="closeProfileOverlay()"><i class="fas fa-arrow-right"></i></button>
        <div class="profile-header-right">
            <button class="profile-header-btn" onclick="shareCurrentProfile()"><i class="fas fa-share-alt"></i></button>
        </div>
    </div>
    <div id="profileBody"></div>
</div>

<!-- RECITER REELS -->
<div id="reciterReelsContainer" class="reels-tab-container" style="display:none;z-index:9999;position:fixed;top:0;left:0;"></div>
<div id="reciterReelsBackBtn" style="position:fixed;top:calc(16px + var(--safe-top));right:16px;z-index:10000;width:44px;height:44px;background:rgba(0,0,0,0.7);backdrop-filter:blur(8px);border:2px solid var(--gold);border-radius:50%;display:none;align-items:center;justify-content:center;color:var(--gold);font-size:18px;cursor:pointer;" onclick="closeReciterReels()">
    <i class="fas fa-arrow-right"></i>
</div>

<!-- SHARE POPUP -->
<div class="share-popup-overlay" id="sharePopup" onclick="if(event.target===this) closeSharePopup()">
    <div class="share-popup-content">
        <div class="share-popup-title"><i class="fas fa-share-alt"></i> مشاركة</div>
        <div class="share-popup-grid">
            <div class="share-popup-item" onclick="shareToWhatsApp()"><div class="share-icon whatsapp"><i class="fab fa-whatsapp"></i></div><span>واتساب</span></div>
            <div class="share-popup-item" onclick="shareToFacebook()"><div class="share-icon facebook"><i class="fab fa-facebook-f"></i></div><span>فيسبوك</span></div>
            <div class="share-popup-item" onclick="copyShareLink()"><div class="share-icon copy"><i class="fas fa-link"></i></div><span>نسخ الرابط</span></div>
            <div class="share-popup-item" onclick="shareToSystem()"><div class="share-icon system"><i class="fas fa-ellipsis-h"></i></div><span>مشاركة</span></div>
        </div>
        <div class="share-popup-close" onclick="closeSharePopup()">إغلاق</div>
    </div>
</div>

<!-- PDF READER -->
<div class="pdf-reader-modal" id="pdfReaderModal">
    <div class="pdf-reader-header">
        <span class="pdf-title" id="pdfReaderTitle">قراءة الكتاب</span>
        <div class="pdf-tools">
            <input type="number" id="pdfPageInput" min="1" value="1" onchange="pdfGoToPage(this.value)">
            <span class="pdf-page-indicator" id="pdfPageIndicator">صفحة 1 / 1</span>
            <div class="pdf-close" onclick="closePdfReader()"><i class="fas fa-times"></i></div>
        </div>
    </div>
    <div class="pdf-reader-body" id="pdfReaderBody"></div>
    <div class="pdf-reader-controls">
        <button onclick="pdfPrevPage()"><i class="fas fa-chevron-right"></i> السابق</button>
        <span class="page-num" id="pdfPageNum">صفحة 1</span>
        <button onclick="pdfNextPage()">التالي <i class="fas fa-chevron-left"></i></button>
    </div>
</div>

<!-- AZKAR -->
<div id="azkarPage" class="azkar-page">
    <div class="azkar-header">
        <i class="fas fa-arrow-right" onclick="closeAzkarPage()"></i>
        <h2>الأذكار</h2>
    </div>
    <div class="azkar-cats-bar" id="azkarCatsBar"></div>
    <div class="azkar-list-body" id="azkarListBody"><div class="loader"><i class="fas fa-spinner fa-spin"></i></div></div>
    <div class="azkar-content-view" id="azkarContentView"></div>
</div>

<!-- HADITH -->
<div id="hadithPage" class="hadith-page">
    <div class="hadith-header">
        <i class="fas fa-arrow-right" onclick="closeHadithPage()"></i>
        <h2>الأحاديث النبوية</h2>
    </div>
    <div class="hadith-list-body" id="hadithListBody"><div class="loader"><i class="fas fa-spinner fa-spin"></i></div></div>
    <div class="hadith-content-view" id="hadithContentView"></div>
</div>

<!-- TASBIH -->
<div id="tasbihPage" class="tasbih-page">
    <div class="tasbih-header">
        <i class="fas fa-arrow-right" onclick="closeTasbihPage()"></i>
        <h2>المسبحة الإلكترونية</h2>
    </div>
    <div class="tasbih-body">
        <div class="tasbih-count-wrap">
            <div class="tasbih-ring"></div>
            <div class="tasbih-ring-inner"></div>
            <div class="tasbih-count-number" id="tasbihCount">0</div>
        </div>
        <button class="tasbih-tap-btn" onclick="incrementTasbih()">اضغط</button>
        <div class="tasbih-actions-row">
            <button class="tasbih-action-btn" onclick="openResetModal()"><i class="fas fa-redo"></i> إعادة تعيين</button>
            <button class="tasbih-action-btn" onclick="openTargetModal()"><i class="fas fa-bullseye"></i> تحديد الهدف</button>
        </div>
    </div>
</div>

<div class="tasbih-modal" id="tasbihTargetModal" onclick="if(event.target===this) closeTargetModal()">
    <div class="tasbih-modal-content">
        <h3><i class="fas fa-bullseye"></i> اختر الهدف</h3>
        <div class="tasbih-target-options">
            <button class="tasbih-target-opt" onclick="setTarget(33)">33</button>
            <button class="tasbih-target-opt" onclick="setTarget(66)">66</button>
            <button class="tasbih-target-opt" onclick="setTarget(100)">100</button>
            <button class="tasbih-target-opt" onclick="setTarget(1000)">1000</button>
        </div>
        <div class="tasbih-modal-actions"><button class="tasbih-modal-cancel" onclick="closeTargetModal()">إلغاء</button></div>
    </div>
</div>

<div class="tasbih-modal" id="tasbihResetModal" onclick="if(event.target===this) closeResetModal()">
    <div class="tasbih-modal-content">
        <h3><i class="fas fa-redo"></i> إعادة تعيين</h3>
        <p style="text-align:center;color:#a0b9c4;font-size:14px;margin-bottom:18px;">هل أنت متأكد من إعادة تعيين العداد؟</p>
        <div class="tasbih-modal-actions">
            <button class="tasbih-modal-cancel" onclick="closeResetModal()">إلغاء</button>
            <button class="tasbih-modal-confirm" onclick="confirmReset()">تأكيد</button>
        </div>
    </div>
</div>

<!-- CALENDAR -->
<div id="calendarPage" class="calendar-page">
    <div class="calendar-header">
        <i class="fas fa-arrow-right" onclick="closeCalendarPage()"></i>
        <h2>التقويم</h2>
    </div>
    <div class="calendar-body">
        <div class="calendar-today" id="calendarToday"></div>
        <div class="calendar-nav">
            <button onclick="changeMonth(-1)"><i class="fas fa-chevron-right"></i></button>
            <div class="month-title" id="calendarMonthTitle"></div>
            <button onclick="changeMonth(1)"><i class="fas fa-chevron-left"></i></button>
        </div>
        <div class="calendar-grid" id="calendarGrid"></div>
        <div class="calendar-day-detail" id="calendarDayDetail"></div>
        <div class="calendar-prayer-times" id="calendarPrayerTimes"></div>
    </div>
</div>

<!-- SPOTIFY PLAYER -->
<div id="spotifyPlayer" class="spotify-player">
    <div class="spotify-player-header">
        <button class="spotify-player-header-btn" onclick="closeSpotifyPlayer()"><i class="fas fa-chevron-down"></i></button>
        <div class="spotify-player-header-center">
            <div class="small-title">يتم التشغيل من</div>
            <div class="playing-from" id="playingFromName">صوتيات</div>
        </div>
        <button class="spotify-player-header-btn" onclick="openSharePopup(state.currentTrackTitle, 0)"><i class="fas fa-share-alt"></i></button>
    </div>
    <div class="spotify-player-body">
        <div class="spotify-cover-wrap" id="spotifyCoverWrap">
            <img id="spotifyCoverImg" src="https://via.placeholder.com/320" alt="">
        </div>
        <div class="spotify-info-row">
            <div class="spotify-info-text">
                <div class="song-title" id="spotifyTitle">اسم السورة</div>
                <div class="song-artist" id="spotifyArtist">اسم القارئ</div>
            </div>
            <div class="spotify-info-actions">
                <button id="spotifyAddBtn" onclick="toggleAddToPlaylist()"><i class="fas fa-plus-circle"></i></button>
                <button id="spotifyLikeBtn" onclick="toggleAudioLike()"><i class="fas fa-heart"></i></button>
            </div>
        </div>
        <div class="spotify-progress-wrap">
            <div class="spotify-progress-bar" id="spotifyProgressBar">
                <div class="spotify-progress-fill" id="spotifyProgressFill"></div>
                <input type="range" id="spotifyProgressInput" min="0" max="100" value="0" step="0.1">
            </div>
            <div class="spotify-progress-times">
                <span id="spotifyCurrentTime">00:00</span>
                <span id="spotifyDurationTime">00:00</span>
            </div>
        </div>
        <div class="spotify-controls">
            <button class="spotify-ctrl-btn" id="spotifyShuffleBtn" onclick="toggleShuffle()"><i class="fas fa-random"></i></button>
            <button class="spotify-ctrl-btn" onclick="playPrevTrack()"><i class="fas fa-step-backward"></i></button>
            <button class="spotify-play-btn" id="spotifyPlayBtn" onclick="toggleAudioPlay()"><i class="fas fa-play"></i></button>
            <button class="spotify-ctrl-btn" onclick="playNextTrack()"><i class="fas fa-step-forward"></i></button>
            <button class="spotify-ctrl-btn" id="spotifyRepeatBtn" onclick="toggleRepeat()"><i class="fas fa-redo"></i></button>
        </div>
    </div>
    <div class="spotify-bottom-actions">
        <button onclick="toggleAudioLike()"><i class="fas fa-heart" id="spotifyBottomLike"></i><span>إعجاب</span></button>
        <button onclick="downloadCurrentAudio()"><i class="fas fa-download"></i><span>تحميل</span></button>
        <button onclick="openSharePopup(state.currentTrackTitle, 0)"><i class="fas fa-share-alt"></i><span>مشاركة</span></button>
    </div>
</div>

<!-- MINI PLAYER -->
<div class="mini-player" id="miniPlayer" onclick="openSpotifyPlayer()">
    <img src="https://via.placeholder.com/45" id="miniPlayerImg" class="mini-player-cover" alt="">
    <div class="mini-player-info">
        <div class="mini-player-title" id="miniPlayerTitle">اسم السورة</div>
        <div class="mini-player-sub" id="miniPlayerSub">اسم الشيخ</div>
    </div>
    <div class="mini-player-controls" onclick="event.stopPropagation()">
        <button onclick="playPrevTrack()"><i class="fas fa-step-backward"></i></button>
        <button class="play-btn" id="miniPlayerPlayBtn" onclick="toggleAudioPlay()"><i class="fas fa-play"></i></button>
        <button onclick="playNextTrack()"><i class="fas fa-step-forward"></i></button>
        <button onclick="closeMiniPlayer()"><i class="fas fa-times"></i></button>
    </div>
    <div class="mini-player-progress"><div class="mini-player-progress-fill" id="miniPlayerProgressFill"></div></div>
</div>

<button class="scroll-top-btn" id="scrollTopBtn" onclick="window.scrollTo({top:0,behavior:'smooth'})"><i class="fas fa-chevron-up"></i></button>
<div id="customToast" class="custom-toast"></div>

<script>
window.QURAN_DATA = {
    baseUrl: '<?= BASE_URL ?>',
    showIntro: <?= $showIntro ? 'true' : 'false' ?>,
    surahStartPages: <?= json_encode($surahStartPages) ?>,
    surahNames: <?= json_encode($surahNames, JSON_UNESCAPED_UNICODE) ?>,
    carouselItemSize: <?= $carouselItemSize ?>,
    sections: {
        books: <?= $showBooks ? 'true' : 'false' ?>,
        videos: <?= $showVideos ? 'true' : 'false' ?>,
        audio: <?= $showAudio ? 'true' : 'false' ?>,
        reciters: <?= $showReciters ? 'true' : 'false' ?>,
        prayer: <?= $showPrayer ? 'true' : 'false' ?>,
        surahs: <?= $showSurahs ? 'true' : 'false' ?>,
        azkar: <?= $showAzkar ? 'true' : 'false' ?>,
        tasbih: <?= $showTasbih ? 'true' : 'false' ?>,
        hadith: <?= $showHadith ? 'true' : 'false' ?>,
        calendar: <?= $showCalendar ? 'true' : 'false' ?>
    },
    prayerBackgrounds: {
        dawn: '<?= htmlspecialchars($bgFajr) ?>',
        sunrise: '<?= htmlspecialchars($bgSunrise) ?>',
        day: '<?= htmlspecialchars($bgDhuhr) ?>',
        asr: '<?= htmlspecialchars($bgAsr) ?>',
        sunset: '<?= htmlspecialchars($bgMaghrib) ?>',
        night: '<?= htmlspecialchars($bgIsha) ?>',
        default: '<?= htmlspecialchars($bgDefault) ?>'
    },
    texts: {
        emptyReciters: '<?= htmlspecialchars(cs('empty_reciters_msg', 'لا يوجد قراء'), ENT_QUOTES) ?>',
        emptyBooks: '<?= htmlspecialchars(cs('empty_books_msg', 'لا توجد كتب'), ENT_QUOTES) ?>',
        emptyVideos: '<?= htmlspecialchars(cs('empty_videos_msg', 'لا توجد فيديوهات'), ENT_QUOTES) ?>',
        btnLike: '<?= htmlspecialchars(cs('btn_like', 'أعجبني'), ENT_QUOTES) ?>',
        btnShare: '<?= htmlspecialchars(cs('btn_share', 'مشاركة'), ENT_QUOTES) ?>',
        btnDownload: '<?= htmlspecialchars(cs('btn_download', 'تحميل'), ENT_QUOTES) ?>'
    }
};
</script>
<script>
(function () {
'use strict';

const DATA = window.QURAN_DATA || {};
const API_BASE = 'index.php?action=';
const QURAN_PAGES_API = 'https://quran.yousefheiba.com/api/quran-pages/';
const TOTAL_PAGES = 604;
const ALQURAN_API = 'https://api.alquran.cloud/v1';
const surahStartPages = DATA.surahStartPages || {};
const surahNames = DATA.surahNames || {};

const state = {
    currentPage: 1,
    quranNightMode: localStorage.getItem('quranNightMode') === 'true',
    quranFontSize: parseInt(localStorage.getItem('quranFontSize') || '100'),
    activeVideo: null,
    reelsObserver: null,
    reciterReelsObserver: null,
    currentAudioPlaylist: [],
    currentAudioTrackIndex: -1,
    currentTrackTitle: '',
    currentTrackUrl: '',
    currentReciterVideos: [],
    currentReciterReelIndex: 0,
    selectedProvince: localStorage.getItem('selectedCity') || 'القاهرة',
    allBooks: [],
    heroCountdownInterval: null,
    prayerTimings: null,
    shareVideoId: null,
    shareVideoTitle: '',
    pdfDoc: null, pdfPageNum: 1, pdfTotalPages: 0, pdfScale: 1.5,
    allSurahs: [],
    allReciters: [],
    tasbihCount: parseInt(localStorage.getItem('tasbih_count') || '0'),
    calendarDate: new Date(),
    calendarSelectedDate: null,
    currentProfileId: null,
    currentProfileName: '',
    currentProfileImage: '',
    currentProfileVideos: [],
    currentProfileLikedVideos: [],
    azkarCategories: [],
    shuffleMode: false,
    repeatMode: false,
    prayerRequestId: 0
};

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

function showToast(msg) {
    const t = $('#customToast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(t._to); t._to = setTimeout(() => t.classList.remove('show'), 2800);
}
window.showToast = showToast;

function formatTime(secs) {
    if (!isFinite(secs) || isNaN(secs)) return '00:00';
    const m = String(Math.floor(secs / 60)).padStart(2, '0');
    const s = String(Math.floor(secs % 60)).padStart(2, '0');
    return `${m}:${s}`;
}
function escapeHtml(str) { const d = document.createElement('div'); d.textContent = str || ''; return d.innerHTML; }
function trackAction(type, itemType, itemId) { try { fetch(`${API_BASE}track&type=${type}&item_type=${itemType}&item_id=${encodeURIComponent(itemId)}`, { keepalive: true }).catch(() => {}); } catch (e) {} }
function removeArabicDiacritics(str) { return String(str).replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '').replace(/[إأآا]/g, 'ا').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ة/g, 'ه'); }

/* ============================================================
   PRAYER TIMES — إصلاح كامل
   ============================================================ */
const egyptianCities = [
    { ar:'القاهرة', en:'Cairo' }, { ar:'الإسكندرية', en:'Alexandria' }, { ar:'الجيزة', en:'Giza' },
    { ar:'القليوبية', en:'Qalyubia' }, { ar:'بورسعيد', en:'Port Said' }, { ar:'السويس', en:'Suez' },
    { ar:'الأقصر', en:'Luxor' }, { ar:'أسوان', en:'Aswan' }, { ar:'الغربية', en:'Gharbia' },
    { ar:'الدقهلية', en:'Dakahlia' }, { ar:'الشرقية', en:'Sharqia' }, { ar:'الإسماعيلية', en:'Ismailia' },
    { ar:'كفر الشيخ', en:'Kafr El Sheikh' }, { ar:'أسيوط', en:'Asyut' }, { ar:'بني سويف', en:'Beni Suef' },
    { ar:'الفيوم', en:'Faiyum' }, { ar:'دمياط', en:'Damietta' }, { ar:'البحيرة', en:'Beheira' },
    { ar:'المنيا', en:'Minya' }, { ar:'قنا', en:'Qena' }, { ar:'سوهاج', en:'Sohag' },
    { ar:'البحر الأحمر', en:'Red Sea' }, { ar:'مطروح', en:'Matrouh' }, { ar:'المنوفية', en:'Monufia' },
    { ar:'شمال سيناء', en:'North Sinai' }, { ar:'جنوب سيناء', en:'South Sinai' }, { ar:'الوادي الجديد', en:'New Valley' }
];

const PRAYER_CACHE_KEY = 'prayer_cache_v11';
function getCachedPrayer(city) {
    try {
        const raw = localStorage.getItem(PRAYER_CACHE_KEY);
        if (!raw) return null;
        const data = JSON.parse(raw);
        if (data.city !== city) return null;
        // cache valid for 6 hours
        if (Date.now() - data.ts > 6 * 3600 * 1000) return null;
        return data.payload;
    } catch (e) { return null; }
}
function setCachedPrayer(city, payload) {
    try {
        localStorage.setItem(PRAYER_CACHE_KEY, JSON.stringify({ city, payload, ts: Date.now() }));
    } catch (e) {}
}

function getTimeOfDay(key) {
    const m = { Fajr:'dawn', Sunrise:'sunrise', Dhuhr:'day', Asr:'asr', Maghrib:'sunset', Isha:'night' };
    return m[key] || 'default';
}

/* إصلاح: حساب العد التنازلي بشكل صحيح */
function getNextPrayer(timings) {
    if (!timings) return null;
    const names = ['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'];
    const now = new Date();
    const nowSec = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();

    // بني مصفوفة من {key, timeSec}
    const list = [];
    for (const n of names) {
        if (!timings[n]) continue;
        const [h, m] = String(timings[n]).split(':').map(Number);
        if (isNaN(h) || isNaN(m)) continue;
        list.push({ key: n, sec: h * 3600 + m * 60 });
    }
    if (!list.length) return null;

    let next = null;
    // ابحث عن أول صلاة وقتها بعد الآن (اليوم)
    for (const p of list) {
        if (p.sec > nowSec) { next = p; break; }
    }
    // لو مفيش، يبقى فجر بكرة
    let isTomorrow = false;
    if (!next) { next = list[0]; isTomorrow = true; }

    let diff = next.sec - nowSec;
    if (isTomorrow) diff += 86400;
    if (diff < 0) diff = 0;

    const h = Math.floor(diff / 3600);
    const m = Math.floor((diff % 3600) / 60);
    const s = diff % 60;
    const namesMap = { Fajr:'الفجر', Sunrise:'الشروق', Dhuhr:'الظهر', Asr:'العصر', Maghrib:'المغرب', Isha:'العشاء' };

    return {
        name: namesMap[next.key],
        time: timings[next.key],
        key: next.key,
        countdown: `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`
    };
}

function convertTo12Hour(t) {
    if (!t) return '';
    let [h, m] = String(t).split(':').map(Number);
    if (isNaN(h) || isNaN(m)) return '';
    const ampm = h >= 12 ? 'م' : 'ص';
    h = h % 12 || 12;
    return `${h}:${String(m).padStart(2, '0')} ${ampm}`;
}

/* إصلاح race condition + cache + fallback */
async function loadHomePrayerTimes() {
    if (!DATA.sections.prayer) return;
    const cityName = state.selectedProvince || 'القاهرة';
    const cityData = egyptianCities.find(c => c.ar === cityName);
    const cityEn = cityData ? cityData.en : 'Cairo';

    const reqId = ++state.prayerRequestId;

    // 1. اعرض من الكاش فورًا لو موجود
    const cached = getCachedPrayer(cityName);
    if (cached) {
        state.prayerTimings = cached.timings;
        renderHomePrayerTimes(cached, cityName, true);
    }

    try {
        const res = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(cityEn)}&country=Egypt&method=5`);
        if (!res.ok) throw new Error('fail');
        const data = await res.json();
        if (reqId !== state.prayerRequestId) return; // تم تغيير المدينة أثناء الطلب
        if (!data || !data.data || !data.data.timings) throw new Error('invalid');
        const payload = { timings: data.data.timings, date: data.data.date };
        state.prayerTimings = payload.timings;
        setCachedPrayer(cityName, payload);
        renderHomePrayerTimes(payload, cityName, false);
    } catch (e) {
        if (reqId !== state.prayerRequestId) return;
        if (!cached) {
            // fallback واضح مع توضيح أنه بيانات تقريبية
            const hijriEl = $('#heroHijriDate');
            if (hijriEl) hijriEl.textContent = 'تعذر التحميل';
            showToast('⚠️ تعذر جلب مواقيت الصلاة، تحقق من الإنترنت');
        }
    }
}

function renderHomePrayerTimes(data, cityName, fromCache) {
    const timings = data.timings;
    const prayers = ['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'];
    const next = getNextPrayer(timings);
    const cityEl = $('#heroCityName'); if (cityEl) cityEl.textContent = cityName;
    const hijriEl = $('#heroHijriDate');
    if (hijriEl && data.date && data.date.hijri) {
        const h = data.date.hijri;
        hijriEl.textContent = `${h.day} ${h.month.ar} ${h.year} هـ`;
    }
    const nextNameEl = $('#heroNextName'); if (nextNameEl && next) nextNameEl.textContent = next.name;
    const bgEl = $('#prayerHeroBg');
    if (bgEl) {
        const timeOfDay = getTimeOfDay(next ? next.key : 'Dhuhr');
        const bgUrl = DATA.prayerBackgrounds[timeOfDay] || DATA.prayerBackgrounds.default;
        if (bgUrl) {
            const img = new Image();
            img.onload = () => { bgEl.style.backgroundImage = `url('${bgUrl}')`; bgEl.classList.add('loaded'); };
            img.src = bgUrl;
        }
    }
    prayers.forEach(p => {
        const el = document.getElementById('time-' + p);
        if (el) el.textContent = convertTo12Hour(timings[p]);
    });
    $$('.prayer-time-col').forEach(c => c.classList.remove('active'));
    if (next) {
        const col = document.getElementById('col-' + next.key);
        if (col) col.classList.add('active');
    }
    startHeroCountdown();
}

function startHeroCountdown() {
    if (state.heroCountdownInterval) clearInterval(state.heroCountdownInterval);
    const update = () => {
        if (!state.prayerTimings) return;
        const next = getNextPrayer(state.prayerTimings);
        const el = $('#heroCountdown');
        if (el && next) el.textContent = next.countdown;
    };
    update();
    state.heroCountdownInterval = setInterval(update, 1000);
}

window.toggleCitySelector = function () {
    const modal = $('#cityModal'); if (!modal) return;
    modal.classList.toggle('active');
    if (modal.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = '';
    }
    const grid = $('#cityModalGrid');
    if (grid && grid.children.length === 0) {
        grid.innerHTML = egyptianCities.map(c =>
            `<div class="city-modal-item ${c.ar === state.selectedProvince ? 'selected' : ''}" onclick="selectCity('${c.ar}')">${c.ar}</div>`
        ).join('');
    }
};
window.selectCity = function (name) {
    state.selectedProvince = name;
    localStorage.setItem('selectedCity', name);
    toggleCitySelector();
    loadHomePrayerTimes();
    showToast('✅ تم التغيير إلى ' + name);
};

/* ============================================================
   CAROUSEL RECITERS
   ============================================================ */
async function loadCarouselReciters() {
    if (!DATA.sections.reciters) return;
    const c = $('#recitersCarousel'); if (!c) return;
    try {
        const res = await fetch(`${API_BASE}get_reciters_carousel`);
        const reciters = await res.json();
        state.allReciters = reciters;
        if (!reciters.length) { c.innerHTML = '<div class="loader" style="width:100%;">لا يوجد قراء</div>'; return; }
        c.innerHTML = reciters.map(r => {
            const img = r.image ? 'uploads/' + r.image : 'https://via.placeholder.com/80/0d2b35/c9a959?text=🎤';
            return `<div class="carousel-reciter-item" onclick="openReciterFromCarousel(${r.id}, '${escapeHtml(r.name).replace(/'/g, "\\'")}', '${r.image || ''}')">
                <div class="carousel-avatar-wrapper"><img src="${img}" onerror="this.src='https://via.placeholder.com/80/0d2b35/c9a959?text=🎤'" loading="lazy" draggable="false"></div>
                <span class="carousel-reciter-name">${escapeHtml(r.name)}</span>
            </div>`;
        }).join('');
    } catch (e) { c.innerHTML = '<div class="loader" style="width:100%;">لا يوجد قراء</div>'; }
}

window.openReciterFromCarousel = function (id, name, img) {
    switchTab('audios');
    setTimeout(() => openReciterPage(id, name, img), 300);
};

function initDragScroll(el) {
    if (!el || el._dragInit) return;
    el._dragInit = true;
    let isDown = false, startX = 0, scrollLeft = 0;
    const onStart = (x) => { isDown = true; startX = x; scrollLeft = el.scrollLeft; };
    const onMove = (x) => { if (!isDown) return; const walk = x - startX; if (Math.abs(walk) > 3) el.classList.add('dragging'); el.scrollLeft = scrollLeft - walk; };
    const onEnd = () => { isDown = false; setTimeout(() => el.classList.remove('dragging'), 30); };
    el.addEventListener('mousedown', (e) => { e.preventDefault(); onStart(e.pageX); });
    el.addEventListener('mousemove', (e) => { if (isDown) onMove(e.pageX); });
    el.addEventListener('mouseleave', onEnd);
    el.addEventListener('mouseup', onEnd);
    el.addEventListener('touchstart', (e) => onStart(e.touches[0].pageX), { passive: true });
    el.addEventListener('touchmove', (e) => { if (!isDown) return; onMove(e.touches[0].pageX); }, { passive: true });
    el.addEventListener('touchend', onEnd, { passive: true });
    el.addEventListener('touchcancel', onEnd, { passive: true });
}

/* ============================================================
   TABS
   ============================================================ */
function switchTab(tab, el) {
    // لا تغلق النوافذ إلا إذا فعلاً تغيّر التبويب
    closeReader(); closeVideoPlayer(); closeProfileOverlay(); closeReciterReels();
    closeAzkarPage(); closeTasbihPage(); closeHadithPage(); closeCalendarPage();
    // لا نغلق reciterPage هنا — نتركها تُفتح من الكاروسيل
    const appContent = $('#appContent');
    if (tab === 'videos') {
        appContent.classList.add('videos-mode');
        setTimeout(initReelsEngine, 100);
    } else {
        appContent.classList.remove('videos-mode');
    }
    $$('.tab-pane').forEach(p => p.classList.remove('active'));
    const target = document.getElementById(tab + 'Tab');
    if (target) target.classList.add('active');
    $$('.nav-item, .sidebar-nav-item').forEach(n => { if (n.dataset.tab === tab) n.classList.add('active'); else n.classList.remove('active'); });
    if (el) el.classList.add('active');
    if (tab === 'surahs') loadSurahs();
    if (tab === 'juz') renderJuzGrid();
    if (tab === 'books') loadAllBooks();
    if (tab === 'audios') loadRecitersGrid();
    if (tab === 'videos') loadReels();
    sessionStorage.setItem('currentTab', tab);
    if (window.innerWidth < 1024) window.scrollTo({ top: 0, behavior: 'instant' });
}
window.switchTab = switchTab;

/* ============================================================
   QUICK ICONS — مع دعم internal link
   ============================================================ */
window.handleQuickIcon = function(type, link) {
    switch(type) {
        case 'azkar': if (!DATA.sections.azkar) { showToast('⚠️ الأذكار غير مفعلة'); return; } openAzkarPage(); break;
        case 'tasbih': if (!DATA.sections.tasbih) { showToast('⚠️ المسبحة غير مفعلة'); return; } openTasbihPage(); break;
        case 'hadith': if (!DATA.sections.hadith) { showToast('⚠️ الأحاديث غير مفعلة'); return; } openHadithPage(); break;
        case 'calendar': if (!DATA.sections.calendar) { showToast('⚠️ التقويم غير مفعل'); return; } openCalendarPage(); break;
        case 'link':
        case 'internal': if (link) window.open(link, '_blank'); break;
        default: showToast('قيد التطوير');
    }
};

/* ============================================================
   AZKAR
   ============================================================ */
window.openAzkarPage = async function() {
    $('#azkarPage').classList.add('active');
    document.body.style.overflow = 'hidden';
    $('#azkarContentView').classList.remove('active');
    $('#azkarListBody').style.display = '';
    await loadAzkarCategories();
};
window.closeAzkarPage = function() {
    $('#azkarPage').classList.remove('active');
    if (!$('#calendarPage').classList.contains('active') && !$('#tasbihPage').classList.contains('active') && !$('#hadithPage').classList.contains('active')) {
        document.body.style.overflow = '';
    }
    $('#azkarContentView').classList.remove('active');
    $('#azkarListBody').style.display = '';
};

async function loadAzkarCategories() {
    const bar = $('#azkarCatsBar');
    const listBody = $('#azkarListBody');
    listBody.innerHTML = '<div class="loader"><i class="fas fa-spinner fa-spin"></i></div>';
    try {
        const res = await fetch(`${API_BASE}get_azkar_categories`);
        const cats = await res.json();
        state.azkarCategories = cats;
        if (!cats.length) { bar.innerHTML = ''; listBody.innerHTML = '<div class="loader">لا توجد أذكار</div>'; return; }
        bar.innerHTML = cats.map((c, i) => `<button class="azkar-cat-pill ${i === 0 ? 'active' : ''}" onclick="showAzkarCat(${c.id}, this)">${escapeHtml(c.name)}</button>`).join('');
        listBody.innerHTML = cats.map(c => `
            <div class="azkar-item-row" onclick="showAzkarCat(${c.id}, null)">
                <span class="row-title">${escapeHtml(c.name)}</span>
                <i class="fas fa-chevron-left row-arrow"></i>
            </div>
        `).join('');
    } catch (e) { listBody.innerHTML = '<div class="loader">⚠️ خطأ</div>'; }
}

window.showAzkarCat = async function(catId, btn) {
    if (btn) { $$('.azkar-cat-pill').forEach(b => b.classList.remove('active')); btn.classList.add('active'); }
    const listBody = $('#azkarListBody');
    const contentView = $('#azkarContentView');
    listBody.style.display = 'none';
    contentView.classList.add('active');
    contentView.innerHTML = '<div class="loader"><i class="fas fa-spinner fa-spin"></i></div>';
    contentView.scrollTop = 0;
    try {
        const res = await fetch(`${API_BASE}get_azkar&category_id=${catId}`);
        const azkar = await res.json();
        const catName = state.azkarCategories.find(c => c.id == catId)?.name || 'أذكار';
        if (!azkar.length) { contentView.innerHTML = '<div class="loader">لا توجد أذكار</div>'; return; }
        contentView.innerHTML = `
            <button class="azkar-back-btn" onclick="backToAzkarList()"><i class="fas fa-arrow-right"></i> العودة</button>
            <div class="azkar-content-title">${escapeHtml(catName)}</div>
            ${azkar.map(z => `<div class="zikr-text-block">${escapeHtml(z.text)}${z.reward ? `<span class="source-text">🌟 ${escapeHtml(z.reward)}</span>` : ''}</div>`).join('')}
        `;
    } catch (e) { contentView.innerHTML = '<div class="loader">⚠️ خطأ</div>'; }
};
window.backToAzkarList = function() {
    $('#azkarContentView').classList.remove('active');
    $('#azkarListBody').style.display = '';
};

/* ============================================================
   HADITH
   ============================================================ */
window.openHadithPage = async function() {
    $('#hadithPage').classList.add('active');
    document.body.style.overflow = 'hidden';
    $('#hadithContentView').classList.remove('active');
    $('#hadithListBody').style.display = '';
    await loadHadiths();
};
window.closeHadithPage = function() {
    $('#hadithPage').classList.remove('active');
    document.body.style.overflow = '';
    $('#hadithContentView').classList.remove('active');
    $('#hadithListBody').style.display = '';
};

async function loadHadiths() {
    const listBody = $('#hadithListBody');
    listBody.innerHTML = '<div class="loader"><i class="fas fa-spinner fa-spin"></i></div>';
    try {
        const res = await fetch(`${API_BASE}get_hadiths`);
        const hadiths = await res.json();
        if (!hadiths.length) { listBody.innerHTML = '<div class="loader">لا توجد أحاديث</div>'; return; }
        listBody.innerHTML = hadiths.map((h, idx) => `
            <div class="hadith-item-row" onclick='showHadithByIndex(${idx})'>
                <span class="row-title">${escapeHtml(h.title || (h.text || '').substring(0, 60))}</span>
                <i class="fas fa-chevron-left row-arrow"></i>
            </div>
        `).join('');
        listBody._hadiths = hadiths;
    } catch (e) { listBody.innerHTML = '<div class="loader">⚠️ خطأ</div>'; }
}

window.showHadithByIndex = function(idx) {
    const listBody = $('#hadithListBody');
    const hadiths = listBody._hadiths || [];
    const h = hadiths[idx];
    if (!h) return;
    const contentView = $('#hadithContentView');
    listBody.style.display = 'none';
    contentView.classList.add('active');
    contentView.innerHTML = `
        <button class="azkar-back-btn" onclick="backToHadithList()"><i class="fas fa-arrow-right"></i> العودة</button>
        ${h.title ? `<div class="azkar-content-title">${escapeHtml(h.title)}</div>` : ''}
        <div class="hadith-text-block">${escapeHtml(h.text)}${h.narrator || h.source ? `<span class="meta-text">${h.narrator ? '👤 ' + escapeHtml(h.narrator) : ''}${h.source ? ' • 📚 ' + escapeHtml(h.source) : ''}</span>` : ''}</div>
    `;
    contentView.scrollTop = 0;
};
window.backToHadithList = function() {
    $('#hadithContentView').classList.remove('active');
    $('#hadithListBody').style.display = '';
};

/* ============================================================
   TASBIH
   ============================================================ */
window.openTasbihPage = function() {
    $('#tasbihPage').classList.add('active');
    document.body.style.overflow = 'hidden';
    updateTasbihDisplay();
};
window.closeTasbihPage = function() {
    $('#tasbihPage').classList.remove('active');
    document.body.style.overflow = '';
};
function updateTasbihDisplay() {
    const el = $('#tasbihCount');
    if (el) el.textContent = state.tasbihCount;
}
window.incrementTasbih = function() {
    state.tasbihCount++;
    localStorage.setItem('tasbih_count', state.tasbihCount);
    const el = $('#tasbihCount');
    if (el) { el.classList.add('pulse'); setTimeout(() => el.classList.remove('pulse'), 150); el.textContent = state.tasbihCount; }
    if (navigator.vibrate) navigator.vibrate(25);
    const target = parseInt(localStorage.getItem('tasbih_target') || '0');
    if (target > 0 && state.tasbihCount === target) { showToast('🎉 وصلت للهدف!'); if (navigator.vibrate) navigator.vibrate([100, 50, 100]); }
};
window.openTargetModal = function() { $('#tasbihTargetModal').classList.add('active'); };
window.closeTargetModal = function() { $('#tasbihTargetModal').classList.remove('active'); };
window.setTarget = function(t) { localStorage.setItem('tasbih_target', t); showToast('✅ الهدف: ' + t); closeTargetModal(); };
window.openResetModal = function() { $('#tasbihResetModal').classList.add('active'); };
window.closeResetModal = function() { $('#tasbihResetModal').classList.remove('active'); };
window.confirmReset = function() {
    state.tasbihCount = 0;
    localStorage.setItem('tasbih_count', '0');
    updateTasbihDisplay();
    closeResetModal();
    showToast('✅ تم إعادة التعيين');
};

/* ============================================================
   CALENDAR — مع مواقيت الصلاة لليوم المختار
   ============================================================ */
let calendarSelectedDay = null;

window.openCalendarPage = function() {
    $('#calendarPage').classList.add('active');
    document.body.style.overflow = 'hidden';
    calendarSelectedDay = null;
    renderCalendar();
};
window.closeCalendarPage = function() {
    $('#calendarPage').classList.remove('active');
    document.body.style.overflow = '';
};
window.changeMonth = function(d) {
    state.calendarDate.setMonth(state.calendarDate.getMonth() + d);
    calendarSelectedDay = null;
    $('#calendarDayDetail').classList.remove('active');
    $('#calendarPrayerTimes').classList.remove('active');
    renderCalendar();
};

function renderCalendar() {
    const date = state.calendarDate;
    const year = date.getFullYear();
    const month = date.getMonth();
    const months = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
    const days = ['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const today = new Date();
    const isThisMonth = today.getFullYear() === year && today.getMonth() === month;
    const todayEl = $('#calendarToday');
    const dayName = days[today.getDay()];
    const gregDate = `${today.getDate()} ${months[today.getMonth()]} ${today.getFullYear()}`;
    let hijriStr = '';
    try { hijriStr = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { day: 'numeric', month: 'long', year: 'numeric' }).format(today); } catch(e) {}
    todayEl.innerHTML = `<div class="day-name">${dayName}</div>${hijriStr ? `<div class="hijri-date">${hijriStr}</div>` : ''}<div class="gregorian-date">${gregDate}</div>`;
    $('#calendarMonthTitle').textContent = `${months[month]} ${year}`;
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysInPrevMonth = new Date(year, month, 0).getDate();
    let html = days.map(d => `<div class="calendar-day-name">${d.substring(0, 3)}</div>`).join('');
    for (let i = firstDay - 1; i >= 0; i--) html += `<div class="calendar-day other-month">${daysInPrevMonth - i}</div>`;
    for (let d = 1; d <= daysInMonth; d++) {
        const isToday = isThisMonth && d === today.getDate();
        const isSelected = calendarSelectedDay === d;
        let hijriSmall = '';
        try {
            const dDate = new Date(year, month, d);
            const hd = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { day: 'numeric' }).format(dDate);
            if (hd === '1') { const hMonth = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { month: 'short' }).format(dDate); hijriSmall = `<span class="hijri-small">${hMonth}</span>`; }
        } catch (e) {}
        html += `<div class="calendar-day ${isToday ? 'today' : ''} ${isSelected ? 'selected' : ''}" onclick="selectCalendarDay(${year}, ${month}, ${d}, this)">${d}${hijriSmall}</div>`;
    }
    const remaining = 42 - (firstDay + daysInMonth);
    for (let d = 1; d <= remaining; d++) html += `<div class="calendar-day other-month">${d}</div>`;
    $('#calendarGrid').innerHTML = html;
}

window.selectCalendarDay = function(year, month, day, el) {
    calendarSelectedDay = day;
    $$('.calendar-day').forEach(d => d.classList.remove('selected'));
    if (el) el.classList.add('selected');
    const date = new Date(year, month, day);
    state.calendarSelectedDate = date;
    const daysAr = ['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
    const months = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
    const dayName = daysAr[date.getDay()];
    const greg = `${day} ${months[month]} ${year}`;
    let hijri = '';
    try { hijri = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { day: 'numeric', month: 'long', year: 'numeric' }).format(date); } catch(e) {}
    const detail = $('#calendarDayDetail');
    detail.classList.add('active');
    detail.innerHTML = `<h4><i class="fas fa-calendar-day"></i> ${dayName}</h4>
        <div class="detail-row"><span class="label">التاريخ الميلادي</span><span class="value">${greg}</span></div>
        ${hijri ? `<div class="detail-row"><span class="label">التاريخ الهجري</span><span class="value">${hijri}</span></div>` : ''}`;

    // جلب مواقيت الصلاة لهذا التاريخ
    loadCalendarPrayerTimes(date);
};

async function loadCalendarPrayerTimes(date) {
    const container = $('#calendarPrayerTimes');
    if (!container) return;
    container.classList.add('active');
    container.innerHTML = '<div class="loader" style="padding:20px;"><i class="fas fa-spinner fa-spin"></i></div>';
    const cityName = state.selectedProvince || 'القاهرة';
    const cityData = egyptianCities.find(c => c.ar === cityName);
    const cityEn = cityData ? cityData.en : 'Cairo';
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    const dateStr = `${dd}-${mm}-${yyyy}`;
    try {
        const res = await fetch(`https://api.aladhan.com/v1/timingsByCity/${dateStr}?city=${encodeURIComponent(cityEn)}&country=Egypt&method=5`);
        const data = await res.json();
        if (!data || !data.data || !data.data.timings) throw new Error('invalid');
        const t = data.data.timings;
        const prayers = [
            { key: 'Fajr', label: 'الفجر' },
            { key: 'Sunrise', label: 'الشروق' },
            { key: 'Dhuhr', label: 'الظهر' },
            { key: 'Asr', label: 'العصر' },
            { key: 'Maghrib', label: 'المغرب' },
            { key: 'Isha', label: 'العشاء' }
        ];
        container.innerHTML = `<h4><i class="fas fa-clock"></i> مواقيت الصلاة في ${escapeHtml(cityName)}</h4>
            <div class="pt-grid">
                ${prayers.map(p => `<div class="pt-row"><span class="name">${p.label}</span><span class="value">${convertTo12Hour(t[p.key])}</span></div>`).join('')}
            </div>`;
    } catch (e) {
        container.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:16px;font-size:13px;">⚠️ تعذر جلب المواقيت</div>';
    }
}

/* ============================================================
   SURAHS
   ============================================================ */
async function loadSurahs() {
    const c = $('#surahList'); if (!c) return;
    if (state.allSurahs.length > 0) { displaySurahs(state.allSurahs); return; }
    c.innerHTML = '<div class="loader"><i class="fas fa-spinner fa-spin"></i> جاري التحميل...</div>';
    try {
        const res = await fetch(`${ALQURAN_API}/surah`);
        const data = await res.json();
        state.allSurahs = data.data;
        displaySurahs(state.allSurahs);
    } catch (e) { c.innerHTML = '<div class="loader">⚠️ خطأ</div>'; }
}

function displaySurahs(surahs, cid) {
    cid = cid || 'surahList';
    const c = document.getElementById(cid); if (!c) return;
    c.innerHTML = surahs.map(s => `
        <div class="card" onclick="openSurah(${s.number}, '${s.name.replace(/'/g, "\\'")}')">
            <div class="num-badge">${s.number}</div>
            <div class="surah-info"><div class="surah-name">${escapeHtml(s.name)}</div><div class="surah-details"><span>${s.numberOfAyahs} آية</span></div></div>
        </div>
    `).join('');
}

window.filterSurahs = function (q) {
    const cleanQ = removeArabicDiacritics(q.trim());
    if (!cleanQ) { displaySurahs(state.allSurahs); return; }
    const f = state.allSurahs.filter(s => {
        const cleanName = removeArabicDiacritics(s.name);
        return cleanName.includes(cleanQ) || String(s.number).includes(cleanQ);
    });
    displaySurahs(f);
};

function renderJuzGrid() {
    const c = $('#juzContainer'); if (!c) return;
    let h = '<div class="juz-grid">';
    for (let i = 1; i <= 30; i++) h += `<div class="juz-box" onclick="showJuzDetails(${i})"><span>${i}</span><small>الجزء</small></div>`;
    h += '</div>';
    c.innerHTML = h;
}
window.renderJuzGrid = renderJuzGrid;

window.showJuzDetails = async function (n) {
    const c = $('#juzContainer');
    c.innerHTML = '<div class="loader"><i class="fas fa-spinner fa-spin"></i> جاري التحميل...</div>';
    try {
        const res = await fetch(`${ALQURAN_API}/juz/${n}/quran-uthmani`);
        const data = await res.json();
        const ids = [...new Set(data.data.ayahs.map(a => a.surah.number))];
        if (state.allSurahs.length === 0) {
            const r2 = await fetch(`${ALQURAN_API}/surah`);
            const d2 = await r2.json();
            state.allSurahs = d2.data;
        }
        const f = state.allSurahs.filter(s => ids.includes(s.number));
        c.innerHTML = `<div class="back-button" onclick="renderJuzGrid()"><i class="fas fa-arrow-right"></i> العودة</div><div id="juzSurahList" class="surah-list"></div>`;
        displaySurahs(f, 'juzSurahList');
    } catch (e) { c.innerHTML = '<div class="loader">⚠️ خطأ</div>'; }
};

/* ============================================================
   RECITERS GRID
   ============================================================ */
async function loadRecitersGrid() {
    const grid = $('#recitersGrid'); if (!grid) return;
    if (grid.dataset.loaded === 'true') return;
    if (state.allReciters.length === 0) {
        try { const res = await fetch(`${API_BASE}get_reciters`); state.allReciters = await res.json(); } catch (e) {}
    }
    if (state.allReciters.length === 0) { grid.innerHTML = `<div class="loader">${DATA.texts.emptyReciters}</div>`; return; }
    grid.innerHTML = state.allReciters.map(r => {
        const img = r.image ? 'uploads/' + r.image : 'https://via.placeholder.com/80/0d2b35/c9a959?text=🎤';
        const locked = r.is_locked == 1;
        return `<div class="reciter-card ${locked ? 'locked' : ''}" data-name="${escapeHtml(r.name)}" data-lock-message="${escapeHtml(r.lock_message || 'قريباً')}" onclick="${locked ? 'showLockedMessage(this)' : `openReciterPage(${r.id}, '${escapeHtml(r.name).replace(/'/g, "\\'")}', '${r.image || ''}')`}">
            ${locked ? '<div class="lock-overlay"><i class="fas fa-lock"></i></div>' : ''}
            <img src="${img}" onerror="this.src='https://via.placeholder.com/80/0d2b35/c9a959?text=🎤'" loading="lazy">
            <h4>${escapeHtml(r.name)}</h4>
        </div>`;
    }).join('');
    grid.dataset.loaded = 'true';
}

window.filterReciters = function (q) {
    const cleanQ = removeArabicDiacritics(q.trim());
    if (!cleanQ) { $$('.reciter-card').forEach(c => c.style.display = ''); return; }
    $$('.reciter-card').forEach(c => {
        const cleanName = removeArabicDiacritics(c.dataset.name || '');
        c.style.display = cleanName.includes(cleanQ) ? '' : 'none';
    });
};
window.filterSurahsInReciter = function (q) {
    const cleanQ = removeArabicDiacritics(q.trim());
    let v = 0;
    $$('#reciterSurahsList .surah-audio-item').forEach(i => {
        const cleanName = removeArabicDiacritics(i.dataset.surahName || '');
        if (!cleanQ || cleanName.includes(cleanQ)) { i.style.display = ''; v++; } else i.style.display = 'none';
    });
    if (v === 0 && q) showToast('😕 لا نتائج');
};
window.showLockedMessage = function (el) { showToast('🔒 ' + (el.dataset.lockMessage || 'قريباً')); };

window.openReciterPage = async function (id, name, img) {
    const rp = $('#reciterPage');
    if (rp) { rp.classList.add('active'); rp.style.display = 'flex'; }
    $('#reciterPageName').textContent = name;
    $('#reciterPageImg').src = img ? ('uploads/' + img) : 'https://via.placeholder.com/50/0d2b35/c9a959?text=🎤';
    $('#reciterPageCount').textContent = 'جاري التحميل...';
    $('#reciterSurahsList').innerHTML = '<div class="loader"><i class="fas fa-spinner fa-spin"></i> جاري التحميل...</div>';
    try {
        const res = await fetch(`${API_BASE}get_audios&reciter_id=${id}`);
        const audios = await res.json();
        if (!audios.length) { $('#reciterSurahsList').innerHTML = '<div class="loader">لا توجد سور</div>'; return; }
        $('#reciterPageCount').innerHTML = `<i class="fas fa-headphones"></i> ${audios.length} سورة`;
        state.currentAudioPlaylist = audios.map(a => ({
            surah_name: a.surah_name,
            url: a.audio_type === 'file' ? 'uploads/' + a.file_path : a.audio_url,
            reciter: name,
            img: img ? ('uploads/' + img) : 'https://via.placeholder.com/80/0d2b35/c9a959?text=🎤'
        }));
        $('#reciterSurahsList').innerHTML = audios.map((a, idx) => {
            const url = a.audio_type === 'file' ? 'uploads/' + a.file_path : a.audio_url;
            return `<div class="surah-audio-item" data-surah-name="${escapeHtml(a.surah_name)}">
                <div class="surah-info">
                    <div class="surah-name" style="font-weight:700;font-size:16px;color:#fff;">${escapeHtml(a.surah_name)}</div>
                    <div class="surah-details" style="font-size:11px;color:#a0b9c4;">رقم ${a.surah_number || ''}</div>
                </div>
                <div style="display:flex;gap:8px;">
                    <button class="play-audio-btn" onclick="playReciterAudio('${url.replace(/'/g, "\\'")}', '${a.surah_name.replace(/'/g, "\\'")}', '${name.replace(/'/g, "\\'")}', 'uploads/${img || ''}', ${idx})"><i class="fas fa-play"></i></button>
                    <button class="download-audio-btn" onclick="downloadFile('${url}', '${a.surah_name}.mp3')"><i class="fas fa-download"></i></button>
                </div>
            </div>`;
        }).join('');
    } catch (e) { $('#reciterSurahsList').innerHTML = '<div class="loader">⚠️ خطأ</div>'; }
};
window.closeReciterPage = function () { const rp = $('#reciterPage'); if (rp) { rp.classList.remove('active'); rp.style.display = 'none'; } };

/* ============================================================
   AUDIO PLAYER - SPOTIFY
   ============================================================ */
const audio = new Audio();
audio.preload = 'metadata';

audio.onerror = function() {
    showToast('⚠️ تعذر تشغيل الملف الصوتي');
    updateAudioUI();
};

window.playReciterAudio = function (url, surah, reciter, img, idx) {
    state.currentAudioTrackIndex = idx;
    state.currentTrackTitle = surah;
    state.currentTrackUrl = url;
    openSpotifyPlayer();
    const spotifyImg = $('#spotifyCoverImg');
    const miniImg = $('#miniPlayerImg');
    if (spotifyImg) spotifyImg.src = img;
    if (miniImg) miniImg.src = img;
    $('#spotifyTitle').textContent = surah;
    $('#spotifyArtist').textContent = reciter;
    $('#miniPlayerTitle').textContent = surah;
    $('#miniPlayerSub').textContent = reciter;
    if (audio.src) audio.pause();
    audio.src = url;
    audio.load();
    audio.play().then(updateAudioUI).catch(() => {});
    updateAudioLikeButton();
    trackAction('play_audio', 'surah', idx);
};

function updateAudioUI() {
    const icon = audio.paused ? 'fa-play' : 'fa-pause';
    const spotifyBtn = $('#spotifyPlayBtn');
    const miniBtn = $('#miniPlayerPlayBtn');
    if (spotifyBtn) spotifyBtn.innerHTML = `<i class="fas ${icon}"></i>`;
    if (miniBtn) miniBtn.innerHTML = `<i class="fas ${icon}"></i>`;
    const coverWrap = $('#spotifyCoverWrap');
    if (coverWrap) coverWrap.classList.toggle('playing', !audio.paused);
}

audio.ontimeupdate = () => {
    if (!audio.duration) return;
    const p = (audio.currentTime / audio.duration) * 100;
    const progressFill = $('#spotifyProgressFill');
    const progressInput = $('#spotifyProgressInput');
    const miniFill = $('#miniPlayerProgressFill');
    const currentTime = $('#spotifyCurrentTime');
    if (progressFill) progressFill.style.width = p + '%';
    if (progressInput) progressInput.value = p;
    if (miniFill) miniFill.style.width = p + '%';
    if (currentTime) currentTime.textContent = formatTime(audio.currentTime);
};
audio.onloadedmetadata = () => {
    const d = $('#spotifyDurationTime');
    if (d) d.textContent = formatTime(audio.duration);
};
audio.onended = () => {
    if (state.repeatMode) { audio.currentTime = 0; audio.play(); }
    else { playNextTrack(); }
};

window.toggleAudioPlay = function () {
    if (!audio.src) return;
    if (audio.paused) audio.play().then(updateAudioUI);
    else { audio.pause(); updateAudioUI(); }
};

window.playNextTrack = function () {
    if (!state.currentAudioPlaylist.length) return;
    if (state.shuffleMode) {
        state.currentAudioTrackIndex = Math.floor(Math.random() * state.currentAudioPlaylist.length);
    } else {
        state.currentAudioTrackIndex = (state.currentAudioTrackIndex + 1) % state.currentAudioPlaylist.length;
    }
    playTrackAt(state.currentAudioTrackIndex);
};
window.playPrevTrack = function () {
    if (!state.currentAudioPlaylist.length) return;
    state.currentAudioTrackIndex = (state.currentAudioTrackIndex - 1 + state.currentAudioPlaylist.length) % state.currentAudioPlaylist.length;
    playTrackAt(state.currentAudioTrackIndex);
};
function playTrackAt(i) {
    const t = state.currentAudioPlaylist[i];
    if (!t) return;
    state.currentTrackTitle = t.surah_name;
    state.currentTrackUrl = t.url;
    const spotifyImg = $('#spotifyCoverImg');
    const miniImg = $('#miniPlayerImg');
    if (spotifyImg) spotifyImg.src = t.img;
    if (miniImg) miniImg.src = t.img;
    $('#spotifyTitle').textContent = t.surah_name;
    $('#spotifyArtist').textContent = t.reciter;
    $('#miniPlayerTitle').textContent = t.surah_name;
    $('#miniPlayerSub').textContent = t.reciter;
    if (audio.src) audio.pause();
    audio.src = t.url;
    audio.load();
    audio.play().then(updateAudioUI).catch(() => {});
    updateAudioLikeButton();
}

window.openSpotifyPlayer = function () {
    $('#spotifyPlayer').classList.add('active');
    document.body.style.overflow = 'hidden';
};
window.closeSpotifyPlayer = function () {
    $('#spotifyPlayer').classList.remove('active');
    document.body.style.overflow = '';
    $('#miniPlayer').classList.add('visible');
};
window.closeMiniPlayer = function () {
    $('#miniPlayer').classList.remove('visible');
    audio.pause();
    audio.src = '';
    updateAudioUI();
};

window.toggleShuffle = function () {
    state.shuffleMode = !state.shuffleMode;
    const btn = $('#spotifyShuffleBtn');
    if (btn) btn.classList.toggle('active', state.shuffleMode);
    showToast(state.shuffleMode ? '🔀 خلط مفعّل' : '🔀 خلط معطل');
};
window.toggleRepeat = function () {
    state.repeatMode = !state.repeatMode;
    const btn = $('#spotifyRepeatBtn');
    if (btn) btn.classList.toggle('active', state.repeatMode);
    showToast(state.repeatMode ? '🔁 تكرار مفعّل' : '🔁 تكرار معطل');
};
window.toggleAddToPlaylist = function () {
    const btn = $('#spotifyAddBtn');
    if (btn) {
        btn.classList.toggle('added');
        const added = btn.classList.contains('added');
        showToast(added ? '✅ تمت الإضافة للمكتبة' : 'تمت الإزالة');
    }
};

window.toggleAudioLike = function () {
    if (!state.currentTrackUrl) return;
    const key = 'audio_liked_' + state.currentTrackUrl;
    const liked = localStorage.getItem(key) === 'true';
    if (liked) { localStorage.removeItem(key); showToast('تم إزالة الإعجاب'); }
    else { localStorage.setItem(key, 'true'); showToast('❤️ إعجاب'); }
    updateAudioLikeButton();
};
function updateAudioLikeButton() {
    if (!state.currentTrackUrl) return;
    const liked = localStorage.getItem('audio_liked_' + state.currentTrackUrl) === 'true';
    const btn = $('#spotifyLikeBtn');
    const bottomBtn = $('#spotifyBottomLike');
    if (btn) btn.classList.toggle('liked', liked);
    if (bottomBtn) bottomBtn.style.color = liked ? '#1ed760' : '';
}

window.downloadCurrentAudio = function () {
    if (!state.currentTrackUrl) return;
    const filename = (state.currentTrackTitle || 'audio') + '.mp3';
    downloadFile(state.currentTrackUrl, filename);
};

document.addEventListener('DOMContentLoaded', () => {
    const progressInput = $('#spotifyProgressInput');
    if (progressInput) progressInput.addEventListener('input', function () {
        if (audio.duration) audio.currentTime = (parseFloat(this.value) / 100) * audio.duration;
    });
});

/* ============================================================
   DOWNLOAD
   ============================================================ */
window.downloadFile = function (url, filename) {
    if (!url) { showToast('⚠️ لا يوجد ملف'); return; }
    if (url.includes('youtube') || url.includes('screenpal')) { showToast('⚠️ غير قابل للتحميل'); return; }
    showToast('⬇️ جاري التحميل...');
    trackAction('download', 'file', filename);
    const proxyUrl = `${API_BASE}proxy_download&url=${encodeURIComponent(url)}&filename=${encodeURIComponent(filename)}`;
    try {
        const a = document.createElement('a');
        a.href = url;
        a.download = filename || 'download';
        a.style.display = 'none';
        if (url.startsWith('http') && !url.startsWith(window.location.origin)) a.href = proxyUrl;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => document.body.removeChild(a), 200);
    } catch (e) {
        window.location.href = proxyUrl;
    }
};

/* ============================================================
   QURAN READER
   ============================================================ */
const preloaded = {};
function preloadPage(n) { if (n < 1 || n > TOTAL_PAGES || preloaded[n]) return; const img = new Image(); img.src = QURAN_PAGES_API + String(n).padStart(3, '0') + '.png'; preloaded[n] = img; }

function loadQuranPage(n) {
    n = Math.max(1, Math.min(TOTAL_PAGES, n));
    state.currentPage = n;
    localStorage.setItem('lastQuranPage', n);
    let sName = null;
    for (const [num, sp] of Object.entries(surahStartPages)) { if (sp <= n) sName = surahNames[num]; }
    if (sName) { const rt = $('#readerTitle'); if (rt) rt.textContent = `سورة ${sName}`; }
    const img = $('#quranPageImg'); if (img) img.src = QURAN_PAGES_API + String(n).padStart(3, '0') + '.png';
    preloadPage(n - 1); preloadPage(n + 1); preloadPage(n + 2);
    const pt = $('#pageNumberText'); if (pt) pt.textContent = `${n} / ${TOTAL_PAGES}`;
    const pd = $('#pageNumberDisplay'); if (pd) pd.textContent = `صفحة ${n}`;
    const prev = $('#prevPageBtn'), next = $('#nextPageBtn');
    if (prev) prev.disabled = n <= 1;
    if (next) next.disabled = n >= TOTAL_PAGES;
}
window.changePage = function (d) { const np = state.currentPage + d; if (np >= 1 && np <= TOTAL_PAGES) loadQuranPage(np); };
window.openSurah = function (num, name) { const sp = surahStartPages[num] || 1; const screen = $('#readerScreen'); if (screen) { screen.classList.add('active'); screen.style.display = 'flex'; } const rt = $('#readerTitle'); if (rt) rt.textContent = `سورة ${name}`; loadQuranPage(sp); };
window.closeReader = function () { const s = $('#readerScreen'); if (s) { s.classList.remove('active'); s.style.display = 'none'; } };
window.toggleQuranNightMode = function () { state.quranNightMode = !state.quranNightMode; localStorage.setItem('quranNightMode', state.quranNightMode); const c = $('#quranContainer'); if (c) c.classList.toggle('night-mode', state.quranNightMode); };
window.changeQuranFontSize = function (d) { state.quranFontSize = Math.max(60, Math.min(150, state.quranFontSize + d * 10)); localStorage.setItem('quranFontSize', state.quranFontSize); const l = $('#quranFontSizeLabel'); if (l) l.textContent = state.quranFontSize + '%'; const img = $('#quranPageImg'); if (img) { img.style.width = state.quranFontSize + '%'; img.style.maxWidth = state.quranFontSize + '%'; } };

/* ============================================================
   BOOKS
   ============================================================ */
async function loadAllBooks() {
    if (!DATA.sections.books) return;
    const c = $('#booksList'); if (!c) return;
    if (state.allBooks.length > 0) { renderBooks(state.allBooks); return; }
    try { const res = await fetch(`${API_BASE}get_books&status=1`); const books = await res.json(); state.allBooks = books; renderBooks(books); }
    catch (e) { c.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:#e74c3c;padding:40px;">⚠️ خطأ</div>'; }
}
function renderBooks(books) {
    const c = $('#booksList'); if (!c) return;
    if (!books.length) { c.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:#a0b9c4;padding:40px;">📭 ${DATA.texts.emptyBooks}</div>`; return; }
    c.innerHTML = books.map(b => `
        <div class="book-card" onclick="readBook(${b.id}, '${escapeHtml(b.title).replace(/'/g, "\\'")}')">
            <span class="book-category">${escapeHtml(b.category)}</span>
            <img src="${b.cover_image ? 'uploads/books/covers/' + escapeHtml(b.cover_image) : 'https://via.placeholder.com/300x450/0d2b35/c9a959?text=📚'}" class="book-cover" loading="lazy" onerror="this.src='https://via.placeholder.com/300x450/0d2b35/c9a959?text=📚'">
            <div class="book-info"><div class="book-title">${escapeHtml(b.title)}</div><div class="book-author">${escapeHtml(b.author)}</div><div class="book-pages">${b.pages} صفحة</div></div>
        </div>
    `).join('');
}
window.filterBooks = function (q) {
    const cleanQ = removeArabicDiacritics(q.trim());
    const f = state.allBooks.filter(b => !cleanQ || removeArabicDiacritics(b.title).includes(cleanQ) || removeArabicDiacritics(b.author).includes(cleanQ));
    renderBooks(f);
};
window.readBook = function (id, title) {
    fetch(`${API_BASE}get_book&id=${id}`).then(r => r.json()).then(b => {
        if (!b || !b.id) { showToast('⚠️ غير موجود'); return; }
        fetch(`${API_BASE}increment_book_views&id=${id}`).catch(() => {});
        if (b.source_type === 'url' && b.pdf_url) { window.open(b.pdf_url, '_blank'); return; }
        if (!b.pdf_file) { showToast('⚠️ لا يوجد PDF'); return; }
        openPdf('uploads/books/pdfs/' + b.pdf_file, title);
    }).catch(() => showToast('⚠️ خطأ'));
};
function openPdf(url, title) {
    $('#pdfReaderTitle').textContent = title || 'قراءة';
    $('#pdfReaderModal').classList.add('active');
    document.body.style.overflow = 'hidden';
    if (typeof pdfjsLib === 'undefined') { const s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'; s.onload = () => loadPdf(url); document.head.appendChild(s); } else loadPdf(url);
}
function loadPdf(url) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    const c = $('#pdfReaderBody');
    c.innerHTML = '<div style="color:#fff;padding:40px;text-align:center;"><i class="fas fa-spinner fa-spin" style="font-size:30px;"></i></div>';
    pdfjsLib.getDocument(url).promise.then(pdf => {
        state.pdfDoc = pdf; state.pdfTotalPages = pdf.numPages; state.pdfPageNum = 1;
        renderPdf(1);
        $('#pdfPageInput').max = pdf.numPages; $('#pdfPageInput').value = 1;
        $('#pdfPageIndicator').textContent = `صفحة 1 / ${pdf.numPages}`;
    }).catch(() => { c.innerHTML = '<div style="color:#e74c3c;padding:40px;text-align:center;">⚠️ فشل التحميل</div>'; });
}
function renderPdf(n) {
    if (!state.pdfDoc) return;
    state.pdfDoc.getPage(n).then(page => {
        const vp = page.getViewport({ scale: state.pdfScale });
        const canvas = document.createElement('canvas');
        canvas.width = vp.width; canvas.height = vp.height;
        const ctx = canvas.getContext('2d');
        page.render({ canvasContext: ctx, viewport: vp }).promise.then(() => {
            const c = $('#pdfReaderBody'); c.innerHTML = ''; c.appendChild(canvas);
            $('#pdfPageNum').textContent = `صفحة ${n} / ${state.pdfTotalPages}`;
            $('#pdfPageIndicator').textContent = `صفحة ${n} / ${state.pdfTotalPages}`;
            $('#pdfPageInput').value = n; c.scrollTop = 0;
        });
    });
}
window.pdfPrevPage = function () { if (state.pdfPageNum > 1) { state.pdfPageNum--; renderPdf(state.pdfPageNum); } };
window.pdfNextPage = function () { if (state.pdfPageNum < state.pdfTotalPages) { state.pdfPageNum++; renderPdf(state.pdfPageNum); } };
window.pdfGoToPage = function (v) { let n = parseInt(v); if (isNaN(n) || n < 1) n = 1; if (n > state.pdfTotalPages) n = state.pdfTotalPages; state.pdfPageNum = n; renderPdf(n); };
window.closePdfReader = function () { $('#pdfReaderModal').classList.remove('active'); document.body.style.overflow = ''; state.pdfDoc = null; };

/* ============================================================
   SHARE
   ============================================================ */
window.openSharePopup = function (t, id) { state.shareVideoId = id; state.shareVideoTitle = t; $('#sharePopup').classList.add('active'); };
window.closeSharePopup = function () { $('#sharePopup').classList.remove('active'); };
function getShareLink() { return DATA.baseUrl + '?video=' + state.shareVideoId; }
window.shareToWhatsApp = function () { window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent('🎬 ' + state.shareVideoTitle + '\n' + getShareLink())}`, '_blank'); closeSharePopup(); trackAction('share', 'video', state.shareVideoId); };
window.shareToFacebook = function () { window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(getShareLink())}`, '_blank'); closeSharePopup(); trackAction('share', 'video', state.shareVideoId); };
window.copyShareLink = function () { if (navigator.clipboard) navigator.clipboard.writeText(getShareLink()).then(() => showToast('✅ تم النسخ')); closeSharePopup(); trackAction('share', 'video', state.shareVideoId); };
window.shareToSystem = function () { if (navigator.share) navigator.share({ title: state.shareVideoTitle, url: getShareLink() }).catch(() => {}); else copyShareLink(); };

window.shareCurrentProfile = function () {
    if (!state.currentProfileId) return;
    const l = DATA.baseUrl + '?reciter=' + state.currentProfileId;
    if (navigator.share) navigator.share({ title: state.currentProfileName, url: l }).catch(() => {});
    else if (navigator.clipboard) navigator.clipboard.writeText(l).then(() => showToast('✅ تم نسخ رابط البروفايل'));
};

/* ============================================================
   VIDEO PLAYER (YouTube embed fix)
   ============================================================ */
window.openVideoPlayerById = async function (id) {
    const modal = $('#videoPlayerModal'); const c = $('#videoPlayerContainer'); const titleEl = $('#videoPlayerTitle');
    if (!modal || !c) return;
    titleEl.textContent = 'جاري التحميل...';
    c.innerHTML = '<div style="color:#c9a959;padding:40px;text-align:center;"><i class="fas fa-spinner fa-spin" style="font-size:30px;"></i></div>';
    modal.classList.add('active'); modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    try {
        const res = await fetch(`${API_BASE}get_video&id=${id}`);
        const v = await res.json();
        if (!v || !v.id) { titleEl.textContent = 'خطأ'; c.innerHTML = '<div style="color:#e74c3c;padding:40px;text-align:center;">⚠️ غير موجود</div>'; return; }
        titleEl.textContent = v.title || 'فيديو';
        const src = v.video_type === 'file' ? 'uploads/' + v.file_path : v.video_url;
        const embedInfo = getVideoEmbedInfo(src);
        c.innerHTML = '';
        if (embedInfo.isIframe && embedInfo.src) {
            const iframe = document.createElement('iframe');
            iframe.src = embedInfo.src;
            iframe.allowFullscreen = true;
            iframe.setAttribute('allow', 'autoplay; fullscreen; encrypted-media; picture-in-picture');
            c.appendChild(iframe);
        } else if (embedInfo.isMP4) {
            const video = document.createElement('video');
            video.src = src; video.controls = true; video.playsInline = true; video.autoplay = true;
            video.style.width = '100%'; video.style.height = '100%'; video.style.objectFit = 'contain';
            c.appendChild(video);
            video.play().catch(() => {});
        } else {
            c.innerHTML = `<div style="color:#e74c3c;padding:40px;text-align:center;">
                ⚠️ فيديو غير مدعوم للتشغيل<br>
                <a href="${src}" target="_blank" style="color:var(--gold);margin-top:12px;display:inline-block;">فتح في نافذة جديدة</a>
            </div>`;
        }
        trackAction('play_video', 'video', id);
    } catch (e) { titleEl.textContent = 'خطأ'; c.innerHTML = '<div style="color:#e74c3c;padding:40px;text-align:center;">⚠️ خطأ</div>'; }
};

/* إصلاح كامل لاستخراج روابط YouTube */
function getVideoEmbedInfo(src) {
    if (!src) return { isIframe: false, isMP4: false, src: '' };

    // YouTube - كل الأشكال
    const ytPatterns = [
        /(?:youtube\.com\/watch\?v=)([\w\-]+)/,
        /(?:youtu\.be\/)([\w\-]+)/,
        /(?:youtube\.com\/embed\/)([\w\-]+)/,
        /(?:youtube\.com\/shorts\/)([\w\-]+)/
    ];
    for (const pat of ytPatterns) {
        const m = src.match(pat);
        if (m) {
            return {
                isIframe: true,
                isMP4: false,
                src: `https://www.youtube.com/embed/${m[1]}?autoplay=1&controls=1&rel=0&playsinline=1&modestbranding=1`
            };
        }
    }

    // Screenpal
    if (src.includes('screenpal.com')) {
        const m = src.match(/\/([a-zA-Z0-9]+)(?:\?|$)/);
        return {
            isIframe: true,
            isMP4: false,
            src: m ? `https://go.screenpal.com/player/${m[1]}` : src
        };
    }

    // Vimeo
    if (src.includes('vimeo.com')) {
        const m = src.match(/vimeo\.com\/(?:video\/)?(\d+)/);
        if (m) return { isIframe: true, isMP4: false, src: `https://player.vimeo.com/video/${m[1]}?autoplay=1` };
    }

    // MP4 مباشر
    if (/\.(mp4|webm|ogg|mov)(\?|$)/i.test(src)) {
        return { isIframe: false, isMP4: true, src };
    }

    // iframe عام
    if (src.startsWith('http')) {
        return { isIframe: true, isMP4: false, src };
    }

    return { isIframe: false, isMP4: false, src };
}

window.closeVideoPlayer = function () {
    const c = $('#videoPlayerContainer');
    if (c) { c.querySelectorAll('video').forEach(v => { try { v.pause(); } catch(e){} }); c.innerHTML = ''; }
    const m = $('#videoPlayerModal'); if (m) { m.classList.remove('active'); m.style.display = 'none'; }
    document.body.style.overflow = '';
};

/* ============================================================
   REELS
   ============================================================ */
async function loadReels() {
    if (!DATA.sections.videos) return;
    const c = $('#reelsTabContainer'); if (!c) return;
    if (c.dataset.loaded === 'true') {
        const savedIdx = parseInt(sessionStorage.getItem('reels_index') || '0');
        if (savedIdx > 0) { setTimeout(() => { const items = c.querySelectorAll('.reel-item-modern'); if (items[savedIdx]) items[savedIdx].scrollIntoView({ behavior: 'auto' }); initReelsEngine(); }, 50); }
        else { initReelsEngine(); }
        return;
    }
    try {
        const res = await fetch(`${API_BASE}get_videos`);
        const videos = await res.json();
        if (!videos.length) { c.innerHTML = `<div class="loader" style="padding-top:150px;color:#fff;">🎬 ${DATA.texts.emptyVideos}</div>`; return; }
        c.innerHTML = videos.map((v, i) => buildReel(v, i)).join('');
        c.dataset.loaded = 'true';
        const savedIdx = parseInt(sessionStorage.getItem('reels_index') || '0');
        setTimeout(() => { if (savedIdx > 0) { const items = c.querySelectorAll('.reel-item-modern'); if (items[savedIdx]) items[savedIdx].scrollIntoView({ behavior: 'auto' }); } initReelsEngine(); }, 200);
    } catch (e) { c.innerHTML = '<div class="loader" style="padding-top:150px;">⚠️ خطأ</div>'; }
}

function buildReel(v, i) {
    const src = v.video_type === 'file' ? 'uploads/' + escapeHtml(v.file_path) : escapeHtml(v.video_url || '');
    const embedInfo = getVideoEmbedInfo(src);
    const rImg = v.reciter_image ? 'uploads/reel_reciters/' + escapeHtml(v.reciter_image) : 'https://via.placeholder.com/56/0d2b35/c9a959?text=🎤';
    const rName = escapeHtml(v.reciter_name || 'قارئ');
    const rId = v.reel_reciter_id || 0;
    const poster = v.thumbnail_path ? 'uploads/thumbnails/' + escapeHtml(v.thumbnail_path) : '';
    const isLiked = localStorage.getItem(`reel_liked_${v.id}`) === 'true';
    // إصلاح: نستخدم embedInfo.src النظيف
    const iframeSrc = embedInfo.isIframe ? embedInfo.src : '';
    const videoSrc = embedInfo.isMP4 ? src : '';
    return `<div class="reel-item-modern" data-index="${i}" data-video-id="${v.id}" data-title="${escapeHtml(v.title)}">
        <div class="reel-video-wrapper">
            ${poster ? `<div class="reel-poster" style="background-image:url('${poster}')"></div>` : ''}
            <div class="reel-loading"><i class="fas fa-circle-notch fa-spin"></i></div>
            ${iframeSrc ? `<iframe class="reel-iframe" data-src="${iframeSrc}" allowfullscreen></iframe>` : ''}
            ${videoSrc ? `<video class="reel-video-player" data-src="${videoSrc}" preload="none" playsinline loop crossorigin="anonymous"${poster ? ` poster="${poster}"` : ''}></video>` : (iframeSrc ? '' : `<div style="color:#fff;text-align:center;padding:20px;">⚠️ فيديو غير مدعوم</div>`)}
        </div>
        <div class="reel-left-side">
            <div class="reel-reciter-avatar" onclick="event.stopPropagation(); openReciterProfileFromReel(${rId}, '${rName.replace(/'/g, "\\'")}', '${rImg}')">
                <img src="${rImg}" onerror="this.src='https://via.placeholder.com/56'" loading="lazy" alt="${rName}">
                <span class="reciter-name-tag">${rName}</span>
            </div>
            <div class="reel-action-btn-wrapper" onclick="event.stopPropagation(); toggleReelLike(${v.id}, this)">
                <div class="reel-action-circle ${isLiked ? 'liked' : ''}" id="like-${v.id}"><i class="fas fa-heart"></i></div>
                <span>${DATA.texts.btnLike}</span>
            </div>
            <div class="reel-action-btn-wrapper" onclick="event.stopPropagation(); openSharePopup('${escapeHtml(v.title).replace(/'/g, "\\'")}', ${v.id})">
                <div class="reel-action-circle"><i class="fas fa-share-alt"></i></div>
                <span>${DATA.texts.btnShare}</span>
            </div>
            ${videoSrc ? `<div class="reel-action-btn-wrapper" onclick="event.stopPropagation(); downloadFile('${videoSrc}', '${escapeHtml(v.title)}.mp4')">
                <div class="reel-action-circle download"><i class="fas fa-download"></i></div>
                <span>${DATA.texts.btnDownload}</span>
            </div>` : ''}
        </div>
        <div class="reel-progress-holder" id="progress-${i}">
            <div class="reel-progress-modern">
                <span class="time-display" id="time-current-${i}">00:00</span>
                <div class="track-wrapper"><div class="track-fill" id="track-fill-${i}"></div><input type="range" id="timeline-${i}" min="0" value="0" max="100" step="0.1"></div>
                <span class="time-display" id="time-duration-${i}">00:00</span>
            </div>
        </div>
        <div class="reel-bottom-meta">
            <div class="reel-meta-title"><i class="fas fa-video"></i> ${escapeHtml(v.title)}</div>
            ${v.reciter_name ? `<div class="reel-meta-desc">${rName}</div>` : ''}
        </div>
    </div>`;
}

function initReelsEngine() {
    const c = $('#reelsTabContainer'); if (!c) return;
    if (!c._scrollBound) {
        let scrollTimer;
        c.addEventListener('scroll', () => {
            clearTimeout(scrollTimer);
            scrollTimer = setTimeout(() => {
                const scrollTop = c.scrollTop, itemHeight = c.clientHeight;
                sessionStorage.setItem('reels_index', Math.round(scrollTop / itemHeight));
            }, 250);
        }, { passive: true });
        c._scrollBound = true;
    }
    c.querySelectorAll('.reel-item-modern').forEach(item => {
        if (item.dataset.engineInit === 'true') return;
        item.dataset.engineInit = 'true';
        const video = item.querySelector('.reel-video-player');
        const idx = item.dataset.index, id = item.dataset.videoId;
        if (video) {
            const fill = document.getElementById('track-fill-' + idx);
            const tl = document.getElementById('timeline-' + idx);
            const ct = document.getElementById('time-current-' + idx);
            const dt = document.getElementById('time-duration-' + idx);
            const loading = item.querySelector('.reel-loading');
            video.ontimeupdate = () => { if (video.duration && fill && tl) { const p = (video.currentTime / video.duration) * 100; fill.style.width = p + '%'; tl.value = p; if (ct) ct.textContent = formatTime(video.currentTime); } };
            video.onloadedmetadata = () => { if (dt && video.duration) dt.textContent = formatTime(video.duration); };
            video.oncanplay = () => { if (loading) loading.classList.add('hidden'); };
            video.onerror = () => { if (loading) loading.classList.add('hidden'); };
            if (tl) tl.addEventListener('input', function (e) { e.stopPropagation(); const val = parseFloat(this.value); if (video.duration) { video.currentTime = (val / 100) * video.duration; if (fill) fill.style.width = val + '%'; } });
            video.onclick = (e) => { e.stopPropagation(); if (video.paused) { video.play().catch(() => {}); item.classList.remove('paused-mode'); } else { video.pause(); item.classList.add('paused-mode'); } };
            video.ondblclick = (e) => { e.stopPropagation(); const w = item.querySelector('.reel-action-btn-wrapper'); if (w) toggleReelLike(id, w); };
        }
    });
    if (state.reelsObserver) state.reelsObserver.disconnect();
    state.reelsObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            const video = entry.target.querySelector('.reel-video-player');
            const iframe = entry.target.querySelector('.reel-iframe');
            const loading = entry.target.querySelector('.reel-loading');
            if (entry.isIntersecting) {
                if (video && !video.src && video.dataset.src) { if (loading) loading.classList.remove('hidden'); video.src = video.dataset.src; video.load(); }
                if (iframe && !iframe.src && iframe.dataset.src) iframe.src = iframe.dataset.src;
                if (iframe) iframe.classList.add('active');
                if (video) {
                    if (state.activeVideo && state.activeVideo !== video) { state.activeVideo.pause(); const prev = state.activeVideo.closest('.reel-item-modern'); if (prev) prev.classList.remove('paused-mode'); }
                    video.play().catch(() => {});
                    state.activeVideo = video;
                    entry.target.classList.remove('paused-mode');
                    trackAction('play_video', 'video', entry.target.dataset.videoId);
                }
            } else {
                if (video) { video.pause(); entry.target.classList.remove('paused-mode'); }
                if (iframe) iframe.classList.remove('active');
            }
        });
    }, { root: c, threshold: 0.55 });
    c.querySelectorAll('.reel-item-modern').forEach(i => state.reelsObserver.observe(i));
}

window.toggleReelLike = function (id, el) {
    const circle = el.querySelector('.reel-action-circle') || el; if (!circle) return;
    const liked = circle.classList.contains('liked');
    if (liked) { circle.classList.remove('liked'); localStorage.removeItem(`reel_liked_${id}`); showToast('تم إزالة الإعجاب'); }
    else { circle.classList.add('liked'); localStorage.setItem(`reel_liked_${id}`, 'true'); showToast('❤️ إعجاب'); trackAction('like', 'video', id); }
};

/* ============================================================
   PROFILE
   ============================================================ */
window.openReciterProfileFromReel = async function (id, name, img) {
    if (!id) { showToast('⚠️ لا يوجد قارئ'); return; }
    $$('.reel-video-player').forEach(v => { if (!v.paused) v.pause(); });
    state.currentProfileId = id;
    state.currentProfileName = name;
    state.currentProfileImage = img;
    const overlay = $('#profileOverlay');
    const body = $('#profileBody');
    if (!overlay || !body) return;
    body.innerHTML = '<div class="loader" style="padding-top:120px;"><i class="fas fa-spinner fa-spin" style="font-size:30px;"></i><p>جاري التحميل...</p></div>';
    overlay.classList.add('active');
    overlay.scrollTop = 0;
    document.body.style.overflow = 'hidden';
    try {
        const [r1, r2] = await Promise.all([
            fetch(`${API_BASE}get_reel_reciter&id=${id}`),
            fetch(`${API_BASE}get_reciter_videos&reciter_id=${id}`)
        ]);
        const rd = await r1.json();
        const videos = await r2.json();
        state.currentReciterVideos = videos;
        state.currentProfileVideos = videos;
        state.currentProfileLikedVideos = videos.filter(v => localStorage.getItem(`reel_liked_${v.id}`) === 'true');
        const pi = img && img !== '' ? img : 'https://via.placeholder.com/100/0d2b35/c9a959?text=🎤';
        const finalName = rd.name || name || 'قارئ';
        const username = rd.username || 'reciter';
        const bio = rd.bio || '';
        body.innerHTML = `<div class="profile-body">
            <div class="profile-top-section">
                <img class="profile-avatar" src="${pi}" onerror="this.src='https://via.placeholder.com/100/0d2b35/c9a959?text=🎤'" alt="${escapeHtml(finalName)}">
                <div class="profile-username-handle">@${escapeHtml(username)}</div>
                <div class="profile-stats-row">
                    <div class="profile-stat"><div class="num">${videos.length}</div><div class="lbl">فيديو</div></div>
                    <div class="profile-stat"><div class="num">${state.currentProfileLikedVideos.length}</div><div class="lbl">إعجاب</div></div>
                </div>
                ${bio ? `<div class="profile-bio">${escapeHtml(bio).replace(/\n/g, '<br>')}</div>` : ''}
            </div>
            <div class="profile-tabs">
                <button class="profile-tab active" id="tabVideosBtn" onclick="switchProfileTab('videos')"><i class="fas fa-th"></i></button>
                <button class="profile-tab" id="tabLikesBtn" onclick="switchProfileTab('likes')"><i class="fas fa-heart"></i></button>
            </div>
            <div class="profile-videos-grid" id="profileVideosGrid"></div>
        </div>`;
        renderProfileVideos('videos');
    } catch (e) { body.innerHTML = '<div class="loader" style="padding-top:120px;">⚠️ خطأ</div>'; }
};

window.switchProfileTab = function(tab) {
    const videosBtn = $('#tabVideosBtn');
    const likesBtn = $('#tabLikesBtn');
    if (videosBtn) videosBtn.classList.toggle('active', tab === 'videos');
    if (likesBtn) likesBtn.classList.toggle('active', tab === 'likes');
    renderProfileVideos(tab);
};

function renderProfileVideos(tab) {
    const grid = $('#profileVideosGrid');
    if (!grid) return;
    const videos = tab === 'videos' ? (state.currentProfileVideos || []) : (state.currentProfileLikedVideos || []);
    if (!videos.length) {
        grid.innerHTML = `<div class="profile-empty-state"><i class="fas fa-${tab === 'videos' ? 'video-slash' : 'heart'}"></i><p>${tab === 'videos' ? 'لا توجد فيديوهات بعد' : 'لم تعجب بأي فيديو'}</p></div>`;
        return;
    }
    grid.innerHTML = videos.map((v, i) => {
        const t = v.thumbnail_path ? 'uploads/thumbnails/' + v.thumbnail_path : '';
        const realIdx = (state.currentProfileVideos || []).findIndex(x => x.id === v.id);
        const isLiked = localStorage.getItem(`reel_liked_${v.id}`) === 'true';
        return `<div class="profile-video-item" onclick="openReciterReels(${realIdx >= 0 ? realIdx : i})">
            ${t ? `<img src="${t}" alt="${escapeHtml(v.title)}" loading="lazy">` : `<div style="width:100%;height:100%;background:#0a0f1e;display:flex;align-items:center;justify-content:center;"><i class="fas fa-video" style="color:#c9a959;font-size:28px;"></i></div>`}
            <div class="profile-video-play-icon"><i class="fas fa-play"></i></div>
            <div class="profile-video-overlay">${isLiked ? '<i class="fas fa-heart" style="color:#ff4757;"></i>' : '<i class="fas fa-play"></i>'}</div>
        </div>`;
    }).join('');
}

window.closeProfileOverlay = function () {
    const overlay = $('#profileOverlay');
    if (!overlay) return;
    overlay.classList.remove('active');
    document.body.style.overflow = '';
};

window.openReciterReels = function (idx) {
    if (!state.currentReciterVideos.length) { showToast('⚠️ لا توجد فيديوهات'); return; }
    state.currentReciterReelIndex = idx;
    createReciterReelsUI(idx);
};

function createReciterReelsUI(startIdx) {
    const container = $('#reciterReelsContainer');
    const backBtn = $('#reciterReelsBackBtn');
    if (!container || !backBtn) return;
    const videos = state.currentReciterVideos;
    const sliceVideos = videos.slice(startIdx);
    container.innerHTML = sliceVideos.map((v, localIdx) => buildReciterFullscreenReel(v, startIdx + localIdx)).join('');
    container.style.display = 'block';
    backBtn.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    container.scrollTop = 0;
    setTimeout(() => initReciterReelsEngine(), 100);
}

function buildReciterFullscreenReel(v, realIdx) {
    const src = v.video_type === 'file' ? 'uploads/' + escapeHtml(v.file_path) : escapeHtml(v.video_url || '');
    const embedInfo = getVideoEmbedInfo(src);
    const poster = v.thumbnail_path ? 'uploads/thumbnails/' + escapeHtml(v.thumbnail_path) : '';
    const isLiked = localStorage.getItem(`reel_liked_${v.id}`) === 'true';
    const rImg = state.currentProfileImage || 'https://via.placeholder.com/56/0d2b35/c9a959?text=🎤';
    const rName = state.currentProfileName || 'قارئ';
    const iframeSrc = embedInfo.isIframe ? embedInfo.src : '';
    const videoSrc = embedInfo.isMP4 ? src : '';
    return `<div class="reel-item-modern" data-index="${realIdx}" data-video-id="${v.id}">
        <div class="reel-video-wrapper">
            ${poster ? `<div class="reel-poster" style="background-image:url('${poster}')"></div>` : ''}
            <div class="reel-loading"><i class="fas fa-circle-notch fa-spin"></i></div>
            ${iframeSrc ? `<iframe class="reel-iframe" data-src="${iframeSrc}" allowfullscreen></iframe>` : ''}
            ${videoSrc ? `<video class="reel-video-player" data-src="${videoSrc}" preload="none" playsinline loop crossorigin="anonymous"${poster ? ` poster="${poster}"` : ''}></video>` : ''}
        </div>
        <div class="reel-left-side">
            <div class="reel-reciter-avatar" onclick="event.stopPropagation();">
                <img src="${rImg}" onerror="this.src='https://via.placeholder.com/56'" loading="lazy" alt="${escapeHtml(rName)}">
                <span class="reciter-name-tag">${escapeHtml(rName)}</span>
            </div>
            <div class="reel-action-btn-wrapper" onclick="event.stopPropagation(); toggleReelLikeAndRefresh(${v.id}, this)">
                <div class="reel-action-circle ${isLiked ? 'liked' : ''}"><i class="fas fa-heart"></i></div>
                <span>${DATA.texts.btnLike}</span>
            </div>
            <div class="reel-action-btn-wrapper" onclick="event.stopPropagation(); openSharePopup('${escapeHtml(v.title).replace(/'/g, "\\'")}', ${v.id})">
                <div class="reel-action-circle"><i class="fas fa-share-alt"></i></div>
                <span>${DATA.texts.btnShare}</span>
            </div>
            ${videoSrc ? `<div class="reel-action-btn-wrapper" onclick="event.stopPropagation(); downloadFile('${videoSrc}', '${escapeHtml(v.title)}.mp4')">
                <div class="reel-action-circle download"><i class="fas fa-download"></i></div>
                <span>${DATA.texts.btnDownload}</span>
            </div>` : ''}
        </div>
        <div class="reel-progress-holder">
            <div class="reel-progress-modern">
                <span class="time-display" data-role="current">00:00</span>
                <div class="track-wrapper"><div class="track-fill" data-role="fill"></div><input type="range" data-role="timeline" min="0" value="0" max="100" step="0.1"></div>
                <span class="time-display" data-role="duration">00:00</span>
            </div>
        </div>
        <div class="reel-bottom-meta"><div class="reel-meta-title"><i class="fas fa-video"></i> ${escapeHtml(v.title)}</div></div>
    </div>`;
}

window.toggleReelLikeAndRefresh = function (id, el) {
    const circle = el.querySelector('.reel-action-circle') || el; if (!circle) return;
    const liked = circle.classList.contains('liked');
    if (liked) { circle.classList.remove('liked'); localStorage.removeItem(`reel_liked_${id}`); showToast('تم إزالة الإعجاب'); }
    else { circle.classList.add('liked'); localStorage.setItem(`reel_liked_${id}`, 'true'); showToast('❤️ إعجاب'); trackAction('like', 'video', id); }
    if (state.currentProfileVideos.length) {
        state.currentProfileLikedVideos = state.currentProfileVideos.filter(v => localStorage.getItem(`reel_liked_${v.id}`) === 'true');
        const statNums = $$('.profile-stat .num');
        if (statNums[1]) statNums[1].textContent = state.currentProfileLikedVideos.length;
    }
};

function initReciterReelsEngine() {
    const container = $('#reciterReelsContainer'); if (!container) return;
    if (state.reciterReelsObserver) state.reciterReelsObserver.disconnect();
    container.querySelectorAll('.reel-item-modern').forEach(item => {
        const video = item.querySelector('.reel-video-player');
        if (video) {
            const fill = item.querySelector('[data-role="fill"]');
            const tl = item.querySelector('[data-role="timeline"]');
            const ct = item.querySelector('[data-role="current"]');
            const dt = item.querySelector('[data-role="duration"]');
            const loading = item.querySelector('.reel-loading');
            video.ontimeupdate = () => { if (video.duration && fill && tl) { const p = (video.currentTime / video.duration) * 100; fill.style.width = p + '%'; tl.value = p; if (ct) ct.textContent = formatTime(video.currentTime); } };
            video.onloadedmetadata = () => { if (dt && video.duration) dt.textContent = formatTime(video.duration); };
            video.oncanplay = () => { if (loading) loading.classList.add('hidden'); };
            video.onerror = () => { if (loading) loading.classList.add('hidden'); };
            if (tl) tl.addEventListener('input', function (e) { e.stopPropagation(); const val = parseFloat(this.value); if (video.duration) { video.currentTime = (val / 100) * video.duration; if (fill) fill.style.width = val + '%'; } });
            video.onclick = (e) => { e.stopPropagation(); if (video.paused) video.play().catch(() => {}); else video.pause(); };
        }
    });
    state.reciterReelsObserver = new IntersectionObserver(entries => {
        entries.forEach(e => {
            const video = e.target.querySelector('.reel-video-player');
            const iframe = e.target.querySelector('.reel-iframe');
            const loading = e.target.querySelector('.reel-loading');
            if (e.isIntersecting) {
                if (video && !video.src && video.dataset.src) { if (loading) loading.classList.remove('hidden'); video.src = video.dataset.src; video.load(); }
                if (iframe && !iframe.src && iframe.dataset.src) iframe.src = iframe.dataset.src;
                container.querySelectorAll('.reel-video-player').forEach(v => { if (v !== video && !v.paused) v.pause(); });
                if (video) video.play().catch(() => {});
            } else { if (video && !video.paused) video.pause(); }
        });
    }, { root: container, threshold: 0.55 });
    container.querySelectorAll('.reel-item-modern').forEach(i => state.reciterReelsObserver.observe(i));
}

window.closeReciterReels = function () {
    const container = $('#reciterReelsContainer');
    const backBtn = $('#reciterReelsBackBtn');
    if (container) {
        container.querySelectorAll('.reel-video-player').forEach(v => { try { v.pause(); } catch(e){} });
        container.innerHTML = ''; container.style.display = 'none'; container.scrollTop = 0;
    }
    if (backBtn) backBtn.style.display = 'none';
    if (state.reciterReelsObserver) { state.reciterReelsObserver.disconnect(); state.reciterReelsObserver = null; }
    if (!$('#profileOverlay')?.classList.contains('active')) document.body.style.overflow = '';
};

/* ============================================================
   INIT
   ============================================================ */
function initializeApp() {
    const app = $('#appWrapper');
    if (app) app.style.display = '';
    if (state.quranNightMode) { const c = $('#quranContainer'); if (c) c.classList.add('night-mode'); }
    const sl = $('#quranFontSizeLabel'); if (sl) sl.textContent = state.quranFontSize + '%';
    const lp = localStorage.getItem('lastQuranPage'); if (lp) state.currentPage = parseInt(lp);

    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get('video') || urlParams.get('reel');
    const reciterId = urlParams.get('reciter');

    if (videoId) setTimeout(() => openVideoPlayerById(videoId), 800);
    if (reciterId) {
        setTimeout(async () => {
            try {
                const res = await fetch(`${API_BASE}get_reel_reciter&id=${reciterId}`);
                const rd = await res.json();
                if (rd && rd.id) {
                    const img = rd.image ? 'uploads/reel_reciters/' + rd.image : '';
                    openReciterProfileFromReel(rd.id, rd.name, img);
                }
            } catch (e) {}
        }, 800);
    }

    const savedTab = sessionStorage.getItem('currentTab');
    if (savedTab && savedTab !== 'home' && !videoId && !reciterId) {
        const navItem = document.querySelector(`.nav-item[data-tab="${savedTab}"], .sidebar-nav-item[data-tab="${savedTab}"]`);
        if (navItem) setTimeout(() => switchTab(savedTab, navItem), 100);
    }

    if (DATA.sections.prayer) loadHomePrayerTimes();
    if (DATA.sections.reciters) loadCarouselReciters();
    if (DATA.sections.books) loadAllBooks();
    if (DATA.sections.surahs) { for (let i = 1; i <= 5; i++) preloadPage(i); }

    setTimeout(() => {
        initDragScroll($('#recitersCarousel'));
        initDragScroll($('#recentVideosScroll'));
    }, 500);

    updateTasbihDisplay();

    if (DATA.showIntro) {
        setTimeout(() => {
            const intro = $('#introScreen');
            if (intro) { intro.style.opacity = '0'; setTimeout(() => { intro.style.display = 'none'; }, 800); }
        }, 2200);
    }

    window.addEventListener('scroll', () => {
        const b = $('#scrollTopBtn');
        if (b) b.classList.toggle('visible', window.scrollY > 300);
    }, { passive: true });

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) { $$('.reel-video-player').forEach(v => { if (!v.paused) v.pause(); }); }
    });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initializeApp);
else initializeApp();

window.addEventListener('beforeunload', () => {
    if (state.reelsObserver) state.reelsObserver.disconnect();
    if (state.reciterReelsObserver) state.reciterReelsObserver.disconnect();
    if (state.heroCountdownInterval) clearInterval(state.heroCountdownInterval);
    if (audio) audio.pause();
});

})();
</script>
</body>
</html>